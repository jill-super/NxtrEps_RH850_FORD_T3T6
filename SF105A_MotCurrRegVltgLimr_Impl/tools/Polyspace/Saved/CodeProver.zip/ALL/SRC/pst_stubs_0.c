#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * atan2f
 */


__PST__FLOAT32 atan2f(__PST__FLOAT32 P_0, __PST__FLOAT32 P_1)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        {
            __PST__FLOAT32 _main_gen_tmp_0;
            _main_gen_tmp_0 = pst_random_g_10;
            if (_main_gen_tmp_0 < -3.141200e+000F) _main_gen_tmp_0 = -3.141200e+000F;
            else if (_main_gen_tmp_0 > 3.141200e+000F) _main_gen_tmp_0 = 3.141200e+000F;
            random_for_return = _main_gen_tmp_0;
        }
        return random_for_return;
    }
}

/*
 * expf
 */


__PST__FLOAT32 expf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        {
            __PST__FLOAT32 _main_gen_tmp_1;
            _main_gen_tmp_1 = pst_random_g_10;
            if (_main_gen_tmp_1 < 0.000000e+000F) _main_gen_tmp_1 = 0.000000e+000F;
            else if (_main_gen_tmp_1 > 3.402823e+038F) _main_gen_tmp_1 = 3.402823e+038F;
            random_for_return = _main_gen_tmp_1;
        }
        return random_for_return;
    }
}

/*
 * sqrtf
 */


__PST__FLOAT32 sqrtf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        {
            __PST__FLOAT32 _main_gen_tmp_2;
            _main_gen_tmp_2 = pst_random_g_10;
            if (_main_gen_tmp_2 < 0.000000e+000F) _main_gen_tmp_2 = 0.000000e+000F;
            else if (_main_gen_tmp_2 > 3.402823e+038F) _main_gen_tmp_2 = 3.402823e+038F;
            random_for_return = _main_gen_tmp_2;
        }
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtDax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtDax_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtDax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtQax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtQax_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtQax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrCurrLoaScarSlewRate_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrCurrLoaScarSlewRate_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrCurrLoaScarSlewRate_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDaxAntiWdupCoeff_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDaxAntiWdupCoeff_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDaxAntiWdupCoeff_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDualEcuLoaScarSlewRate_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDualEcuLoaScarSlewRate_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDualEcuLoaScarSlewRate_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrFETLoaScarSlewRate_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrFETLoaScarSlewRate_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrFETLoaScarSlewRate_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrIvtrLoaScarSlewRate_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrIvtrLoaScarSlewRate_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrIvtrLoaScarSlewRate_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredTi_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglHiLim_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglLoLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglLoLim_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglLoLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglHiLim_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglLoLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglLoLim_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglLoLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupCoeff_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupCoeff_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupCoeff_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlIvtrDeadTiBrdgVltgSca_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlIvtrDeadTiBrdgVltgSca_Val"


__PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlIvtrDeadTiBrdgVltgSca_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl"


__PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredEna_Logl"


__PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna_Logl"


__PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgFilEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgFilEna_Logl"


__PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgFilEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfFilEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfFilEna_Logl"


__PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfFilEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupScagDi_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupScagDi_Logl"


__PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupScagDi_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlFbCtrlDi_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlFbCtrlDi_Logl"


__PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlFbCtrlDi_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

