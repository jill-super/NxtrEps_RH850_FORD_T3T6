/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function atan2f
//
// #pragma POLYSPACE_PURE "atan2f"
// #pragma POLYSPACE_CLEAN "atan2f"
// #pragma POLYSPACE_WORST "atan2f"
//
// __PST__FLOAT32 atan2f(__PST__FLOAT32 P_0, __PST__FLOAT32 P_1)
// {
//    ...
// }


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function sqrtf
//
// #pragma POLYSPACE_PURE "sqrtf"
// #pragma POLYSPACE_CLEAN "sqrtf"
// #pragma POLYSPACE_WORST "sqrtf"
//
// __PST__FLOAT32 sqrtf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtDax_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtDax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtDax_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtDax_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtDax_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtQax_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtQax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtQax_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtQax_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgMotRVirtQax_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrCurrLoaScarSlewRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrCurrLoaScarSlewRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrCurrLoaScarSlewRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrCurrLoaScarSlewRate_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrCurrLoaScarSlewRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDaxAntiWdupCoeff_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDaxAntiWdupCoeff_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDaxAntiWdupCoeff_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDaxAntiWdupCoeff_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDaxAntiWdupCoeff_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDualEcuLoaScarSlewRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDualEcuLoaScarSlewRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDualEcuLoaScarSlewRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDualEcuLoaScarSlewRate_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrDualEcuLoaScarSlewRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrFETLoaScarSlewRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrFETLoaScarSlewRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrFETLoaScarSlewRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrFETLoaScarSlewRate_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrFETLoaScarSlewRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrIvtrLoaScarSlewRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrIvtrLoaScarSlewRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrIvtrLoaScarSlewRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrIvtrLoaScarSlewRate_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrIvtrLoaScarSlewRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredTi_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglLoLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglLoLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglLoLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglLoLim_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgDaxIntglLoLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglLoLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglLoLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglLoLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglLoLim_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxIntglLoLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupCoeff_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupCoeff_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupCoeff_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupCoeff_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupCoeff_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlIvtrDeadTiBrdgVltgSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlIvtrDeadTiBrdgVltgSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlIvtrDeadTiBrdgVltgSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlIvtrDeadTiBrdgVltgSca_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlIvtrDeadTiBrdgVltgSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl"
//
// __PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredEna_Logl"
//
// __PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrPredEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna_Logl"
//
// __PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotCurrQaxRefMdfnRplEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgFilEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgFilEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgFilEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgFilEna_Logl"
//
// __PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgBrdgFilEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfFilEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfFilEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfFilEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfFilEna_Logl"
//
// __PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrMotVltgQaxFfFilEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupScagDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupScagDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupScagDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupScagDi_Logl"
//
// __PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotCurrRegVltgLimrQaxAntiWdupScagDi_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlFbCtrlDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlFbCtrlDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlFbCtrlDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlFbCtrlDi_Logl"
//
// __PST__UINT8 Rte_Prm_CDD_MotCurrRegVltgLimr_MotRefMdlFbCtrlDi_Logl(__PST__VOID)
// {
//    ...
// }

