#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__28 _main_gen_init_g28(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct Rte_CDS_CDD_MotCurrRegVltgLimr _main_gen_init_g25(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__28 _main_gen_init_g28(void)
{
    static struct __PST__g__28 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

struct Rte_CDS_CDD_MotCurrRegVltgLimr _main_gen_init_g25(void)
{
    static struct Rte_CDS_CDD_MotCurrRegVltgLimr x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_5[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_6;
        for (_i_main_gen_tmp_6 = 0; _i_main_gen_tmp_6 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_6++)
        {
            _main_gen_tmp_5[_i_main_gen_tmp_6] = _main_gen_init_g10();
        }
        x.Pim_AntiWdupCmdScaDax = PST_TRUE() ? 0 : &_main_gen_tmp_5[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_7[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_8;
        for (_i_main_gen_tmp_8 = 0; _i_main_gen_tmp_8 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_8++)
        {
            _main_gen_tmp_7[_i_main_gen_tmp_8] = _main_gen_init_g10();
        }
        x.Pim_AntiWdupCmdScaQax = PST_TRUE() ? 0 : &_main_gen_tmp_7[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_9[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_10;
        for (_i_main_gen_tmp_10 = 0; _i_main_gen_tmp_10 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_10++)
        {
            _main_gen_tmp_9[_i_main_gen_tmp_10] = _main_gen_init_g10();
        }
        x.Pim_CurrLoaScarPrev = PST_TRUE() ? 0 : &_main_gen_tmp_9[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_11[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_12;
        for (_i_main_gen_tmp_12 = 0; _i_main_gen_tmp_12 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_12++)
        {
            _main_gen_tmp_11[_i_main_gen_tmp_12] = _main_gen_init_g10();
        }
        x.Pim_DualEcuLoaScarPrev = PST_TRUE() ? 0 : &_main_gen_tmp_11[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_13[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_14;
        for (_i_main_gen_tmp_14 = 0; _i_main_gen_tmp_14 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_14++)
        {
            _main_gen_tmp_13[_i_main_gen_tmp_14] = _main_gen_init_g10();
        }
        x.Pim_FETLoaScarPrev = PST_TRUE() ? 0 : &_main_gen_tmp_13[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_15[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_16;
        for (_i_main_gen_tmp_16 = 0; _i_main_gen_tmp_16 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_16++)
        {
            _main_gen_tmp_15[_i_main_gen_tmp_16] = _main_gen_init_g10();
        }
        x.Pim_IvtrLoaScarPrev = PST_TRUE() ? 0 : &_main_gen_tmp_15[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_17[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_18;
        for (_i_main_gen_tmp_18 = 0; _i_main_gen_tmp_18 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_18++)
        {
            _main_gen_tmp_17[_i_main_gen_tmp_18] = _main_gen_init_g10();
        }
        x.Pim_MotCtrlMotVltgDaxPrev = PST_TRUE() ? 0 : &_main_gen_tmp_17[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_19[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_20;
        for (_i_main_gen_tmp_20 = 0; _i_main_gen_tmp_20 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_20++)
        {
            _main_gen_tmp_19[_i_main_gen_tmp_20] = _main_gen_init_g10();
        }
        x.Pim_MotCtrlMotVltgQaxPrev = PST_TRUE() ? 0 : &_main_gen_tmp_19[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__28 _main_gen_tmp_21[ARRAY_NBELEM(struct __PST__g__28)];
        __PST__UINT32 _i_main_gen_tmp_22;
        for (_i_main_gen_tmp_22 = 0; _i_main_gen_tmp_22 < ARRAY_NBELEM(struct __PST__g__28); _i_main_gen_tmp_22++)
        {
            _main_gen_tmp_21[_i_main_gen_tmp_22] = _main_gen_init_g28();
        }
        x.Pim_MotVltgBrdgLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_21[ARRAY_NBELEM(struct __PST__g__28) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_23[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_24;
        for (_i_main_gen_tmp_24 = 0; _i_main_gen_tmp_24 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_24++)
        {
            _main_gen_tmp_23[_i_main_gen_tmp_24] = _main_gen_init_g10();
        }
        x.Pim_MotVltgIntglCmdDaxPrev = PST_TRUE() ? 0 : &_main_gen_tmp_23[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_25[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_26;
        for (_i_main_gen_tmp_26 = 0; _i_main_gen_tmp_26 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_26++)
        {
            _main_gen_tmp_25[_i_main_gen_tmp_26] = _main_gen_init_g10();
        }
        x.Pim_MotVltgIntglCmdQaxPrev = PST_TRUE() ? 0 : &_main_gen_tmp_25[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__28 _main_gen_tmp_27[ARRAY_NBELEM(struct __PST__g__28)];
        __PST__UINT32 _i_main_gen_tmp_28;
        for (_i_main_gen_tmp_28 = 0; _i_main_gen_tmp_28 < ARRAY_NBELEM(struct __PST__g__28); _i_main_gen_tmp_28++)
        {
            _main_gen_tmp_27[_i_main_gen_tmp_28] = _main_gen_init_g28();
        }
        x.Pim_MotVltgQaxFfLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_27[ARRAY_NBELEM(struct __PST__g__28) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_29[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_30;
        for (_i_main_gen_tmp_30 = 0; _i_main_gen_tmp_30 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_30++)
        {
            _main_gen_tmp_29[_i_main_gen_tmp_30] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrAntiWdupCmdScaDax = PST_TRUE() ? 0 : &_main_gen_tmp_29[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_31[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_32;
        for (_i_main_gen_tmp_32 = 0; _i_main_gen_tmp_32 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_32++)
        {
            _main_gen_tmp_31[_i_main_gen_tmp_32] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrAntiWdupCmdScaQax = PST_TRUE() ? 0 : &_main_gen_tmp_31[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_33[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_34;
        for (_i_main_gen_tmp_34 = 0; _i_main_gen_tmp_34 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_34++)
        {
            _main_gen_tmp_33[_i_main_gen_tmp_34] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotCurrCmdErrDax = PST_TRUE() ? 0 : &_main_gen_tmp_33[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_35[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_36;
        for (_i_main_gen_tmp_36 = 0; _i_main_gen_tmp_36 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_36++)
        {
            _main_gen_tmp_35[_i_main_gen_tmp_36] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotCurrCmdErrQax = PST_TRUE() ? 0 : &_main_gen_tmp_35[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_37[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_38;
        for (_i_main_gen_tmp_38 = 0; _i_main_gen_tmp_38 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_38++)
        {
            _main_gen_tmp_37[_i_main_gen_tmp_38] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotCurrCmdScaDax = PST_TRUE() ? 0 : &_main_gen_tmp_37[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_39[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_40;
        for (_i_main_gen_tmp_40 = 0; _i_main_gen_tmp_40 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_40++)
        {
            _main_gen_tmp_39[_i_main_gen_tmp_40] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotCurrCmdScaQax = PST_TRUE() ? 0 : &_main_gen_tmp_39[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_41[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_42;
        for (_i_main_gen_tmp_42 = 0; _i_main_gen_tmp_42 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_42++)
        {
            _main_gen_tmp_41[_i_main_gen_tmp_42] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgBrdgFild = PST_TRUE() ? 0 : &_main_gen_tmp_41[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_43[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_44;
        for (_i_main_gen_tmp_44 = 0; _i_main_gen_tmp_44 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_44++)
        {
            _main_gen_tmp_43[_i_main_gen_tmp_44] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgCmdFinal = PST_TRUE() ? 0 : &_main_gen_tmp_43[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_45[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_46;
        for (_i_main_gen_tmp_46 = 0; _i_main_gen_tmp_46 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_46++)
        {
            _main_gen_tmp_45[_i_main_gen_tmp_46] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgCmdPreLim = PST_TRUE() ? 0 : &_main_gen_tmp_45[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_47[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_48;
        for (_i_main_gen_tmp_48 = 0; _i_main_gen_tmp_48 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_48++)
        {
            _main_gen_tmp_47[_i_main_gen_tmp_48] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgDampgDax = PST_TRUE() ? 0 : &_main_gen_tmp_47[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_49[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_50;
        for (_i_main_gen_tmp_50 = 0; _i_main_gen_tmp_50 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_50++)
        {
            _main_gen_tmp_49[_i_main_gen_tmp_50] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgDampgQax = PST_TRUE() ? 0 : &_main_gen_tmp_49[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_51[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_52;
        for (_i_main_gen_tmp_52 = 0; _i_main_gen_tmp_52 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_52++)
        {
            _main_gen_tmp_51[_i_main_gen_tmp_52] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgDaxFb = PST_TRUE() ? 0 : &_main_gen_tmp_51[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_53[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_54;
        for (_i_main_gen_tmp_54 = 0; _i_main_gen_tmp_54 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_54++)
        {
            _main_gen_tmp_53[_i_main_gen_tmp_54] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgDaxIntglPreLim = PST_TRUE() ? 0 : &_main_gen_tmp_53[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_55[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_56;
        for (_i_main_gen_tmp_56 = 0; _i_main_gen_tmp_56 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_56++)
        {
            _main_gen_tmp_55[_i_main_gen_tmp_56] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgDecouplFbDax = PST_TRUE() ? 0 : &_main_gen_tmp_55[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_57[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_58;
        for (_i_main_gen_tmp_58 = 0; _i_main_gen_tmp_58 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_58++)
        {
            _main_gen_tmp_57[_i_main_gen_tmp_58] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgDecouplFbQax = PST_TRUE() ? 0 : &_main_gen_tmp_57[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_59[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_60;
        for (_i_main_gen_tmp_60 = 0; _i_main_gen_tmp_60 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_60++)
        {
            _main_gen_tmp_59[_i_main_gen_tmp_60] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgDircFbDax = PST_TRUE() ? 0 : &_main_gen_tmp_59[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_61[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_62;
        for (_i_main_gen_tmp_62 = 0; _i_main_gen_tmp_62 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_62++)
        {
            _main_gen_tmp_61[_i_main_gen_tmp_62] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgDircFbQax = PST_TRUE() ? 0 : &_main_gen_tmp_61[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_63[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_64;
        for (_i_main_gen_tmp_64 = 0; _i_main_gen_tmp_64 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_64++)
        {
            _main_gen_tmp_63[_i_main_gen_tmp_64] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgPreLimDax = PST_TRUE() ? 0 : &_main_gen_tmp_63[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_65[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_66;
        for (_i_main_gen_tmp_66 = 0; _i_main_gen_tmp_66 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_66++)
        {
            _main_gen_tmp_65[_i_main_gen_tmp_66] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgPreLimQax = PST_TRUE() ? 0 : &_main_gen_tmp_65[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_67[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_68;
        for (_i_main_gen_tmp_68 = 0; _i_main_gen_tmp_68 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_68++)
        {
            _main_gen_tmp_67[_i_main_gen_tmp_68] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgPropCmdDax = PST_TRUE() ? 0 : &_main_gen_tmp_67[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_69[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_70;
        for (_i_main_gen_tmp_70 = 0; _i_main_gen_tmp_70 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_70++)
        {
            _main_gen_tmp_69[_i_main_gen_tmp_70] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgPropCmdQax = PST_TRUE() ? 0 : &_main_gen_tmp_69[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_71[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_72;
        for (_i_main_gen_tmp_72 = 0; _i_main_gen_tmp_72 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_72++)
        {
            _main_gen_tmp_71[_i_main_gen_tmp_72] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgQaxFb = PST_TRUE() ? 0 : &_main_gen_tmp_71[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_73[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_74;
        for (_i_main_gen_tmp_74 = 0; _i_main_gen_tmp_74 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_74++)
        {
            _main_gen_tmp_73[_i_main_gen_tmp_74] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgQaxFfFild = PST_TRUE() ? 0 : &_main_gen_tmp_73[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_75[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_76;
        for (_i_main_gen_tmp_76 = 0; _i_main_gen_tmp_76 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_76++)
        {
            _main_gen_tmp_75[_i_main_gen_tmp_76] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgQaxIntglPreLim = PST_TRUE() ? 0 : &_main_gen_tmp_75[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_77[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_78;
        for (_i_main_gen_tmp_78 = 0; _i_main_gen_tmp_78 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_78++)
        {
            _main_gen_tmp_77[_i_main_gen_tmp_78] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgSatnIvsRat = PST_TRUE() ? 0 : &_main_gen_tmp_77[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_79[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_80;
        for (_i_main_gen_tmp_80 = 0; _i_main_gen_tmp_80 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_80++)
        {
            _main_gen_tmp_79[_i_main_gen_tmp_80] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrMotVltgSatnRat = PST_TRUE() ? 0 : &_main_gen_tmp_79[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_81[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_82;
        for (_i_main_gen_tmp_82 = 0; _i_main_gen_tmp_82 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_82++)
        {
            _main_gen_tmp_81[_i_main_gen_tmp_82] = _main_gen_init_g10();
        }
        x.Pim_dMotCurrRegVltgLimrPhaAdvPreDly = PST_TRUE() ? 0 : &_main_gen_tmp_81[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_MotCurrRegVltgLimr(void)
{
    extern __PST__g__22 Rte_Inst_CDD_MotCurrRegVltgLimr;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_MotCurrRegVltgLimr _main_gen_tmp_3[ARRAY_NBELEM(struct Rte_CDS_CDD_MotCurrRegVltgLimr)];
            __PST__UINT32 _i_main_gen_tmp_4;
            for (_i_main_gen_tmp_4 = 0; _i_main_gen_tmp_4 < ARRAY_NBELEM(struct Rte_CDS_CDD_MotCurrRegVltgLimr); _i_main_gen_tmp_4++)
            {
                _main_gen_tmp_3[_i_main_gen_tmp_4] = _main_gen_init_g25();
            }
            Rte_Inst_CDD_MotCurrRegVltgLimr = PST_TRUE() ? 0 : &_main_gen_tmp_3[ARRAY_NBELEM(struct Rte_CDS_CDD_MotCurrRegVltgLimr) / 2];
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlBrdgVltg(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlBrdgVltg;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlBrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElecDly(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAgElecDly;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgElecDly = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDaxCmd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrDaxCmd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrDaxCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDaxMax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrDaxMax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrDaxMax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxCmd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrQaxCmd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQaxCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotDampgDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotDampgDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotDampgDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotDampgQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotDampgQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotDampgQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotIntglGainDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotIntglGainDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotIntglGainDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotIntglGainQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotIntglGainQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotIntglGainQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPropGainDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotPropGainDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotPropGainDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPropGainQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotPropGainQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotPropGainQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotReacncDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotReacncDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotReacncDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotReacncQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotReacncQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotReacncQax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgDaxFf(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVltgDaxFf;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVltgDaxFf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgQaxFf(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVltgQaxFf;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVltgQaxFf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlSysSt(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlSysSt;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlSysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotBackEmfVltg(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotBackEmfVltg;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotBackEmfVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotREstimd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotREstimd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotREstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgDax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVltgDax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVltgDax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgQax(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVltgQax;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVltgQax = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_MotCurrRegVltgLimr */
    _main_gen_init_sym_Rte_Inst_CDD_MotCurrRegVltgLimr();
    
    /* init for variable MOTCTRLMGR_MotCtrlBrdgVltg */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlBrdgVltg();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgElecDly */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElecDly();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrDaxCmd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDaxCmd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrDaxMax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrDaxMax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxCmd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxCmd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotDampgDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotDampgDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotDampgQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotDampgQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotIntglGainDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotIntglGainDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotIntglGainQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotIntglGainQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotPropGainDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPropGainDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotPropGainQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPropGainQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotReacncDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotReacncDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotReacncQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotReacncQax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotVltgDaxFf */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgDaxFf();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotVltgQaxFf */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgQaxFf();
    
    /* init for variable MOTCTRLMGR_MotCtrlSysSt */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlSysSt();
    
    /* init for variable MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlDualEcuMotCtrlMtgtnEna();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotBackEmfVltg */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotBackEmfVltg();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotREstimd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotREstimd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotInduDaxEstimdIvs();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotInduQaxEstimdIvs();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAndThermProtnLoaMod();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxCmdFinal : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotModlnIdx : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotPhaAdv : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotVltgDax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgDax();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotVltgQax */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVltgQax();
    
}
