#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * WrProtdRegEcm0_u32
 */


__PST__VOID WrProtdRegEcm0_u32(__PST__UINT32 P_0, __PST__g__66 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_8;
        }
        P_1[0] = pst_random_g_8;
    }

    return;
}

/*
 * __SYNCM
 */

#pragma POLYSPACE_POLYMORPHIC "__SYNCM"


__PST__VOID __SYNCM(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * SuspendAllInterrupts
 */

#pragma POLYSPACE_POLYMORPHIC "SuspendAllInterrupts"


__PST__VOID SuspendAllInterrupts(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * ResumeAllInterrupts
 */

#pragma POLYSPACE_POLYMORPHIC "ResumeAllInterrupts"


__PST__VOID ResumeAllInterrupts(__PST__VOID)
{
    /* function is pure */

    return;
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

