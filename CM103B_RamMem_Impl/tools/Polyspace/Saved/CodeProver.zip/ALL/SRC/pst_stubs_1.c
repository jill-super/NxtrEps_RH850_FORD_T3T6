#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__79 _main_gen_init_g79(void);

extern __PST__g__76 _main_gen_init_g76(void);

extern __PST__g__71 _main_gen_init_g71(void);

extern __PST__g__68 _main_gen_init_g68(void);

extern __PST__g__61 _main_gen_init_g61(void);

extern __PST__g__56 _main_gen_init_g56(void);

extern __PST__g__53 _main_gen_init_g53(void);

extern __PST__g__50 _main_gen_init_g50(void);

extern __PST__g__45 _main_gen_init_g45(void);

extern __PST__g__40 _main_gen_init_g40(void);

extern __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__23 _main_gen_init_g23(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__34 _main_gen_init_g34(void)
{
    __PST__g__34 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__37 _main_gen_init_g37(void)
{
    __PST__g__37 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__40 _main_gen_init_g40(void)
{
    __PST__g__40 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__45 _main_gen_init_g45(void)
{
    __PST__g__45 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__50 _main_gen_init_g50(void)
{
    __PST__g__50 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__53 _main_gen_init_g53(void)
{
    __PST__g__53 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__56 _main_gen_init_g56(void)
{
    __PST__g__56 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__61 _main_gen_init_g61(void)
{
    __PST__g__61 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__68 _main_gen_init_g68(void)
{
    __PST__g__68 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__71 _main_gen_init_g71(void)
{
    __PST__g__71 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__76 _main_gen_init_g76(void)
{
    __PST__g__76 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__79 _main_gen_init_g79(void)
{
    __PST__g__79 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_RamMem_Pim_GlbRamEccSngBitCntr(void)
{
    extern __PST__UINT8 RamMem_Pim_GlbRamEccSngBitCntr;
    
    /* initialization with random value */
    {
        RamMem_Pim_GlbRamEccSngBitCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RamMem_Pim_GlbRamEccSngBitSoftFailr(void)
{
    extern __PST__UINT8 RamMem_Pim_GlbRamEccSngBitSoftFailr;
    
    /* initialization with random value */
    {
        RamMem_Pim_GlbRamEccSngBitSoftFailr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RamMem_Pim_LclRamEccSngBitCntr(void)
{
    extern __PST__UINT8 RamMem_Pim_LclRamEccSngBitCntr;
    
    /* initialization with random value */
    {
        RamMem_Pim_LclRamEccSngBitCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RamMem_Pim_LclRamEccSngBitSoftFailr(void)
{
    extern __PST__UINT8 RamMem_Pim_LclRamEccSngBitSoftFailr;
    
    /* initialization with random value */
    {
        RamMem_Pim_LclRamEccSngBitSoftFailr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ECCCSIH0CTL_BASE(void)
{
    extern __PST__g__23 ECCCSIH0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH0CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCCSIH0EAD0_BASE(void)
{
    extern __PST__g__28 ECCCSIH0EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH0EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCCSIH1CTL_BASE(void)
{
    extern __PST__g__23 ECCCSIH1CTL_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH1CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCCSIH1EAD0_BASE(void)
{
    extern __PST__g__28 ECCCSIH1EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH1EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCCSIH2CTL_BASE(void)
{
    extern __PST__g__23 ECCCSIH2CTL_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH2CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCCSIH2EAD0_BASE(void)
{
    extern __PST__g__28 ECCCSIH2EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH2EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCCSIH3CTL_BASE(void)
{
    extern __PST__g__23 ECCCSIH3CTL_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH3CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCCSIH3EAD0_BASE(void)
{
    extern __PST__g__28 ECCCSIH3EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH3EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCTTCAN0CTL_BASE(void)
{
    extern __PST__g__23 ECCTTCAN0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCTTCAN0CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCTTCAN0EAD0_BASE(void)
{
    extern __PST__g__28 ECCTTCAN0EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCTTCAN0EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCMCAN0CTL_BASE(void)
{
    extern __PST__g__23 ECCMCAN0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCMCAN0CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCMCAN0EAD0_BASE(void)
{
    extern __PST__g__28 ECCMCAN0EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCMCAN0EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCMCAN1CTL_BASE(void)
{
    extern __PST__g__23 ECCMCAN1CTL_BASE;
    
    /* initialization with random value */
    {
        ECCMCAN1CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCMCAN1EAD0_BASE(void)
{
    extern __PST__g__28 ECCMCAN1EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCMCAN1EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCFLX0CTL_BASE(void)
{
    extern __PST__g__23 ECCFLX0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCFLX0CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCFLX0EAD0_BASE(void)
{
    extern __PST__g__28 ECCFLX0EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCFLX0EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCFLX0T0CTL_BASE(void)
{
    extern __PST__g__23 ECCFLX0T0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCFLX0T0CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCFLX0T0EAD0_BASE(void)
{
    extern __PST__g__28 ECCFLX0T0EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCFLX0T0EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCFLX0T1CTL_BASE(void)
{
    extern __PST__g__23 ECCFLX0T1CTL_BASE;
    
    /* initialization with random value */
    {
        ECCFLX0T1CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCFLX0T1EAD0_BASE(void)
{
    extern __PST__g__28 ECCFLX0T1EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCFLX0T1EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCGTM0CTL_BASE(void)
{
    extern __PST__g__23 ECCGTM0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCGTM0CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCGTM0EAD0_BASE(void)
{
    extern __PST__g__28 ECCGTM0EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCGTM0EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ECCGTM1CTL_BASE(void)
{
    extern __PST__g__23 ECCGTM1CTL_BASE;
    
    /* initialization with random value */
    {
        ECCGTM1CTL_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECCGTM1EAD0_BASE(void)
{
    extern __PST__g__28 ECCGTM1EAD0_BASE;
    
    /* initialization with random value */
    {
        ECCGTM1EAD0_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_IDSERSTCLR_PE1_BASE(void)
{
    extern __PST__g__34 IDSERSTCLR_PE1_BASE;
    
    /* initialization with random value */
    {
        IDSERSTCLR_PE1_BASE = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_IDDERSTCLR_PE1_BASE(void)
{
    extern __PST__g__37 IDDERSTCLR_PE1_BASE;
    
    /* initialization with random value */
    {
        IDDERSTCLR_PE1_BASE = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_IDSERSTR_PE1_BASE(void)
{
    extern __PST__g__40 IDSERSTR_PE1_BASE;
    
    /* initialization with random value */
    {
        IDSERSTR_PE1_BASE = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_IDDERSTR_PE1_BASE(void)
{
    extern __PST__g__45 IDDERSTR_PE1_BASE;
    
    /* initialization with random value */
    {
        IDDERSTR_PE1_BASE = _main_gen_init_g45();
    }
}

static void _main_gen_init_sym_ECM0ESSTC0_BASE(void)
{
    extern __PST__g__50 ECM0ESSTC0_BASE;
    
    /* initialization with random value */
    {
        ECM0ESSTC0_BASE = _main_gen_init_g50();
    }
}

static void _main_gen_init_sym_ECM0ESSTC1_BASE(void)
{
    extern __PST__g__53 ECM0ESSTC1_BASE;
    
    /* initialization with random value */
    {
        ECM0ESSTC1_BASE = _main_gen_init_g53();
    }
}

static void _main_gen_init_sym_DTSER2_BASE(void)
{
    extern __PST__g__56 DTSER2_BASE;
    
    /* initialization with random value */
    {
        DTSER2_BASE = _main_gen_init_g56();
    }
}

static void _main_gen_init_sym_DTSERC_BASE(void)
{
    extern __PST__g__61 DTSERC_BASE;
    
    /* initialization with random value */
    {
        DTSERC_BASE = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_LRSERSTCLR_PE1_BASE(void)
{
    extern __PST__g__68 LRSERSTCLR_PE1_BASE;
    
    /* initialization with random value */
    {
        LRSERSTCLR_PE1_BASE = _main_gen_init_g68();
    }
}

static void _main_gen_init_sym_LRSERSTR_PE1_BASE(void)
{
    extern __PST__g__71 LRSERSTR_PE1_BASE;
    
    /* initialization with random value */
    {
        LRSERSTR_PE1_BASE = _main_gen_init_g71();
    }
}

static void _main_gen_init_sym_UGRSERSTCLR_BASE(void)
{
    extern __PST__g__76 UGRSERSTCLR_BASE;
    
    /* initialization with random value */
    {
        UGRSERSTCLR_BASE = _main_gen_init_g76();
    }
}

static void _main_gen_init_sym_UGRSERSTR_BASE(void)
{
    extern __PST__g__79 UGRSERSTR_BASE;
    
    /* initialization with random value */
    {
        UGRSERSTR_BASE = _main_gen_init_g79();
    }
}

static void _main_gen_init_sym_RamMem_Pim_GlbRamFailrAdr(void)
{
    extern __PST__UINT32 RamMem_Pim_GlbRamFailrAdr;
    
    /* initialization with random value */
    {
        RamMem_Pim_GlbRamFailrAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_RamMem_Pim_LclRamFailrAdr(void)
{
    extern __PST__UINT32 RamMem_Pim_LclRamFailrAdr;
    
    /* initialization with random value */
    {
        RamMem_Pim_LclRamFailrAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_RamMem_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 RamMem_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        RamMem_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable RamMem_Op_GlbRamEccSngBitCntrOutp : useless (never read) */

    /* init for variable RamMem_Op_LclRamEccSngBitCntrOutp : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemCanRamDblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemCanRamSngBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemDtsRamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemFrRamDblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemFrRamSngBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemFrRamTmpBufADblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemFrRamTmpBufBDblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemGtmRamSngBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemMCan0RamDblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemMCan1RamDblBitEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpi0RamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpi1RamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpi2RamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpi3RamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_dRamMemSpiRamEccErrAdr : useless (never read) */

    /* init for variable RamMem_Pim_GlbRamEccSngBitCntr */
    _main_gen_init_sym_RamMem_Pim_GlbRamEccSngBitCntr();
    
    /* init for variable RamMem_Pim_GlbRamEccSngBitSoftFailr */
    _main_gen_init_sym_RamMem_Pim_GlbRamEccSngBitSoftFailr();
    
    /* init for variable RamMem_Pim_LclRamEccSngBitCntr */
    _main_gen_init_sym_RamMem_Pim_LclRamEccSngBitCntr();
    
    /* init for variable RamMem_Pim_LclRamEccSngBitSoftFailr */
    _main_gen_init_sym_RamMem_Pim_LclRamEccSngBitSoftFailr();
    
    /* init for variable ECCCSIH0CTL_BASE */
    _main_gen_init_sym_ECCCSIH0CTL_BASE();
    
    /* init for variable ECCCSIH0EAD0_BASE */
    _main_gen_init_sym_ECCCSIH0EAD0_BASE();
    
    /* init for variable ECCCSIH1CTL_BASE */
    _main_gen_init_sym_ECCCSIH1CTL_BASE();
    
    /* init for variable ECCCSIH1EAD0_BASE */
    _main_gen_init_sym_ECCCSIH1EAD0_BASE();
    
    /* init for variable ECCCSIH2CTL_BASE */
    _main_gen_init_sym_ECCCSIH2CTL_BASE();
    
    /* init for variable ECCCSIH2EAD0_BASE */
    _main_gen_init_sym_ECCCSIH2EAD0_BASE();
    
    /* init for variable ECCCSIH3CTL_BASE */
    _main_gen_init_sym_ECCCSIH3CTL_BASE();
    
    /* init for variable ECCCSIH3EAD0_BASE */
    _main_gen_init_sym_ECCCSIH3EAD0_BASE();
    
    /* init for variable ECCTTCAN0CTL_BASE */
    _main_gen_init_sym_ECCTTCAN0CTL_BASE();
    
    /* init for variable ECCTTCAN0EAD0_BASE */
    _main_gen_init_sym_ECCTTCAN0EAD0_BASE();
    
    /* init for variable ECCMCAN0CTL_BASE */
    _main_gen_init_sym_ECCMCAN0CTL_BASE();
    
    /* init for variable ECCMCAN0EAD0_BASE */
    _main_gen_init_sym_ECCMCAN0EAD0_BASE();
    
    /* init for variable ECCMCAN1CTL_BASE */
    _main_gen_init_sym_ECCMCAN1CTL_BASE();
    
    /* init for variable ECCMCAN1EAD0_BASE */
    _main_gen_init_sym_ECCMCAN1EAD0_BASE();
    
    /* init for variable ECCFLX0CTL_BASE */
    _main_gen_init_sym_ECCFLX0CTL_BASE();
    
    /* init for variable ECCFLX0EAD0_BASE */
    _main_gen_init_sym_ECCFLX0EAD0_BASE();
    
    /* init for variable ECCFLX0T0CTL_BASE */
    _main_gen_init_sym_ECCFLX0T0CTL_BASE();
    
    /* init for variable ECCFLX0T0EAD0_BASE */
    _main_gen_init_sym_ECCFLX0T0EAD0_BASE();
    
    /* init for variable ECCFLX0T1CTL_BASE */
    _main_gen_init_sym_ECCFLX0T1CTL_BASE();
    
    /* init for variable ECCFLX0T1EAD0_BASE */
    _main_gen_init_sym_ECCFLX0T1EAD0_BASE();
    
    /* init for variable ECCGTM0CTL_BASE */
    _main_gen_init_sym_ECCGTM0CTL_BASE();
    
    /* init for variable ECCGTM0EAD0_BASE */
    _main_gen_init_sym_ECCGTM0EAD0_BASE();
    
    /* init for variable ECCGTM1CTL_BASE */
    _main_gen_init_sym_ECCGTM1CTL_BASE();
    
    /* init for variable ECCGTM1EAD0_BASE */
    _main_gen_init_sym_ECCGTM1EAD0_BASE();
    
    /* init for variable IDSERSTCLR_PE1_BASE */
    _main_gen_init_sym_IDSERSTCLR_PE1_BASE();
    
    /* init for variable IDDERSTCLR_PE1_BASE */
    _main_gen_init_sym_IDDERSTCLR_PE1_BASE();
    
    /* init for variable IDSERSTR_PE1_BASE */
    _main_gen_init_sym_IDSERSTR_PE1_BASE();
    
    /* init for variable IDDERSTR_PE1_BASE */
    _main_gen_init_sym_IDDERSTR_PE1_BASE();
    
    /* init for variable ECM0ESSTC0_BASE */
    _main_gen_init_sym_ECM0ESSTC0_BASE();
    
    /* init for variable ECM0ESSTC1_BASE */
    _main_gen_init_sym_ECM0ESSTC1_BASE();
    
    /* init for variable DTSER2_BASE */
    _main_gen_init_sym_DTSER2_BASE();
    
    /* init for variable DTSERC_BASE */
    _main_gen_init_sym_DTSERC_BASE();
    
    /* init for variable LRSERSTCLR_PE1_BASE */
    _main_gen_init_sym_LRSERSTCLR_PE1_BASE();
    
    /* init for variable LRSERSTR_PE1_BASE */
    _main_gen_init_sym_LRSERSTR_PE1_BASE();
    
    /* init for variable UGRSERSTCLR_BASE */
    _main_gen_init_sym_UGRSERSTCLR_BASE();
    
    /* init for variable UGRSERSTR_BASE */
    _main_gen_init_sym_UGRSERSTR_BASE();
    
    /* init for variable RamMem_Pim_GlbRamFailrAdr */
    _main_gen_init_sym_RamMem_Pim_GlbRamFailrAdr();
    
    /* init for variable RamMem_Pim_GlbRamWordLineRead : useless (never read) */

    /* init for variable RamMem_Pim_LclRamFailrAdr */
    _main_gen_init_sym_RamMem_Pim_LclRamFailrAdr();
    
    /* init for variable RamMem_Pim_LclRamWordLineRead : useless (never read) */

    /* init for variable RamMem_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable RamMem_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable RamMem_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable RamMem_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable RamMem_Srv_SetNtcSts_Return */
    _main_gen_init_sym_RamMem_Srv_SetNtcSts_Return();
    
}
