#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__SINT32 pst_random_g_4;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__40 _main_gen_init_g40(void);

extern __PST__g__61 _main_gen_init_g61(void);

__PST__g__61 _main_gen_init_g61(void)
{
    __PST__g__61 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__40 _main_gen_init_g40(void)
{
    __PST__g__40 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ImcArbn_Cal_ImcArbnEcuIninTiOutThd(void)
{
    extern __PST__g__61 ImcArbn_Cal_ImcArbnEcuIninTiOutThd;
    
    /* initialization with random value */
    {
        ImcArbn_Cal_ImcArbnEcuIninTiOutThd = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_ImcArbn_Cal_ImcArbnFrmFltThd(void)
{
    extern __PST__g__40 ImcArbn_Cal_ImcArbnFrmFltThd;
    
    /* initialization with random value */
    {
        ImcArbn_Cal_ImcArbnFrmFltThd = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_FrmFltCntr100MilliSec(void)
{
    extern __PST__g__62 ImcArbn_Pim_FrmFltCntr100MilliSec;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 2; _main_gen_tmp_0_0++)
            {
                __PST__UINT32 _main_gen_tmp_0_1;
                
                for (_main_gen_tmp_0_1 = 0; _main_gen_tmp_0_1 < 2; _main_gen_tmp_0_1++)
                {
                    /* base type */
                    ImcArbn_Pim_FrmFltCntr100MilliSec[_main_gen_tmp_0_0][_main_gen_tmp_0_1] = pst_random_g_6;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_FrmFltCntr10MilliSec(void)
{
    extern __PST__g__62 ImcArbn_Pim_FrmFltCntr10MilliSec;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 2; _main_gen_tmp_1_0++)
            {
                __PST__UINT32 _main_gen_tmp_1_1;
                
                for (_main_gen_tmp_1_1 = 0; _main_gen_tmp_1_1 < 2; _main_gen_tmp_1_1++)
                {
                    /* base type */
                    ImcArbn_Pim_FrmFltCntr10MilliSec[_main_gen_tmp_1_0][_main_gen_tmp_1_1] = pst_random_g_6;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_FrmFltCntr2MilliSec(void)
{
    extern __PST__g__62 ImcArbn_Pim_FrmFltCntr2MilliSec;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 2; _main_gen_tmp_2_0++)
            {
                __PST__UINT32 _main_gen_tmp_2_1;
                
                for (_main_gen_tmp_2_1 = 0; _main_gen_tmp_2_1 < 2; _main_gen_tmp_2_1++)
                {
                    /* base type */
                    ImcArbn_Pim_FrmFltCntr2MilliSec[_main_gen_tmp_2_0][_main_gen_tmp_2_1] = pst_random_g_6;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_ImcEcuComStrtTiRef(void)
{
    extern __PST__UINT32 ImcArbn_Pim_ImcEcuComStrtTiRef;
    
    /* initialization with random value */
    {
        ImcArbn_Pim_ImcEcuComStrtTiRef = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_PrevRollgCntrRxd(void)
{
    extern __PST__g__64 ImcArbn_Pim_PrevRollgCntrRxd;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 256; _main_gen_tmp_3_0++)
            {
                /* base type */
                ImcArbn_Pim_PrevRollgCntrRxd[_main_gen_tmp_3_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_PrimSrcResyncCntr(void)
{
    extern __PST__g__64 ImcArbn_Pim_PrimSrcResyncCntr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 256; _main_gen_tmp_4_0++)
            {
                /* base type */
                ImcArbn_Pim_PrimSrcResyncCntr[_main_gen_tmp_4_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_PrimSrcRollgCntrResync(void)
{
    extern __PST__g__64 ImcArbn_Pim_PrimSrcRollgCntrResync;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 256; _main_gen_tmp_5_0++)
            {
                /* base type */
                ImcArbn_Pim_PrimSrcRollgCntrResync[_main_gen_tmp_5_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_PrimSrcRxBuf(void)
{
    extern __PST__g__65 ImcArbn_Pim_PrimSrcRxBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 256; _main_gen_tmp_6_0++)
            {
                __PST__UINT32 _main_gen_tmp_6_1;
                
                for (_main_gen_tmp_6_1 = 0; _main_gen_tmp_6_1 < 8; _main_gen_tmp_6_1++)
                {
                    /* base type */
                    ImcArbn_Pim_PrimSrcRxBuf[_main_gen_tmp_6_0][_main_gen_tmp_6_1] = pst_random_g_6;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_ResyncOnPrimActv(void)
{
    extern __PST__g__64 ImcArbn_Pim_ResyncOnPrimActv;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 256; _main_gen_tmp_7_0++)
            {
                /* base type */
                ImcArbn_Pim_ResyncOnPrimActv[_main_gen_tmp_7_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_ResyncOnSecdryActv(void)
{
    extern __PST__g__64 ImcArbn_Pim_ResyncOnSecdryActv;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 256; _main_gen_tmp_8_0++)
            {
                /* base type */
                ImcArbn_Pim_ResyncOnSecdryActv[_main_gen_tmp_8_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_RollgCntr(void)
{
    extern __PST__g__66 ImcArbn_Pim_RollgCntr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 3; _main_gen_tmp_9_0++)
            {
                /* base type */
                ImcArbn_Pim_RollgCntr[_main_gen_tmp_9_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_RxdSigData(void)
{
    extern __PST__g__67 ImcArbn_Pim_RxdSigData;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 8192; _main_gen_tmp_10_0++)
            {
                /* base type */
                ImcArbn_Pim_RxdSigData[_main_gen_tmp_10_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_RxdSigDataExtdSts(void)
{
    extern __PST__g__68 ImcArbn_Pim_RxdSigDataExtdSts;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 8192; _main_gen_tmp_11_0++)
            {
                /* base type */
                ImcArbn_Pim_RxdSigDataExtdSts[_main_gen_tmp_11_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_RxdSigDataSrc(void)
{
    extern __PST__g__68 ImcArbn_Pim_RxdSigDataSrc;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 8192; _main_gen_tmp_12_0++)
            {
                /* base type */
                ImcArbn_Pim_RxdSigDataSrc[_main_gen_tmp_12_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_SecdrySrcResyncCntr(void)
{
    extern __PST__g__64 ImcArbn_Pim_SecdrySrcResyncCntr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 256; _main_gen_tmp_13_0++)
            {
                /* base type */
                ImcArbn_Pim_SecdrySrcResyncCntr[_main_gen_tmp_13_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_SecdrySrcRollgCntrResync(void)
{
    extern __PST__g__64 ImcArbn_Pim_SecdrySrcRollgCntrResync;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 256; _main_gen_tmp_14_0++)
            {
                /* base type */
                ImcArbn_Pim_SecdrySrcRollgCntrResync[_main_gen_tmp_14_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_SecdrySrcRxBuf(void)
{
    extern __PST__g__65 ImcArbn_Pim_SecdrySrcRxBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 256; _main_gen_tmp_15_0++)
            {
                __PST__UINT32 _main_gen_tmp_15_1;
                
                for (_main_gen_tmp_15_1 = 0; _main_gen_tmp_15_1 < 8; _main_gen_tmp_15_1++)
                {
                    /* base type */
                    ImcArbn_Pim_SecdrySrcRxBuf[_main_gen_tmp_15_0][_main_gen_tmp_15_1] = pst_random_g_6;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_SigGroupDataSrc(void)
{
    extern __PST__g__64 ImcArbn_Pim_SigGroupDataSrc;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_16_0;
            
            for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < 256; _main_gen_tmp_16_0++)
            {
                /* base type */
                ImcArbn_Pim_SigGroupDataSrc[_main_gen_tmp_16_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_SigGroupMissCntr(void)
{
    extern __PST__g__64 ImcArbn_Pim_SigGroupMissCntr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_17_0;
            
            for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < 256; _main_gen_tmp_17_0++)
            {
                /* base type */
                ImcArbn_Pim_SigGroupMissCntr[_main_gen_tmp_17_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_SigGroupNeverRxd(void)
{
    extern __PST__g__64 ImcArbn_Pim_SigGroupNeverRxd;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_18_0;
            
            for (_main_gen_tmp_18_0 = 0; _main_gen_tmp_18_0 < 256; _main_gen_tmp_18_0++)
            {
                /* base type */
                ImcArbn_Pim_SigGroupNeverRxd[_main_gen_tmp_18_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_SigGroupSkipCntr(void)
{
    extern __PST__g__64 ImcArbn_Pim_SigGroupSkipCntr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_19_0;
            
            for (_main_gen_tmp_19_0 = 0; _main_gen_tmp_19_0 < 256; _main_gen_tmp_19_0++)
            {
                /* base type */
                ImcArbn_Pim_SigGroupSkipCntr[_main_gen_tmp_19_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Pim_TxBuf(void)
{
    extern __PST__g__65 ImcArbn_Pim_TxBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_20_0;
            
            for (_main_gen_tmp_20_0 = 0; _main_gen_tmp_20_0 < 256; _main_gen_tmp_20_0++)
            {
                __PST__UINT32 _main_gen_tmp_20_1;
                
                for (_main_gen_tmp_20_1 = 0; _main_gen_tmp_20_1 < 8; _main_gen_tmp_20_1++)
                {
                    /* base type */
                    ImcArbn_Pim_TxBuf[_main_gen_tmp_20_0][_main_gen_tmp_20_1] = pst_random_g_6;
                }
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Irv_IniTiOutChkCmpl(void)
{
    extern __PST__UINT8 ImcArbn_Irv_IniTiOutChkCmpl;
    
    /* initialization with random value */
    {
        ImcArbn_Irv_IniTiOutChkCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 ImcArbn_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        ImcArbn_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_f32_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcDataExtdSts_f32_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_f32_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_f32_Data(void)
{
    extern __PST__FLOAT32 ImcArbn_Cli_GetSigImcDataExtdSts_f32_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_f32_Data = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_f32_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_f32_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_f32_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_f32_DataSrc(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_f32_DataSrc;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_f32_DataSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_logl_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcDataExtdSts_logl_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_logl_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_logl_Data(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_logl_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_logl_Data = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_logl_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_logl_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_logl_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_logl_DataSrc(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_logl_DataSrc;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_logl_DataSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s08_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcDataExtdSts_s08_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s08_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s08_Data(void)
{
    extern __PST__SINT8 ImcArbn_Cli_GetSigImcDataExtdSts_s08_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s08_Data = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s08_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_s08_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s08_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s08_DataSrc(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_s08_DataSrc;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s08_DataSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s16_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcDataExtdSts_s16_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s16_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s16_Data(void)
{
    extern __PST__SINT16 ImcArbn_Cli_GetSigImcDataExtdSts_s16_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s16_Data = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s16_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_s16_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s16_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s16_DataSrc(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_s16_DataSrc;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s16_DataSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s32_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcDataExtdSts_s32_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s32_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s32_Data(void)
{
    extern __PST__SINT32 ImcArbn_Cli_GetSigImcDataExtdSts_s32_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s32_Data = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s32_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_s32_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s32_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s32_DataSrc(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_s32_DataSrc;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_s32_DataSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u08_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcDataExtdSts_u08_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u08_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u08_Data(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_u08_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u08_Data = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u08_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_u08_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u08_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u08_DataSrc(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_u08_DataSrc;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u08_DataSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u16_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcDataExtdSts_u16_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u16_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u16_Data(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcDataExtdSts_u16_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u16_Data = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u16_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_u16_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u16_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u16_DataSrc(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_u16_DataSrc;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u16_DataSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u32_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcDataExtdSts_u32_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u32_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u32_Data(void)
{
    extern __PST__UINT32 ImcArbn_Cli_GetSigImcDataExtdSts_u32_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u32_Data = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u32_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_u32_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u32_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u32_DataSrc(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcDataExtdSts_u32_DataSrc;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcDataExtdSts_u32_DataSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_f32_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcData_f32_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_f32_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_f32_Data(void)
{
    extern __PST__FLOAT32 ImcArbn_Cli_GetSigImcData_f32_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_f32_Data = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_f32_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_f32_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_f32_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_logl_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcData_logl_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_logl_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_logl_Data(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_logl_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_logl_Data = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_logl_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_logl_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_logl_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s08_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcData_s08_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_s08_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s08_Data(void)
{
    extern __PST__SINT8 ImcArbn_Cli_GetSigImcData_s08_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_s08_Data = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s08_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_s08_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_s08_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s16_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcData_s16_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_s16_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s16_Data(void)
{
    extern __PST__SINT16 ImcArbn_Cli_GetSigImcData_s16_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_s16_Data = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s16_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_s16_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_s16_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s32_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcData_s32_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_s32_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s32_Data(void)
{
    extern __PST__SINT32 ImcArbn_Cli_GetSigImcData_s32_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_s32_Data = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s32_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_s32_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_s32_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u08_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcData_u08_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_u08_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u08_Data(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_u08_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_u08_Data = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u08_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_u08_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_u08_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u16_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcData_u16_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_u16_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u16_Data(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcData_u16_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_u16_Data = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u16_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_u16_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_u16_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u32_SigId(void)
{
    extern __PST__UINT16 ImcArbn_Cli_GetSigImcData_u32_SigId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_u32_SigId = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u32_Data(void)
{
    extern __PST__UINT32 ImcArbn_Cli_GetSigImcData_u32_Data;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_u32_Data = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u32_Sts(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetSigImcData_u32_Sts;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetSigImcData_u32_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetTxRateGroup_RateGroup(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetTxRateGroup_RateGroup;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetTxRateGroup_RateGroup = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetTxRateGroup_Buf(void)
{
    extern __PST__g__80 ImcArbn_Cli_GetTxRateGroup_Buf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_21_0;
            
            for (_main_gen_tmp_21_0 = 0; _main_gen_tmp_21_0 < 2048; _main_gen_tmp_21_0++)
            {
                /* base type */
                ImcArbn_Cli_GetTxRateGroup_Buf[_main_gen_tmp_21_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetTxSigGroup_SigGroupId(void)
{
    extern __PST__UINT8 ImcArbn_Cli_GetTxSigGroup_SigGroupId;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_GetTxSigGroup_SigGroupId = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_GetTxSigGroup_Buf(void)
{
    extern __PST__g__44 ImcArbn_Cli_GetTxSigGroup_Buf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_22_0;
            
            for (_main_gen_tmp_22_0 = 0; _main_gen_tmp_22_0 < 8; _main_gen_tmp_22_0++)
            {
                /* base type */
                ImcArbn_Cli_GetTxSigGroup_Buf[_main_gen_tmp_22_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_SetRxSigGroup_SigGroup(void)
{
    extern __PST__UINT8 ImcArbn_Cli_SetRxSigGroup_SigGroup;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_SetRxSigGroup_SigGroup = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_SetRxSigGroup_DataSrc(void)
{
    extern __PST__UINT8 ImcArbn_Cli_SetRxSigGroup_DataSrc;
    
    /* initialization with random value */
    {
        ImcArbn_Cli_SetRxSigGroup_DataSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcArbn_Cli_SetRxSigGroup_Buf(void)
{
    extern __PST__g__44 ImcArbn_Cli_SetRxSigGroup_Buf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_23_0;
            
            for (_main_gen_tmp_23_0 = 0; _main_gen_tmp_23_0 < 8; _main_gen_tmp_23_0++)
            {
                /* base type */
                ImcArbn_Cli_SetRxSigGroup_Buf[_main_gen_tmp_23_0] = pst_random_g_6;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ImcArbn_Cal_ImcArbnEcuIninTiOutThd */
    _main_gen_init_sym_ImcArbn_Cal_ImcArbnEcuIninTiOutThd();
    
    /* init for variable ImcArbn_Cal_ImcArbnFrmFltThd */
    _main_gen_init_sym_ImcArbn_Cal_ImcArbnFrmFltThd();
    
    /* init for variable ImcArbn_Pim_FrmFltCntr100MilliSec */
    _main_gen_init_sym_ImcArbn_Pim_FrmFltCntr100MilliSec();
    
    /* init for variable ImcArbn_Pim_FrmFltCntr10MilliSec */
    _main_gen_init_sym_ImcArbn_Pim_FrmFltCntr10MilliSec();
    
    /* init for variable ImcArbn_Pim_FrmFltCntr2MilliSec */
    _main_gen_init_sym_ImcArbn_Pim_FrmFltCntr2MilliSec();
    
    /* init for variable ImcArbn_Pim_ImcEcuComStrtTiRef */
    _main_gen_init_sym_ImcArbn_Pim_ImcEcuComStrtTiRef();
    
    /* init for variable ImcArbn_Pim_PrevRollgCntrRxd */
    _main_gen_init_sym_ImcArbn_Pim_PrevRollgCntrRxd();
    
    /* init for variable ImcArbn_Pim_PrimSrcResyncCntr */
    _main_gen_init_sym_ImcArbn_Pim_PrimSrcResyncCntr();
    
    /* init for variable ImcArbn_Pim_PrimSrcRollgCntrResync */
    _main_gen_init_sym_ImcArbn_Pim_PrimSrcRollgCntrResync();
    
    /* init for variable ImcArbn_Pim_PrimSrcRxBuf */
    _main_gen_init_sym_ImcArbn_Pim_PrimSrcRxBuf();
    
    /* init for variable ImcArbn_Pim_ResyncOnPrimActv */
    _main_gen_init_sym_ImcArbn_Pim_ResyncOnPrimActv();
    
    /* init for variable ImcArbn_Pim_ResyncOnSecdryActv */
    _main_gen_init_sym_ImcArbn_Pim_ResyncOnSecdryActv();
    
    /* init for variable ImcArbn_Pim_RollgCntr */
    _main_gen_init_sym_ImcArbn_Pim_RollgCntr();
    
    /* init for variable ImcArbn_Pim_RxdSigData */
    _main_gen_init_sym_ImcArbn_Pim_RxdSigData();
    
    /* init for variable ImcArbn_Pim_RxdSigDataExtdSts */
    _main_gen_init_sym_ImcArbn_Pim_RxdSigDataExtdSts();
    
    /* init for variable ImcArbn_Pim_RxdSigDataSrc */
    _main_gen_init_sym_ImcArbn_Pim_RxdSigDataSrc();
    
    /* init for variable ImcArbn_Pim_SecdrySrcResyncCntr */
    _main_gen_init_sym_ImcArbn_Pim_SecdrySrcResyncCntr();
    
    /* init for variable ImcArbn_Pim_SecdrySrcRollgCntrResync */
    _main_gen_init_sym_ImcArbn_Pim_SecdrySrcRollgCntrResync();
    
    /* init for variable ImcArbn_Pim_SecdrySrcRxBuf */
    _main_gen_init_sym_ImcArbn_Pim_SecdrySrcRxBuf();
    
    /* init for variable ImcArbn_Pim_SigGroupDataSrc */
    _main_gen_init_sym_ImcArbn_Pim_SigGroupDataSrc();
    
    /* init for variable ImcArbn_Pim_SigGroupMissCntr */
    _main_gen_init_sym_ImcArbn_Pim_SigGroupMissCntr();
    
    /* init for variable ImcArbn_Pim_SigGroupNeverRxd */
    _main_gen_init_sym_ImcArbn_Pim_SigGroupNeverRxd();
    
    /* init for variable ImcArbn_Pim_SigGroupSkipCntr */
    _main_gen_init_sym_ImcArbn_Pim_SigGroupSkipCntr();
    
    /* init for variable ImcArbn_Pim_TxBuf */
    _main_gen_init_sym_ImcArbn_Pim_TxBuf();
    
    /* init for variable ImcArbn_Irv_IniTiOutChkCmpl */
    _main_gen_init_sym_ImcArbn_Irv_IniTiOutChkCmpl();
    
    /* init for variable ImcArbn_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable ImcArbn_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable ImcArbn_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable ImcArbn_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable ImcArbn_Srv_SetNtcSts_Return */
    _main_gen_init_sym_ImcArbn_Srv_SetNtcSts_Return();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_f32_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_f32_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_f32_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_f32_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_f32_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_f32_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_f32_DataSrc */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_f32_DataSrc();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_f32_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_logl_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_logl_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_logl_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_logl_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_logl_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_logl_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_logl_DataSrc */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_logl_DataSrc();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_logl_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s08_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s08_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s08_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s08_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s08_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s08_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s08_DataSrc */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s08_DataSrc();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s08_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s16_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s16_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s16_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s16_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s16_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s16_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s16_DataSrc */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s16_DataSrc();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s16_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s32_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s32_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s32_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s32_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s32_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s32_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s32_DataSrc */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_s32_DataSrc();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_s32_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u08_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u08_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u08_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u08_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u08_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u08_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u08_DataSrc */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u08_DataSrc();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u08_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u16_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u16_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u16_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u16_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u16_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u16_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u16_DataSrc */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u16_DataSrc();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u16_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u32_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u32_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u32_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u32_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u32_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u32_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u32_DataSrc */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcDataExtdSts_u32_DataSrc();
    
    /* init for variable ImcArbn_Cli_GetSigImcDataExtdSts_u32_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcData_f32_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_f32_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_f32_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_f32_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_f32_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_f32_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_f32_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcData_logl_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_logl_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_logl_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_logl_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_logl_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_logl_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_logl_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcData_s08_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s08_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_s08_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s08_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_s08_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s08_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_s08_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcData_s16_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s16_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_s16_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s16_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_s16_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s16_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_s16_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcData_s32_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s32_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_s32_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s32_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_s32_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_s32_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_s32_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcData_u08_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u08_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_u08_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u08_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_u08_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u08_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_u08_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcData_u16_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u16_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_u16_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u16_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_u16_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u16_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_u16_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetSigImcData_u32_SigId */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u32_SigId();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_u32_Data */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u32_Data();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_u32_Sts */
    _main_gen_init_sym_ImcArbn_Cli_GetSigImcData_u32_Sts();
    
    /* init for variable ImcArbn_Cli_GetSigImcData_u32_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetTxRateGroup_RateGroup */
    _main_gen_init_sym_ImcArbn_Cli_GetTxRateGroup_RateGroup();
    
    /* init for variable ImcArbn_Cli_GetTxRateGroup_Buf */
    _main_gen_init_sym_ImcArbn_Cli_GetTxRateGroup_Buf();
    
    /* init for variable ImcArbn_Cli_GetTxRateGroup_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_GetTxSigGroup_SigGroupId */
    _main_gen_init_sym_ImcArbn_Cli_GetTxSigGroup_SigGroupId();
    
    /* init for variable ImcArbn_Cli_GetTxSigGroup_Buf */
    _main_gen_init_sym_ImcArbn_Cli_GetTxSigGroup_Buf();
    
    /* init for variable ImcArbn_Cli_GetTxSigGroup_Return : useless (never read) */

    /* init for variable ImcArbn_Cli_SetRxSigGroup_SigGroup */
    _main_gen_init_sym_ImcArbn_Cli_SetRxSigGroup_SigGroup();
    
    /* init for variable ImcArbn_Cli_SetRxSigGroup_DataSrc */
    _main_gen_init_sym_ImcArbn_Cli_SetRxSigGroup_DataSrc();
    
    /* init for variable ImcArbn_Cli_SetRxSigGroup_Buf */
    _main_gen_init_sym_ImcArbn_Cli_SetRxSigGroup_Buf();
    
    /* init for variable ImcArbn_Cli_SetRxSigGroup_Return : useless (never read) */

}
