#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_GetImcTestSig1(void)
{
    extern __PST__UINT32 GetImcTestSig1(__PST__VOID);

    __PST__UINT32 __ret__;
    
    
    /* call it */
    __ret__ = GetImcTestSig1();
}

static void _main_gen_call_GetImcTestSig2(void)
{
    extern __PST__UINT32 GetImcTestSig2(__PST__VOID);

    __PST__UINT32 __ret__;
    
    
    /* call it */
    __ret__ = GetImcTestSig2();
}

static void _main_gen_call_GetImcTestSig3(void)
{
    extern __PST__UINT32 GetImcTestSig3(__PST__VOID);

    __PST__UINT32 __ret__;
    
    
    /* call it */
    __ret__ = GetImcTestSig3();
}

static void _main_gen_call_GetImcTestSig4(void)
{
    extern __PST__UINT32 GetImcTestSig4(__PST__VOID);

    __PST__UINT32 __ret__;
    
    
    /* call it */
    __ret__ = GetImcTestSig4();
}

static void _main_gen_call_GetImcTestSig5(void)
{
    extern __PST__UINT32 GetImcTestSig5(__PST__VOID);

    __PST__UINT32 __ret__;
    
    
    /* call it */
    __ret__ = GetImcTestSig5();
}

static void _main_gen_call_GetImcTestSig6(void)
{
    extern __PST__UINT32 GetImcTestSig6(__PST__VOID);

    __PST__UINT32 __ret__;
    
    
    /* call it */
    __ret__ = GetImcTestSig6();
}

static void _main_gen_call_GetImcTestSig8(void)
{
    extern __PST__UINT32 GetImcTestSig8(__PST__VOID);

    __PST__UINT32 __ret__;
    
    
    /* call it */
    __ret__ = GetImcTestSig8();
}

static void _main_gen_call_GetImcTestSig7(void)
{
    extern __PST__UINT32 GetImcTestSig7(__PST__VOID);

    __PST__UINT32 __ret__;
    
    
    /* call it */
    __ret__ = GetImcTestSig7();
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function GetImcTestSig1 */
        if (PST_TRUE())
        {
            _main_gen_call_GetImcTestSig1();
        }
        
        /* call of function GetImcTestSig2 */
        if (PST_TRUE())
        {
            _main_gen_call_GetImcTestSig2();
        }
        
        /* call of function GetImcTestSig3 */
        if (PST_TRUE())
        {
            _main_gen_call_GetImcTestSig3();
        }
        
        /* call of function GetImcTestSig4 */
        if (PST_TRUE())
        {
            _main_gen_call_GetImcTestSig4();
        }
        
        /* call of function GetImcTestSig5 */
        if (PST_TRUE())
        {
            _main_gen_call_GetImcTestSig5();
        }
        
        /* call of function GetImcTestSig6 */
        if (PST_TRUE())
        {
            _main_gen_call_GetImcTestSig6();
        }
        
        /* call of function GetImcTestSig8 */
        if (PST_TRUE())
        {
            _main_gen_call_GetImcTestSig8();
        }
        
        /* call of function GetImcTestSig7 */
        if (PST_TRUE())
        {
            _main_gen_call_GetImcTestSig7();
        }
        
        /* call of function Rte_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_Stub(__PST__VOID);

            Rte_Stub();
        }
        
    }
}
