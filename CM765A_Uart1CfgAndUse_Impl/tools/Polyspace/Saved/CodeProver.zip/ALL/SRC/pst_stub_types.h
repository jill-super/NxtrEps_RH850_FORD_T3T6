typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__UINT8 *__PST__g__17;
typedef __PST__UINT8 __PST__g__16(__PST__UINT8, __PST__g__17);
typedef const __PST__UINT8 __PST__g__20;
typedef __PST__g__20 *__PST__g__19;
typedef __PST__UINT8 __PST__g__18(__PST__UINT8, __PST__UINT8, __PST__g__19);
typedef __PST__UINT8 __PST__g__22[80];
typedef __PST__UINT8 __PST__g__23[144];
typedef __PST__FLOAT64 __PST__g__24(void);
typedef __PST__g__11 *__PST__g__25;
typedef volatile __PST__FLOAT64 __PST__g__26;
typedef __PST__SINT8 *__PST__g__28;
typedef volatile __PST__g__28 __PST__g__27;
typedef __PST__UINT8 __PST__g__29[2048];
typedef __PST__SINT32 __PST__g__211[1];
union __PST__g__31
  {
    __PST__g__211 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__31 __PST__g__30;
struct __PST__g__32
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__35
  {
    __PST__g__211 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__35 __PST__g__34;
struct __PST__g__36
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__38
  {
    __PST__g__211 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__38 __PST__g__37;
struct __PST__g__39
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__41
  {
    __PST__g__211 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__41 __PST__g__40;
struct __PST__g__42
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__44
  {
    __PST__g__211 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__44 __PST__g__43;
struct __PST__g__45
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__47
  {
    __PST__g__211 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__47 __PST__g__46;
struct __PST__g__48
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__50
  {
    __PST__g__211 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__50 __PST__g__49;
struct __PST__g__51
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
struct __PST__g__54
  {
    __PST__UINT32 _REQEN : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__53
  {
    struct __PST__g__54 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef volatile union __PST__g__53 __PST__g__52;
struct __PST__g__57
  {
    __PST__UINT32 _DRQC : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__56
  {
    struct __PST__g__57 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef volatile union __PST__g__56 __PST__g__55;
struct __PST__g__60
  {
    __PST__UINT32 _DRQS : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__59
  {
    struct __PST__g__60 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef volatile union __PST__g__59 __PST__g__58;
union __PST__g__62
  {
    __PST__g__211 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__62 __PST__g__61;
struct __PST__g__63
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
struct __PST__g__66
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 _LPRS : 3;
    __PST__UINT8 _NSPB : 4;
  };
union __PST__g__65
  {
    struct __PST__g__66 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__65 __PST__g__64;
struct __PST__g__71
  {
    __PST__UINT16 _BRP : 16;
  };
typedef __PST__SINT8 __PST__g__212[2];
union __PST__g__70
  {
    struct __PST__g__71 BIT;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__212 __pst_unused_field_2;
  };
typedef volatile union __PST__g__70 __PST__g__69;
typedef __PST__UINT8 __PST__g__72[2];
struct __PST__g__75
  {
    __PST__UINT8 _LMD : 2;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 _LRDNFS : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
  };
union __PST__g__74
  {
    struct __PST__g__75 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__74 __PST__g__73;
struct __PST__g__79
  {
    __PST__UINT8 _UBLS : 1;
    __PST__UINT8 _UBOS : 1;
    __PST__UINT8 _USBLS : 1;
    __PST__UINT8 _UPS : 2;
    __PST__UINT8 _URPS : 1;
    __PST__UINT8 _UTPS : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
  };
union __PST__g__78
  {
    struct __PST__g__79 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__78 __PST__g__77;
struct __PST__g__82
  {
    __PST__UINT8 _BERE : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 _OERE : 1;
    __PST__UINT8 _FERE : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__81
  {
    struct __PST__g__82 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__81 __PST__g__80;
struct __PST__g__85
  {
    __PST__UINT8 _OM0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__84
  {
    struct __PST__g__85 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__84 __PST__g__83;
struct __PST__g__88
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    const __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 _UTS : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__87
  {
    struct __PST__g__88 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__87 __PST__g__86;
struct __PST__g__92
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 _OER : 1;
    __PST__UINT8 _FER : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 _UPER : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__91
  {
    struct __PST__g__92 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__91 __PST__g__90;
struct __PST__g__95
  {
    __PST__UINT8 _MDL : 4;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
  };
union __PST__g__94
  {
    struct __PST__g__95 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__94 __PST__g__93;
struct __PST__g__98
  {
    __PST__UINT8 _UTOE : 1;
    __PST__UINT8 _UROE : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__97
  {
    struct __PST__g__98 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__97 __PST__g__96;
struct __PST__g__101
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 _UTIGTS : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__100
  {
    struct __PST__g__101 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__100 __PST__g__99;
typedef __PST__SINT16 __PST__g__213[1];
union __PST__g__103
  {
    __PST__g__213 __pst_unused_field_0;
    __PST__UINT16 UINT16;
    __PST__g__212 __pst_unused_field_2;
  };
typedef volatile union __PST__g__103 __PST__g__102;
struct __PST__g__104
  {
    __PST__UINT16 __pst_unused_field_0 : 9;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
  };
union __PST__g__108
  {
    __PST__g__213 __pst_unused_field_0;
    __PST__UINT16 UINT16;
    __PST__g__212 __pst_unused_field_2;
  };
typedef const union __PST__g__108 __PST__g__107;
typedef volatile __PST__g__107 __PST__g__106;
struct __PST__g__110
  {
    const __PST__UINT16 __pst_unused_field_0 : 9;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
  };
typedef const struct __PST__g__110 __PST__g__109;
struct __PST__g__114
  {
    __PST__UINT32 _MS_LM11 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__113
  {
    struct __PST__g__114 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef volatile union __PST__g__113 __PST__g__112;
typedef __PST__VOID __PST__g__115(__PST__SINT32);
typedef __PST__UINT8 __PST__g__116[8];
typedef __PST__g__29 *__PST__g__117;
typedef const __PST__UINT16 __PST__g__118;
typedef __PST__g__112 *__PST__g__119;
typedef volatile struct __PST__g__114 __PST__g__120;
typedef __PST__g__120 *__PST__g__121;
typedef __PST__g__83 *__PST__g__124;
typedef volatile struct __PST__g__85 __PST__g__125;
typedef __PST__g__125 *__PST__g__126;
typedef __PST__g__73 *__PST__g__127;
typedef volatile struct __PST__g__75 __PST__g__128;
typedef __PST__g__128 *__PST__g__129;
typedef __PST__g__77 *__PST__g__132;
typedef volatile struct __PST__g__79 __PST__g__133;
typedef __PST__g__133 *__PST__g__134;
typedef __PST__g__99 *__PST__g__135;
typedef volatile struct __PST__g__101 __PST__g__136;
typedef __PST__g__136 *__PST__g__137;
typedef __PST__g__80 *__PST__g__138;
typedef volatile struct __PST__g__82 __PST__g__139;
typedef __PST__g__139 *__PST__g__140;
typedef __PST__g__93 *__PST__g__141;
typedef volatile struct __PST__g__95 __PST__g__142;
typedef __PST__g__142 *__PST__g__143;
typedef __PST__g__64 *__PST__g__146;
typedef volatile struct __PST__g__66 __PST__g__147;
typedef __PST__g__147 *__PST__g__148;
typedef __PST__g__69 *__PST__g__151;
typedef volatile struct __PST__g__71 __PST__g__152;
typedef __PST__g__152 *__PST__g__153;
typedef volatile __PST__UINT16 __PST__g__154;
typedef __PST__g__154 *__PST__g__155;
typedef __PST__g__96 *__PST__g__156;
typedef volatile struct __PST__g__98 __PST__g__157;
typedef __PST__g__157 *__PST__g__158;
typedef __PST__g__15 *__PST__g__159;
typedef __PST__g__37 *__PST__g__160;
typedef volatile __PST__UINT32 __PST__g__161;
typedef __PST__g__161 *__PST__g__162;
typedef __PST__VOID __PST__g__163(__PST__UINT8);
typedef __PST__g__163 *__PST__g__164;
typedef __PST__g__116 *__PST__g__165;
typedef __PST__g__23 *__PST__g__166;
typedef __PST__UINT8 __PST__g__167(__PST__UINT8, __PST__UINT8);
typedef __PST__g__167 *__PST__g__168;
typedef __PST__g__18 *__PST__g__169;
typedef __PST__g__115 *__PST__g__170;
typedef __PST__g__16 *__PST__g__171;
typedef __PST__g__22 *__PST__g__172;
typedef __PST__g__61 *__PST__g__173;
typedef __PST__g__52 *__PST__g__174;
typedef volatile struct __PST__g__54 __PST__g__175;
typedef __PST__g__175 *__PST__g__176;
typedef __PST__g__30 *__PST__g__177;
typedef __PST__g__34 *__PST__g__178;
typedef __PST__g__102 *__PST__g__179;
typedef __PST__g__40 *__PST__g__180;
typedef __PST__g__55 *__PST__g__181;
typedef volatile struct __PST__g__57 __PST__g__182;
typedef __PST__g__182 *__PST__g__183;
typedef __PST__g__106 *__PST__g__184;
typedef volatile __PST__g__118 __PST__g__185;
typedef __PST__g__185 *__PST__g__186;
typedef __PST__g__43 *__PST__g__187;
typedef __PST__g__46 *__PST__g__188;
typedef __PST__g__49 *__PST__g__189;
typedef __PST__g__58 *__PST__g__190;
typedef volatile struct __PST__g__60 __PST__g__191;
typedef __PST__g__191 *__PST__g__192;
typedef __PST__g__86 *__PST__g__193;
typedef volatile struct __PST__g__88 __PST__g__194;
typedef __PST__g__194 *__PST__g__195;
typedef __PST__g__90 *__PST__g__196;
typedef volatile struct __PST__g__92 __PST__g__197;
typedef __PST__g__197 *__PST__g__198;
typedef volatile __PST__SINT32 __PST__g__199;
typedef __PST__SINT8 __PST__g__205(void);
typedef volatile __PST__SINT8 __PST__g__206;
typedef __PST__UINT8 __PST__g__207(void);
typedef volatile __PST__UINT8 __PST__g__208;
typedef __PST__SINT32 __PST__g__209(void);
typedef __PST__UINT32 __PST__g__210(void);
