typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__UINT8 *__PST__g__16;
typedef __PST__VOID __PST__g__15(__PST__g__16);
typedef __PST__VOID __PST__g__17(void);
typedef __PST__UINT32 *__PST__g__19;
typedef __PST__VOID __PST__g__18(__PST__g__19);
typedef __PST__VOID __PST__g__20(__PST__UINT32, __PST__UINT32);
typedef __PST__VOID __PST__g__21(__PST__UINT32);
typedef __PST__UINT8 __PST__g__22(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);
typedef __PST__UINT32 __PST__g__24[256];
typedef __PST__FLOAT64 __PST__g__25(void);
typedef __PST__g__11 *__PST__g__26;
typedef volatile __PST__FLOAT64 __PST__g__27;
typedef __PST__SINT8 *__PST__g__29;
typedef volatile __PST__g__29 __PST__g__28;
typedef __PST__SINT32 __PST__g__186[1];
union __PST__g__32
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__32 __PST__g__31;
typedef volatile __PST__g__31 __PST__g__30;
struct __PST__g__34
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__34 __PST__g__33;
typedef const __PST__UINT32 __PST__g__35;
union __PST__g__38
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__38 __PST__g__37;
typedef volatile __PST__g__37 __PST__g__36;
struct __PST__g__40
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__40 __PST__g__39;
union __PST__g__45
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__45 __PST__g__44;
typedef volatile __PST__g__44 __PST__g__43;
struct __PST__g__47
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__47 __PST__g__46;
typedef __PST__VOID __PST__g__48(__PST__SINT32);
typedef __PST__UINT8 __PST__g__49(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16, __PST__UINT32, __PST__UINT32, __PST__UINT32);
typedef __PST__SINT16 __PST__g__187[1];
union __PST__g__51
  {
    __PST__g__187 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
typedef volatile union __PST__g__51 __PST__g__50;
struct __PST__g__52
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_8 : 1;
    __PST__UINT16 __pst_unused_field_9 : 1;
    __PST__UINT16 __pst_unused_field_10 : 1;
    __PST__UINT16 __pst_unused_field_11 : 1;
    __PST__UINT16 __pst_unused_field_12 : 1;
    __PST__UINT16 __pst_unused_field_13 : 1;
    __PST__UINT16 __pst_unused_field_14 : 1;
    __PST__UINT16 __pst_unused_field_15 : 1;
  };
union __PST__g__54
  {
    __PST__g__187 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
typedef volatile union __PST__g__54 __PST__g__53;
struct __PST__g__55
  {
    __PST__UINT16 __pst_unused_field_0 : 4;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 7;
  };
union __PST__g__59
  {
    __PST__g__187 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
typedef volatile union __PST__g__59 __PST__g__58;
struct __PST__g__60
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 5;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_8 : 1;
    __PST__UINT16 __pst_unused_field_9 : 3;
  };
union __PST__g__64
  {
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__64 __PST__g__63;
union __PST__g__67
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__67 __PST__g__66;
typedef volatile __PST__g__66 __PST__g__65;
struct __PST__g__69
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    const __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    const __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__69 __PST__g__68;
union __PST__g__72
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__72 __PST__g__71;
typedef volatile __PST__g__71 __PST__g__70;
struct __PST__g__74
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__74 __PST__g__73;
union __PST__g__77
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__77 __PST__g__76;
typedef volatile __PST__g__76 __PST__g__75;
struct __PST__g__79
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    const __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__79 __PST__g__78;
union __PST__g__82
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__82 __PST__g__81;
typedef volatile __PST__g__81 __PST__g__80;
struct __PST__g__84
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__84 __PST__g__83;
union __PST__g__87
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__87 __PST__g__86;
typedef volatile __PST__g__86 __PST__g__85;
struct __PST__g__89
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__89 __PST__g__88;
typedef __PST__VOID __PST__g__90(__PST__SINT32, __PST__SINT32, __PST__UINT32);
typedef __PST__UINT32 __PST__g__91(__PST__SINT32, __PST__SINT32);
union __PST__g__93
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__93 __PST__g__92;
struct __PST__g__94
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    const __PST__UINT32 __pst_unused_field_16 : 1;
    const __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
union __PST__g__97
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__97 __PST__g__96;
typedef volatile __PST__g__96 __PST__g__95;
struct __PST__g__99
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__99 __PST__g__98;
union __PST__g__102
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__102 __PST__g__101;
typedef volatile __PST__g__101 __PST__g__100;
struct __PST__g__104
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__104 __PST__g__103;
union __PST__g__107
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__107 __PST__g__106;
typedef volatile __PST__g__106 __PST__g__105;
struct __PST__g__109
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    const __PST__UINT32 __pst_unused_field_12 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    const __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__109 __PST__g__108;
union __PST__g__112
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__112 __PST__g__111;
typedef volatile __PST__g__111 __PST__g__110;
struct __PST__g__114
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    const __PST__UINT32 __pst_unused_field_12 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__114 __PST__g__113;
union __PST__g__117
  {
    __PST__g__186 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__117 __PST__g__116;
typedef volatile __PST__g__116 __PST__g__115;
struct __PST__g__119
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    const __PST__UINT32 __pst_unused_field_15 : 1;
    const __PST__UINT32 __pst_unused_field_16 : 1;
    const __PST__UINT32 __pst_unused_field_17 : 1;
    const __PST__UINT32 __pst_unused_field_18 : 1;
    const __PST__UINT32 __pst_unused_field_19 : 1;
    const __PST__UINT32 __pst_unused_field_20 : 1;
    const __PST__UINT32 __pst_unused_field_21 : 1;
    const __PST__UINT32 __pst_unused_field_22 : 1;
    const __PST__UINT32 __pst_unused_field_23 : 1;
    const __PST__UINT32 __pst_unused_field_24 : 1;
    const __PST__UINT32 __pst_unused_field_25 : 1;
    const __PST__UINT32 __pst_unused_field_26 : 1;
    const __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    const __PST__UINT32 __pst_unused_field_30 : 1;
    const __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__119 __PST__g__118;
typedef __PST__SINT8 __PST__g__122[3];
typedef const struct __PST__g__125 __PST__g__124;
typedef __PST__g__124 *__PST__g__123;
struct __PST__g__121
  {
    __PST__UINT8 NrOfSupervisedEntities;
    __PST__g__122 __pst_unused_field___pstfiller1;
    __PST__g__123 WdgMSupervisedEntityRef;
  };
typedef const struct __PST__g__121 __PST__g__120;
typedef struct __PST__g__127 *__PST__g__126;
struct __PST__g__125
  {
    __PST__UINT8 __pst_unused_field_0;
    __PST__g__122 __pst_unused_field___pstfiller1;
    __PST__g__126 EntityStatusGRef;
  };
struct __PST__g__127
  {
    __PST__UINT16 FailedSupervisionRefCycles;
    __PST__UINT16 DeadlineViolationCnt;
    __PST__UINT16 ProgramFlowViolationCnt;
  };
typedef __PST__g__24 *__PST__g__128;
typedef __PST__UINT8 __PST__g__129(__PST__UINT32);
typedef __PST__g__129 *__PST__g__130;
typedef __PST__g__36 *__PST__g__131;
typedef volatile __PST__g__35 __PST__g__132;
typedef __PST__g__132 *__PST__g__133;
typedef __PST__g__43 *__PST__g__134;
typedef __PST__g__30 *__PST__g__135;
typedef __PST__g__22 *__PST__g__136;
typedef __PST__g__48 *__PST__g__137;
typedef __PST__g__17 *__PST__g__138;
typedef __PST__g__49 *__PST__g__139;
typedef volatile __PST__UINT32 __PST__g__141;
typedef __PST__g__141 *__PST__g__140;
typedef __PST__g__50 *__PST__g__142;
typedef volatile __PST__UINT16 __PST__g__143;
typedef __PST__g__143 *__PST__g__144;
typedef __PST__g__63 *__PST__g__145;
typedef __PST__g__91 *__PST__g__146;
typedef __PST__g__53 *__PST__g__147;
typedef __PST__g__58 *__PST__g__148;
typedef __PST__g__65 *__PST__g__149;
typedef __PST__g__85 *__PST__g__150;
typedef __PST__g__70 *__PST__g__151;
typedef __PST__g__80 *__PST__g__152;
typedef __PST__g__75 *__PST__g__153;
typedef __PST__g__20 *__PST__g__154;
typedef __PST__g__90 *__PST__g__155;
typedef __PST__g__120 *__PST__g__156;
typedef const __PST__UINT8 __PST__g__157;
typedef __PST__g__157 *__PST__g__158;
typedef const __PST__g__123 __PST__g__159;
typedef __PST__g__159 *__PST__g__160;
typedef const __PST__g__126 __PST__g__161;
typedef __PST__g__161 *__PST__g__162;
typedef __PST__UINT16 *__PST__g__163;
typedef __PST__g__92 *__PST__g__164;
typedef __PST__g__95 *__PST__g__165;
typedef __PST__g__100 *__PST__g__166;
typedef __PST__g__115 *__PST__g__167;
typedef __PST__g__105 *__PST__g__168;
typedef __PST__g__110 *__PST__g__169;
typedef __PST__SINT32 __PST__g__170();
typedef __PST__g__170 *__PST__g__171;
typedef __PST__g__15 *__PST__g__172;
typedef __PST__g__18 *__PST__g__173;
typedef volatile __PST__SINT32 __PST__g__174;
typedef __PST__SINT8 __PST__g__180(void);
typedef volatile __PST__SINT8 __PST__g__181;
typedef __PST__UINT8 __PST__g__182(void);
typedef volatile __PST__UINT8 __PST__g__183;
typedef __PST__SINT32 __PST__g__184(void);
typedef __PST__UINT32 __PST__g__185(void);
