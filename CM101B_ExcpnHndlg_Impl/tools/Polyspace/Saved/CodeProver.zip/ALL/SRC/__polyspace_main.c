#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_SetMcuDiagcIdnData(void)
{
    extern __PST__VOID SetMcuDiagcIdnData(__PST__UINT32, __PST__UINT32);

    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    
    /* call it */
    SetMcuDiagcIdnData(__arg__0, __arg__1);
}

static void _main_gen_call_GetMcuDiagcIdnData(void)
{
    extern __PST__VOID GetMcuDiagcIdnData(__PST__g__19);

    __PST__g__19 __arg__0;
    
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g8();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    GetMcuDiagcIdnData(__arg__0);
}

static void _main_gen_call_ProcUkwnExcpnErr(void)
{
    extern __PST__VOID ProcUkwnExcpnErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcUkwnExcpnErr(__arg__0);
}

static void _main_gen_call_ProcMpuExcpnErr(void)
{
    extern __PST__VOID ProcMpuExcpnErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcMpuExcpnErr(__arg__0);
}

static void _main_gen_call_ProcPrvlgdInstrExcpnErr(void)
{
    extern __PST__VOID ProcPrvlgdInstrExcpnErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcPrvlgdInstrExcpnErr(__arg__0);
}

static void _main_gen_call_ProcPrmntOsErr(void)
{
    extern __PST__VOID ProcPrmntOsErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcPrmntOsErr(__arg__0);
}

static void _main_gen_call_ProcNonCritOsErr(void)
{
    extern __PST__VOID ProcNonCritOsErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcNonCritOsErr(__arg__0);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function FeNmiEcmMstChkrErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiEcmMstChkrErr(__PST__VOID);

            FeNmiEcmMstChkrErr();
        }
        
        /* call of function FeNmiWdgErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiWdgErr(__PST__VOID);

            FeNmiWdgErr();
        }
        
        /* call of function SetMcuDiagcIdnData */
        if (PST_TRUE())
        {
            _main_gen_call_SetMcuDiagcIdnData();
        }
        
        /* call of function GetMcuDiagcIdnData */
        if (PST_TRUE())
        {
            _main_gen_call_GetMcuDiagcIdnData();
        }
        
        /* call of function ProcUkwnExcpnErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcUkwnExcpnErr();
        }
        
        /* call of function ProcMpuExcpnErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcMpuExcpnErr();
        }
        
        /* call of function ProcPrvlgdInstrExcpnErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcPrvlgdInstrExcpnErr();
        }
        
        /* call of function ProcPrmntOsErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcPrmntOsErr();
        }
        
        /* call of function ProcNonCritOsErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcNonCritOsErr();
        }
        
        /* call of function FeNmiDmaLockStepErrOrGblRamWrBufErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiDmaLockStepErrOrGblRamWrBufErr(__PST__VOID);

            FeNmiDmaLockStepErrOrGblRamWrBufErr();
        }
        
        /* call of function FeNmiBusBrdgErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiBusBrdgErr(__PST__VOID);

            FeNmiBusBrdgErr();
        }
        
        /* call of function FeNmiProcrLockStepErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiProcrLockStepErr(__PST__VOID);

            FeNmiProcrLockStepErr();
        }
        
        /* call of function FeNmiClkMonr0RtErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr0RtErr(__PST__VOID);

            FeNmiClkMonr0RtErr();
        }
        
        /* call of function FeNmiClkMonr1RtErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr1RtErr(__PST__VOID);

            FeNmiClkMonr1RtErr();
        }
        
        /* call of function FeNmiClkMonr2RtErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr2RtErr(__PST__VOID);

            FeNmiClkMonr2RtErr();
        }
        
        /* call of function FeNmiClkMonr3RtErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr3RtErr(__PST__VOID);

            FeNmiClkMonr3RtErr();
        }
        
        /* call of function FeNmiClkMonr5RtErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr5RtErr(__PST__VOID);

            FeNmiClkMonr5RtErr();
        }
        
        /* call of function FeNmiGtmRamDblBitEccErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiGtmRamDblBitEccErr(__PST__VOID);

            FeNmiGtmRamDblBitEccErr();
        }
        
        /* call of function FeNmiBusSngBitEccErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiBusSngBitEccErr(__PST__VOID);

            FeNmiBusSngBitEccErr();
        }
        
        /* call of function FeNmiLclRamEccAdrOvfErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiLclRamEccAdrOvfErr(__PST__VOID);

            FeNmiLclRamEccAdrOvfErr();
        }
        
        /* call of function FeNmiGlbRamEccAdrOvfErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiGlbRamEccAdrOvfErr(__PST__VOID);

            FeNmiGlbRamEccAdrOvfErr();
        }
        
        /* call of function FeNmiCodFlsEccAdrOvfErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiCodFlsEccAdrOvfErr(__PST__VOID);

            FeNmiCodFlsEccAdrOvfErr();
        }
        
        /* call of function FeNmiPrphlRamEccAdrOvfErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiPrphlRamEccAdrOvfErr(__PST__VOID);

            FeNmiPrphlRamEccAdrOvfErr();
        }
        
        /* call of function FeNmiDtsRamDblBitEccErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiDtsRamDblBitEccErr(__PST__VOID);

            FeNmiDtsRamDblBitEccErr();
        }
        
        /* call of function FeNmiPegErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiPegErr(__PST__VOID);

            FeNmiPegErr();
        }
        
        /* call of function FeNmiGblRamIllglAcsByProcr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiGblRamIllglAcsByProcr(__PST__VOID);

            FeNmiGblRamIllglAcsByProcr();
        }
        
        /* call of function FeNmiCodFlsIllglAcsBySysBus */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiCodFlsIllglAcsBySysBus(__PST__VOID);

            FeNmiCodFlsIllglAcsBySysBus();
        }
        
        /* call of function FeNmiGblRamIllglAcsBySysBus */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiGblRamIllglAcsBySysBus(__PST__VOID);

            FeNmiGblRamIllglAcsBySysBus();
        }
        
        /* call of function FeNmiResdAreaIllglAcsByHiSpdBus */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiResdAreaIllglAcsByHiSpdBus(__PST__VOID);

            FeNmiResdAreaIllglAcsByHiSpdBus();
        }
        
        /* call of function FeNmiDmaTrfErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiDmaTrfErr(__PST__VOID);

            FeNmiDmaTrfErr();
        }
        
        /* call of function FeNmiDmaIllglAcsErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiDmaIllglAcsErr(__PST__VOID);

            FeNmiDmaIllglAcsErr();
        }
        
        /* call of function FeNmiFlsSeqErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiFlsSeqErr(__PST__VOID);

            FeNmiFlsSeqErr();
        }
        
        /* call of function FeNmiModErrUsrModInactv */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiModErrUsrModInactv(__PST__VOID);

            FeNmiModErrUsrModInactv();
        }
        
        /* call of function FeNmiModErrProgmModActv */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiModErrProgmModActv(__PST__VOID);

            FeNmiModErrProgmModActv();
        }
        
        /* call of function FeNmiModErrDbgActv */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiModErrDbgActv(__PST__VOID);

            FeNmiModErrDbgActv();
        }
        
        /* call of function FeNmiModErrTestModActv */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiModErrTestModActv(__PST__VOID);

            FeNmiModErrTestModActv();
        }
        
        /* call of function Rte_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_Stub(__PST__VOID);

            Rte_Stub();
        }
        
    }
}
