#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Call_CDD_ExcpnHndlg_SetNtcStsAndSnpshtData_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_CDD_ExcpnHndlg_SetNtcStsAndSnpshtData_Oper"


__PST__UINT8 Rte_Call_CDD_ExcpnHndlg_SetNtcStsAndSnpshtData_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3, __PST__UINT32 P_4, __PST__UINT32 P_5, __PST__UINT32 P_6)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * __LDSR
 */

#pragma POLYSPACE_POLYMORPHIC "__LDSR"


__PST__VOID __LDSR(__PST__SINT32 P_0, __PST__SINT32 P_1, __PST__UINT32 P_2)
{
    /* function is pure */

    return;
}

/*
 * __STSR
 */

#pragma POLYSPACE_POLYMORPHIC "__STSR"


__PST__UINT32 __STSR(__PST__SINT32 P_0, __PST__SINT32 P_1)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * NxtrSwRstFromExcpn
 */

#pragma POLYSPACE_POLYMORPHIC "NxtrSwRstFromExcpn"


__PST__VOID NxtrSwRstFromExcpn(__PST__UINT32 P_0, __PST__UINT32 P_1)
{
    /* function is pure */

    return;
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

