#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__127 _main_gen_init_g127(void);

extern struct __PST__g__125 _main_gen_init_g125(void);

extern __PST__g__120 _main_gen_init_g120(void);

extern __PST__g__115 _main_gen_init_g115(void);

extern __PST__g__110 _main_gen_init_g110(void);

extern __PST__g__105 _main_gen_init_g105(void);

extern __PST__g__100 _main_gen_init_g100(void);

extern __PST__g__95 _main_gen_init_g95(void);

extern __PST__g__92 _main_gen_init_g92(void);

extern __PST__g__85 _main_gen_init_g85(void);

extern __PST__g__80 _main_gen_init_g80(void);

extern __PST__g__75 _main_gen_init_g75(void);

extern __PST__g__70 _main_gen_init_g70(void);

extern __PST__g__65 _main_gen_init_g65(void);

extern __PST__g__63 _main_gen_init_g63(void);

extern __PST__g__58 _main_gen_init_g58(void);

extern __PST__g__53 _main_gen_init_g53(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__g__50 _main_gen_init_g50(void);

extern __PST__g__43 _main_gen_init_g43(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__30 _main_gen_init_g30(void);

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__43 _main_gen_init_g43(void)
{
    __PST__g__43 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__50 _main_gen_init_g50(void)
{
    __PST__g__50 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__53 _main_gen_init_g53(void)
{
    __PST__g__53 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__58 _main_gen_init_g58(void)
{
    __PST__g__58 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__63 _main_gen_init_g63(void)
{
    __PST__g__63 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__65 _main_gen_init_g65(void)
{
    __PST__g__65 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__70 _main_gen_init_g70(void)
{
    __PST__g__70 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__75 _main_gen_init_g75(void)
{
    __PST__g__75 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__80 _main_gen_init_g80(void)
{
    __PST__g__80 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__85 _main_gen_init_g85(void)
{
    __PST__g__85 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__92 _main_gen_init_g92(void)
{
    __PST__g__92 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__95 _main_gen_init_g95(void)
{
    __PST__g__95 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__100 _main_gen_init_g100(void)
{
    __PST__g__100 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__105 _main_gen_init_g105(void)
{
    __PST__g__105 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__110 _main_gen_init_g110(void)
{
    __PST__g__110 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__115 _main_gen_init_g115(void)
{
    __PST__g__115 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__127 _main_gen_init_g127(void)
{
    static struct __PST__g__127 x;
    /* struct/union type */
    x.FailedSupervisionRefCycles = _main_gen_init_g7();
    x.DeadlineViolationCnt = _main_gen_init_g7();
    x.ProgramFlowViolationCnt = _main_gen_init_g7();
    return x;
}

struct __PST__g__125 _main_gen_init_g125(void)
{
    static struct __PST__g__125 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__127 _main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__127)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct __PST__g__127); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g127();
        }
        x.EntityStatusGRef = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__127) / 2];
    }
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__120 _main_gen_init_g120(void)
{
    __PST__g__120 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__125 _main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__125)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(struct __PST__g__125); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g125();
        }
        x.WdgMSupervisedEntityRef = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__125) / 2];
    }
    x.NrOfSupervisedEntities = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MBISTFTAGL1_BASE(void)
{
    extern __PST__g__30 MBISTFTAGL1_BASE;
    
    /* initialization with random value */
    {
        MBISTFTAGL1_BASE = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_BSEQ0ST_BASE(void)
{
    extern __PST__g__36 BSEQ0ST_BASE;
    
    /* initialization with random value */
    {
        BSEQ0ST_BASE = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_BSEQ0STB_BASE(void)
{
    extern __PST__g__43 BSEQ0STB_BASE;
    
    /* initialization with random value */
    {
        BSEQ0STB_BASE = _main_gen_init_g43();
    }
}

static void _main_gen_init_sym_SEGFLAG_BASE(void)
{
    extern __PST__g__50 SEGFLAG_BASE;
    
    /* initialization with random value */
    {
        SEGFLAG_BASE = _main_gen_init_g50();
    }
}

static void _main_gen_init_sym_SEGTYPE_BASE(void)
{
    extern __PST__g__53 SEGTYPE_BASE;
    
    /* initialization with random value */
    {
        SEGTYPE_BASE = _main_gen_init_g53();
    }
}

static void _main_gen_init_sym_SEGSIDE_BASE(void)
{
    extern __PST__g__58 SEGSIDE_BASE;
    
    /* initialization with random value */
    {
        SEGSIDE_BASE = _main_gen_init_g58();
    }
}

static void _main_gen_init_sym_SEGADDR_BASE(void)
{
    extern __PST__g__63 SEGADDR_BASE;
    
    /* initialization with random value */
    {
        SEGADDR_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_LRDERSTR_PE1_BASE(void)
{
    extern __PST__g__65 LRDERSTR_PE1_BASE;
    
    /* initialization with random value */
    {
        LRDERSTR_PE1_BASE = _main_gen_init_g65();
    }
}

static void _main_gen_init_sym_ERRSLVSTAT_PFSS0_BASE(void)
{
    extern __PST__g__70 ERRSLVSTAT_PFSS0_BASE;
    
    /* initialization with random value */
    {
        ERRSLVSTAT_PFSS0_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ERRSLVSTAT_PFSS1_BASE(void)
{
    extern __PST__g__70 ERRSLVSTAT_PFSS1_BASE;
    
    /* initialization with random value */
    {
        ERRSLVSTAT_PFSS1_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ERRSLV1STAT_BASE(void)
{
    extern __PST__g__70 ERRSLV1STAT_BASE;
    
    /* initialization with random value */
    {
        ERRSLV1STAT_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ERRSLV2STAT_BASE(void)
{
    extern __PST__g__70 ERRSLV2STAT_BASE;
    
    /* initialization with random value */
    {
        ERRSLV2STAT_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ERRSLV3STAT_BASE(void)
{
    extern __PST__g__70 ERRSLV3STAT_BASE;
    
    /* initialization with random value */
    {
        ERRSLV3STAT_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ERRSLV4STAT_BASE(void)
{
    extern __PST__g__70 ERRSLV4STAT_BASE;
    
    /* initialization with random value */
    {
        ERRSLV4STAT_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_APERSTR_PFSS_BASE(void)
{
    extern __PST__g__75 APERSTR_PFSS_BASE;
    
    /* initialization with random value */
    {
        APERSTR_PFSS_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_ERRSLVF0STAT_BASE(void)
{
    extern __PST__g__70 ERRSLVF0STAT_BASE;
    
    /* initialization with random value */
    {
        ERRSLVF0STAT_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ERRSLVF1STAT_BASE(void)
{
    extern __PST__g__70 ERRSLVF1STAT_BASE;
    
    /* initialization with random value */
    {
        ERRSLVF1STAT_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ERRSLVE0STAT_BASE(void)
{
    extern __PST__g__70 ERRSLVE0STAT_BASE;
    
    /* initialization with random value */
    {
        ERRSLVE0STAT_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ERRSLVE1STAT_BASE(void)
{
    extern __PST__g__70 ERRSLVE1STAT_BASE;
    
    /* initialization with random value */
    {
        ERRSLVE1STAT_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ERRSLVM0STAT_BASE(void)
{
    extern __PST__g__70 ERRSLVM0STAT_BASE;
    
    /* initialization with random value */
    {
        ERRSLVM0STAT_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_MGDCFSTAT_VCI2CFB_BASE(void)
{
    extern __PST__g__70 MGDCFSTAT_VCI2CFB_BASE;
    
    /* initialization with random value */
    {
        MGDCFSTAT_VCI2CFB_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_MGDCFSTAT_PE1_BASE(void)
{
    extern __PST__g__70 MGDCFSTAT_PE1_BASE;
    
    /* initialization with random value */
    {
        MGDCFSTAT_PE1_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_UCFDERSTR_BASE(void)
{
    extern __PST__g__80 UCFDERSTR_BASE;
    
    /* initialization with random value */
    {
        UCFDERSTR_BASE = _main_gen_init_g80();
    }
}

static void _main_gen_init_sym_MGDGRSSTAT_VCI2GRAM_BASE(void)
{
    extern __PST__g__70 MGDGRSSTAT_VCI2GRAM_BASE;
    
    /* initialization with random value */
    {
        MGDGRSSTAT_VCI2GRAM_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_MGDGRSSTAT_PE1_BASE(void)
{
    extern __PST__g__70 MGDGRSSTAT_PE1_BASE;
    
    /* initialization with random value */
    {
        MGDGRSSTAT_PE1_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_MGDGRSSTAT_AXI2GRAM_BASE(void)
{
    extern __PST__g__70 MGDGRSSTAT_AXI2GRAM_BASE;
    
    /* initialization with random value */
    {
        MGDGRSSTAT_AXI2GRAM_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_UGRDERSTR_BASE(void)
{
    extern __PST__g__85 UGRDERSTR_BASE;
    
    /* initialization with random value */
    {
        UGRDERSTR_BASE = _main_gen_init_g85();
    }
}

static void _main_gen_init_sym_PGERRSTAT_PE1_BASE(void)
{
    extern __PST__g__70 PGERRSTAT_PE1_BASE;
    
    /* initialization with random value */
    {
        PGERRSTAT_PE1_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_ECCGTM0CTL_BASE(void)
{
    extern __PST__g__92 ECCGTM0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCGTM0CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_ECCGTM1CTL_BASE(void)
{
    extern __PST__g__92 ECCGTM1CTL_BASE;
    
    /* initialization with random value */
    {
        ECCGTM1CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_LROVFSTR_PE1_BASE(void)
{
    extern __PST__g__95 LROVFSTR_PE1_BASE;
    
    /* initialization with random value */
    {
        LROVFSTR_PE1_BASE = _main_gen_init_g95();
    }
}

static void _main_gen_init_sym_UGROVFSTR_BASE(void)
{
    extern __PST__g__100 UGROVFSTR_BASE;
    
    /* initialization with random value */
    {
        UGROVFSTR_BASE = _main_gen_init_g100();
    }
}

static void _main_gen_init_sym_UCFOVFSTR_BASE(void)
{
    extern __PST__g__100 UCFOVFSTR_BASE;
    
    /* initialization with random value */
    {
        UCFOVFSTR_BASE = _main_gen_init_g100();
    }
}

static void _main_gen_init_sym_ECCFLX0CTL_BASE(void)
{
    extern __PST__g__92 ECCFLX0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCFLX0CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_ECCFLX0T0CTL_BASE(void)
{
    extern __PST__g__92 ECCFLX0T0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCFLX0T0CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_ECCFLX0T1CTL_BASE(void)
{
    extern __PST__g__92 ECCFLX0T1CTL_BASE;
    
    /* initialization with random value */
    {
        ECCFLX0T1CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_ECCCSIH0CTL_BASE(void)
{
    extern __PST__g__92 ECCCSIH0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH0CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_ECCCSIH1CTL_BASE(void)
{
    extern __PST__g__92 ECCCSIH1CTL_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH1CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_ECCCSIH2CTL_BASE(void)
{
    extern __PST__g__92 ECCCSIH2CTL_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH2CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_ECCCSIH3CTL_BASE(void)
{
    extern __PST__g__92 ECCCSIH3CTL_BASE;
    
    /* initialization with random value */
    {
        ECCCSIH3CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_DMACER_BASE(void)
{
    extern __PST__g__105 DMACER_BASE;
    
    /* initialization with random value */
    {
        DMACER_BASE = _main_gen_init_g105();
    }
}

static void _main_gen_init_sym_DTSER1_BASE(void)
{
    extern __PST__g__110 DTSER1_BASE;
    
    /* initialization with random value */
    {
        DTSER1_BASE = _main_gen_init_g110();
    }
}

static void _main_gen_init_sym_DTSER2_BASE(void)
{
    extern __PST__g__115 DTSER2_BASE;
    
    /* initialization with random value */
    {
        DTSER2_BASE = _main_gen_init_g115();
    }
}

static void _main_gen_init_sym_ECCTTCAN0CTL_BASE(void)
{
    extern __PST__g__92 ECCTTCAN0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCTTCAN0CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_ECCMCAN0CTL_BASE(void)
{
    extern __PST__g__92 ECCMCAN0CTL_BASE;
    
    /* initialization with random value */
    {
        ECCMCAN0CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_ECCMCAN1CTL_BASE(void)
{
    extern __PST__g__92 ECCMCAN1CTL_BASE;
    
    /* initialization with random value */
    {
        ECCMCAN1CTL_BASE = _main_gen_init_g92();
    }
}

static void _main_gen_init_sym_WdgMConfig_Mode0(void)
{
    extern __PST__g__120 WdgMConfig_Mode0;
    
    /* initialization with random value */
    {
        WdgMConfig_Mode0 = _main_gen_init_g120();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 ExcpnHndlg_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest(void)
{
    extern __PST__UINT8 ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1(void)
{
    extern __PST__UINT32 ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcNr(void)
{
    extern __PST__UINT16 ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcNr;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcStInfo(void)
{
    extern __PST__UINT8 ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcStInfo;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcSts(void)
{
    extern __PST__UINT8 ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcSts;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_DebStep(void)
{
    extern __PST__UINT16 ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_DebStep;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData0(void)
{
    extern __PST__UINT32 ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData1(void)
{
    extern __PST__UINT32 ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData2(void)
{
    extern __PST__UINT32 ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData2 = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MBISTFTAGL1_BASE */
    _main_gen_init_sym_MBISTFTAGL1_BASE();
    
    /* init for variable BSEQ0ST_BASE */
    _main_gen_init_sym_BSEQ0ST_BASE();
    
    /* init for variable BSEQ0STB_BASE */
    _main_gen_init_sym_BSEQ0STB_BASE();
    
    /* init for variable SEGFLAG_BASE */
    _main_gen_init_sym_SEGFLAG_BASE();
    
    /* init for variable SEGTYPE_BASE */
    _main_gen_init_sym_SEGTYPE_BASE();
    
    /* init for variable SEGSIDE_BASE */
    _main_gen_init_sym_SEGSIDE_BASE();
    
    /* init for variable SEGADDR_BASE */
    _main_gen_init_sym_SEGADDR_BASE();
    
    /* init for variable LRDERSTR_PE1_BASE */
    _main_gen_init_sym_LRDERSTR_PE1_BASE();
    
    /* init for variable ERRSLVSTAT_PFSS0_BASE */
    _main_gen_init_sym_ERRSLVSTAT_PFSS0_BASE();
    
    /* init for variable ERRSLVSTAT_PFSS1_BASE */
    _main_gen_init_sym_ERRSLVSTAT_PFSS1_BASE();
    
    /* init for variable ERRSLV1STAT_BASE */
    _main_gen_init_sym_ERRSLV1STAT_BASE();
    
    /* init for variable ERRSLV2STAT_BASE */
    _main_gen_init_sym_ERRSLV2STAT_BASE();
    
    /* init for variable ERRSLV3STAT_BASE */
    _main_gen_init_sym_ERRSLV3STAT_BASE();
    
    /* init for variable ERRSLV4STAT_BASE */
    _main_gen_init_sym_ERRSLV4STAT_BASE();
    
    /* init for variable APERSTR_PFSS_BASE */
    _main_gen_init_sym_APERSTR_PFSS_BASE();
    
    /* init for variable ERRSLVF0STAT_BASE */
    _main_gen_init_sym_ERRSLVF0STAT_BASE();
    
    /* init for variable ERRSLVF1STAT_BASE */
    _main_gen_init_sym_ERRSLVF1STAT_BASE();
    
    /* init for variable ERRSLVE0STAT_BASE */
    _main_gen_init_sym_ERRSLVE0STAT_BASE();
    
    /* init for variable ERRSLVE1STAT_BASE */
    _main_gen_init_sym_ERRSLVE1STAT_BASE();
    
    /* init for variable ERRSLVM0STAT_BASE */
    _main_gen_init_sym_ERRSLVM0STAT_BASE();
    
    /* init for variable MGDCFSTAT_VCI2CFB_BASE */
    _main_gen_init_sym_MGDCFSTAT_VCI2CFB_BASE();
    
    /* init for variable MGDCFSTAT_PE1_BASE */
    _main_gen_init_sym_MGDCFSTAT_PE1_BASE();
    
    /* init for variable UCFDERSTR_BASE */
    _main_gen_init_sym_UCFDERSTR_BASE();
    
    /* init for variable MGDGRSSTAT_VCI2GRAM_BASE */
    _main_gen_init_sym_MGDGRSSTAT_VCI2GRAM_BASE();
    
    /* init for variable MGDGRSSTAT_PE1_BASE */
    _main_gen_init_sym_MGDGRSSTAT_PE1_BASE();
    
    /* init for variable MGDGRSSTAT_AXI2GRAM_BASE */
    _main_gen_init_sym_MGDGRSSTAT_AXI2GRAM_BASE();
    
    /* init for variable UGRDERSTR_BASE */
    _main_gen_init_sym_UGRDERSTR_BASE();
    
    /* init for variable PGERRSTAT_PE1_BASE */
    _main_gen_init_sym_PGERRSTAT_PE1_BASE();
    
    /* init for variable ECCGTM0CTL_BASE */
    _main_gen_init_sym_ECCGTM0CTL_BASE();
    
    /* init for variable ECCGTM1CTL_BASE */
    _main_gen_init_sym_ECCGTM1CTL_BASE();
    
    /* init for variable LROVFSTR_PE1_BASE */
    _main_gen_init_sym_LROVFSTR_PE1_BASE();
    
    /* init for variable UGROVFSTR_BASE */
    _main_gen_init_sym_UGROVFSTR_BASE();
    
    /* init for variable UCFOVFSTR_BASE */
    _main_gen_init_sym_UCFOVFSTR_BASE();
    
    /* init for variable ECCFLX0CTL_BASE */
    _main_gen_init_sym_ECCFLX0CTL_BASE();
    
    /* init for variable ECCFLX0T0CTL_BASE */
    _main_gen_init_sym_ECCFLX0T0CTL_BASE();
    
    /* init for variable ECCFLX0T1CTL_BASE */
    _main_gen_init_sym_ECCFLX0T1CTL_BASE();
    
    /* init for variable ECCCSIH0CTL_BASE */
    _main_gen_init_sym_ECCCSIH0CTL_BASE();
    
    /* init for variable ECCCSIH1CTL_BASE */
    _main_gen_init_sym_ECCCSIH1CTL_BASE();
    
    /* init for variable ECCCSIH2CTL_BASE */
    _main_gen_init_sym_ECCCSIH2CTL_BASE();
    
    /* init for variable ECCCSIH3CTL_BASE */
    _main_gen_init_sym_ECCCSIH3CTL_BASE();
    
    /* init for variable DMACER_BASE */
    _main_gen_init_sym_DMACER_BASE();
    
    /* init for variable DTSER1_BASE */
    _main_gen_init_sym_DTSER1_BASE();
    
    /* init for variable DTSER2_BASE */
    _main_gen_init_sym_DTSER2_BASE();
    
    /* init for variable ECCTTCAN0CTL_BASE */
    _main_gen_init_sym_ECCTTCAN0CTL_BASE();
    
    /* init for variable ECCMCAN0CTL_BASE */
    _main_gen_init_sym_ECCMCAN0CTL_BASE();
    
    /* init for variable ECCMCAN1CTL_BASE */
    _main_gen_init_sym_ECCMCAN1CTL_BASE();
    
    /* init for variable WdgMConfig_Mode0 */
    _main_gen_init_sym_WdgMConfig_Mode0();
    
    /* init for variable ExcpnHndlg_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable ExcpnHndlg_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable ExcpnHndlg_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable ExcpnHndlg_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable ExcpnHndlg_Srv_SetNtcSts_Return */
    _main_gen_init_sym_ExcpnHndlg_Srv_SetNtcSts_Return();
    
    /* init for variable ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest */
    _main_gen_init_sym_ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest();
    
    /* init for variable ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1 */
    _main_gen_init_sym_ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1();
    
    /* init for variable ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcNr */
    _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcNr();
    
    /* init for variable ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcStInfo */
    _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcStInfo();
    
    /* init for variable ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcSts */
    _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_NtcSts();
    
    /* init for variable ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_DebStep */
    _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_DebStep();
    
    /* init for variable ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData0 */
    _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData0();
    
    /* init for variable ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData1 */
    _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData1();
    
    /* init for variable ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData2 */
    _main_gen_init_sym_ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_SpclSnpshtData2();
    
    /* init for variable ExcpnHndlg_Cli_SetNtcStsAndSnpshtData_Return : useless (never read) */

}
