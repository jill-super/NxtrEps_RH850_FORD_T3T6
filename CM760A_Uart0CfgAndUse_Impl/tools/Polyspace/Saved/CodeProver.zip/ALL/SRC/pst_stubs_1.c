#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__114 _main_gen_init_g114(void);

extern __PST__g__112 _main_gen_init_g112(void);

extern __PST__g__106 _main_gen_init_g106(void);

extern __PST__g__102 _main_gen_init_g102(void);

extern struct __PST__g__101 _main_gen_init_g101(void);

extern __PST__g__99 _main_gen_init_g99(void);

extern struct __PST__g__98 _main_gen_init_g98(void);

extern __PST__g__96 _main_gen_init_g96(void);

extern struct __PST__g__95 _main_gen_init_g95(void);

extern __PST__g__93 _main_gen_init_g93(void);

extern struct __PST__g__92 _main_gen_init_g92(void);

extern __PST__g__90 _main_gen_init_g90(void);

extern struct __PST__g__88 _main_gen_init_g88(void);

extern __PST__g__86 _main_gen_init_g86(void);

extern struct __PST__g__85 _main_gen_init_g85(void);

extern __PST__g__83 _main_gen_init_g83(void);

extern struct __PST__g__82 _main_gen_init_g82(void);

extern __PST__g__80 _main_gen_init_g80(void);

extern struct __PST__g__79 _main_gen_init_g79(void);

extern __PST__g__77 _main_gen_init_g77(void);

extern struct __PST__g__75 _main_gen_init_g75(void);

extern __PST__g__73 _main_gen_init_g73(void);

extern struct __PST__g__71 _main_gen_init_g71(void);

extern __PST__g__69 _main_gen_init_g69(void);

extern struct __PST__g__66 _main_gen_init_g66(void);

extern __PST__g__64 _main_gen_init_g64(void);

extern __PST__g__61 _main_gen_init_g61(void);

extern struct __PST__g__60 _main_gen_init_g60(void);

extern __PST__g__58 _main_gen_init_g58(void);

extern struct __PST__g__57 _main_gen_init_g57(void);

extern __PST__g__55 _main_gen_init_g55(void);

extern struct __PST__g__54 _main_gen_init_g54(void);

extern __PST__g__52 _main_gen_init_g52(void);

extern __PST__g__49 _main_gen_init_g49(void);

extern __PST__g__46 _main_gen_init_g46(void);

extern __PST__g__43 _main_gen_init_g43(void);

extern __PST__g__40 _main_gen_init_g40(void);

extern __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__34 _main_gen_init_g34(void)
{
    __PST__g__34 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__37 _main_gen_init_g37(void)
{
    __PST__g__37 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__40 _main_gen_init_g40(void)
{
    __PST__g__40 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__43 _main_gen_init_g43(void)
{
    __PST__g__43 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__46 _main_gen_init_g46(void)
{
    __PST__g__46 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__49 _main_gen_init_g49(void)
{
    __PST__g__49 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__54 _main_gen_init_g54(void)
{
    static struct __PST__g__54 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._REQEN = bitf;
    }
    return x;
}

__PST__g__52 _main_gen_init_g52(void)
{
    __PST__g__52 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g54();
    return x;
}

struct __PST__g__57 _main_gen_init_g57(void)
{
    static struct __PST__g__57 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._DRQC = bitf;
    }
    return x;
}

__PST__g__55 _main_gen_init_g55(void)
{
    __PST__g__55 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g57();
    return x;
}

struct __PST__g__60 _main_gen_init_g60(void)
{
    static struct __PST__g__60 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._DRQS = bitf;
    }
    return x;
}

__PST__g__58 _main_gen_init_g58(void)
{
    __PST__g__58 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g60();
    return x;
}

__PST__g__61 _main_gen_init_g61(void)
{
    __PST__g__61 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__66 _main_gen_init_g66(void)
{
    static struct __PST__g__66 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 7);
        x._LPRS = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 15);
        x._NSPB = bitf;
    }
    return x;
}

__PST__g__64 _main_gen_init_g64(void)
{
    __PST__g__64 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g66();
    return x;
}

struct __PST__g__71 _main_gen_init_g71(void)
{
    static struct __PST__g__71 x;
    /* struct/union type */
    x._BRP = _main_gen_init_g7();
    return x;
}

__PST__g__69 _main_gen_init_g69(void)
{
    __PST__g__69 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g71();
    return x;
}

struct __PST__g__75 _main_gen_init_g75(void)
{
    static struct __PST__g__75 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x._LMD = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._LRDNFS = bitf;
    }
    return x;
}

__PST__g__73 _main_gen_init_g73(void)
{
    __PST__g__73 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g75();
    return x;
}

struct __PST__g__79 _main_gen_init_g79(void)
{
    static struct __PST__g__79 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._UBLS = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._UBOS = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._USBLS = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x._UPS = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._URPS = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._UTPS = bitf;
    }
    return x;
}

__PST__g__77 _main_gen_init_g77(void)
{
    __PST__g__77 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g79();
    return x;
}

struct __PST__g__82 _main_gen_init_g82(void)
{
    static struct __PST__g__82 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._BERE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._OERE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._FERE = bitf;
    }
    return x;
}

__PST__g__80 _main_gen_init_g80(void)
{
    __PST__g__80 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g82();
    return x;
}

struct __PST__g__85 _main_gen_init_g85(void)
{
    static struct __PST__g__85 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._OM0 = bitf;
    }
    return x;
}

__PST__g__83 _main_gen_init_g83(void)
{
    __PST__g__83 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g85();
    return x;
}

struct __PST__g__88 _main_gen_init_g88(void)
{
    static struct __PST__g__88 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._UTS = bitf;
    }
    return x;
}

__PST__g__86 _main_gen_init_g86(void)
{
    __PST__g__86 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g88();
    return x;
}

struct __PST__g__92 _main_gen_init_g92(void)
{
    static struct __PST__g__92 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._OER = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._FER = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._UPER = bitf;
    }
    return x;
}

__PST__g__90 _main_gen_init_g90(void)
{
    __PST__g__90 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g92();
    return x;
}

struct __PST__g__95 _main_gen_init_g95(void)
{
    static struct __PST__g__95 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 15);
        x._MDL = bitf;
    }
    return x;
}

__PST__g__93 _main_gen_init_g93(void)
{
    __PST__g__93 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g95();
    return x;
}

struct __PST__g__98 _main_gen_init_g98(void)
{
    static struct __PST__g__98 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._UTOE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._UROE = bitf;
    }
    return x;
}

__PST__g__96 _main_gen_init_g96(void)
{
    __PST__g__96 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g98();
    return x;
}

struct __PST__g__101 _main_gen_init_g101(void)
{
    static struct __PST__g__101 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._UTIGTS = bitf;
    }
    return x;
}

__PST__g__99 _main_gen_init_g99(void)
{
    __PST__g__99 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g101();
    return x;
}

__PST__g__102 _main_gen_init_g102(void)
{
    __PST__g__102 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__106 _main_gen_init_g106(void)
{
    __PST__g__106 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__114 _main_gen_init_g114(void)
{
    static struct __PST__g__114 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._MS_LM11 = bitf;
    }
    return x;
}

__PST__g__112 _main_gen_init_g112(void)
{
    __PST__g__112 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g114();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_PrevDmaTrfCnt(void)
{
    extern __PST__UINT16 Uart0CfgAndUse_Pim_PrevDmaTrfCnt;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_PrevDmaTrfCnt = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0100MilliSecBufCnt(void)
{
    extern __PST__g__29 Uart0CfgAndUse_Pim_Uart0100MilliSecBufCnt;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 2048; _main_gen_tmp_0_0++)
            {
                /* base type */
                Uart0CfgAndUse_Pim_Uart0100MilliSecBufCnt[_main_gen_tmp_0_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0100MilliSecReadCmpl(void)
{
    extern __PST__UINT8 Uart0CfgAndUse_Pim_Uart0100MilliSecReadCmpl;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_Uart0100MilliSecReadCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart010MilliSecBufCnt(void)
{
    extern __PST__g__29 Uart0CfgAndUse_Pim_Uart010MilliSecBufCnt;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 2048; _main_gen_tmp_1_0++)
            {
                /* base type */
                Uart0CfgAndUse_Pim_Uart010MilliSecBufCnt[_main_gen_tmp_1_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart010MilliSecReadCmpl(void)
{
    extern __PST__UINT8 Uart0CfgAndUse_Pim_Uart010MilliSecReadCmpl;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_Uart010MilliSecReadCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart02MilliSecBufCnt(void)
{
    extern __PST__g__29 Uart0CfgAndUse_Pim_Uart02MilliSecBufCnt;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 2048; _main_gen_tmp_2_0++)
            {
                /* base type */
                Uart0CfgAndUse_Pim_Uart02MilliSecBufCnt[_main_gen_tmp_2_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0DiagcFrmErrCntr(void)
{
    extern __PST__UINT32 Uart0CfgAndUse_Pim_Uart0DiagcFrmErrCntr;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_Uart0DiagcFrmErrCntr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0DiagcOvrrunErrCntr(void)
{
    extern __PST__UINT32 Uart0CfgAndUse_Pim_Uart0DiagcOvrrunErrCntr;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_Uart0DiagcOvrrunErrCntr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0DiagcParErrCntr(void)
{
    extern __PST__UINT32 Uart0CfgAndUse_Pim_Uart0DiagcParErrCntr;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_Uart0DiagcParErrCntr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0DiagcRxMaxDataErrCntr(void)
{
    extern __PST__UINT32 Uart0CfgAndUse_Pim_Uart0DiagcRxMaxDataErrCntr;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_Uart0DiagcRxMaxDataErrCntr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0NrOfPnd100MilliSecFrmCnt(void)
{
    extern __PST__UINT8 Uart0CfgAndUse_Pim_Uart0NrOfPnd100MilliSecFrmCnt;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_Uart0NrOfPnd100MilliSecFrmCnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0NrOfPnd10MilliSecFrmCnt(void)
{
    extern __PST__UINT8 Uart0CfgAndUse_Pim_Uart0NrOfPnd10MilliSecFrmCnt;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_Uart0NrOfPnd10MilliSecFrmCnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0RxPrevLoopDataUnread(void)
{
    extern __PST__UINT8 Uart0CfgAndUse_Pim_Uart0RxPrevLoopDataUnread;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Pim_Uart0RxPrevLoopDataUnread = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DTSA100_BASE(void)
{
    extern __PST__g__30 DTSA100_BASE;
    
    /* initialization with random value */
    {
        DTSA100_BASE = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DTDA100_BASE(void)
{
    extern __PST__g__34 DTDA100_BASE;
    
    /* initialization with random value */
    {
        DTDA100_BASE = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DTTC100_BASE(void)
{
    extern __PST__g__37 DTTC100_BASE;
    
    /* initialization with random value */
    {
        DTTC100_BASE = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_DTTCT100_BASE(void)
{
    extern __PST__g__40 DTTCT100_BASE;
    
    /* initialization with random value */
    {
        DTTCT100_BASE = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_DTRSA100_BASE(void)
{
    extern __PST__g__43 DTRSA100_BASE;
    
    /* initialization with random value */
    {
        DTRSA100_BASE = _main_gen_init_g43();
    }
}

static void _main_gen_init_sym_DTRDA100_BASE(void)
{
    extern __PST__g__46 DTRDA100_BASE;
    
    /* initialization with random value */
    {
        DTRDA100_BASE = _main_gen_init_g46();
    }
}

static void _main_gen_init_sym_DTRTC100_BASE(void)
{
    extern __PST__g__49 DTRTC100_BASE;
    
    /* initialization with random value */
    {
        DTRTC100_BASE = _main_gen_init_g49();
    }
}

static void _main_gen_init_sym_DTFSL100_BASE(void)
{
    extern __PST__g__52 DTFSL100_BASE;
    
    /* initialization with random value */
    {
        DTFSL100_BASE = _main_gen_init_g52();
    }
}

static void _main_gen_init_sym_DTFSC100_BASE(void)
{
    extern __PST__g__55 DTFSC100_BASE;
    
    /* initialization with random value */
    {
        DTFSC100_BASE = _main_gen_init_g55();
    }
}

static void _main_gen_init_sym_DTSA101_BASE(void)
{
    extern __PST__g__30 DTSA101_BASE;
    
    /* initialization with random value */
    {
        DTSA101_BASE = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DTDA101_BASE(void)
{
    extern __PST__g__34 DTDA101_BASE;
    
    /* initialization with random value */
    {
        DTDA101_BASE = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DTTC101_BASE(void)
{
    extern __PST__g__37 DTTC101_BASE;
    
    /* initialization with random value */
    {
        DTTC101_BASE = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_DTTCT101_BASE(void)
{
    extern __PST__g__40 DTTCT101_BASE;
    
    /* initialization with random value */
    {
        DTTCT101_BASE = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_DTFSL101_BASE(void)
{
    extern __PST__g__52 DTFSL101_BASE;
    
    /* initialization with random value */
    {
        DTFSL101_BASE = _main_gen_init_g52();
    }
}

static void _main_gen_init_sym_DTFSS101_BASE(void)
{
    extern __PST__g__58 DTFSS101_BASE;
    
    /* initialization with random value */
    {
        DTFSS101_BASE = _main_gen_init_g58();
    }
}

static void _main_gen_init_sym_DTFSC101_BASE(void)
{
    extern __PST__g__55 DTFSC101_BASE;
    
    /* initialization with random value */
    {
        DTFSC101_BASE = _main_gen_init_g55();
    }
}

static void _main_gen_init_sym_DTS100CM_BASE(void)
{
    extern __PST__g__61 DTS100CM_BASE;
    
    /* initialization with random value */
    {
        DTS100CM_BASE = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_DTS101CM_BASE(void)
{
    extern __PST__g__61 DTS101CM_BASE;
    
    /* initialization with random value */
    {
        DTS101CM_BASE = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_RLN30LWBR_BASE(void)
{
    extern __PST__g__64 RLN30LWBR_BASE;
    
    /* initialization with random value */
    {
        RLN30LWBR_BASE = _main_gen_init_g64();
    }
}

static void _main_gen_init_sym_RLN30LBRP01_BASE(void)
{
    extern __PST__g__69 RLN30LBRP01_BASE;
    
    /* initialization with random value */
    {
        RLN30LBRP01_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_RLN30LMD_BASE(void)
{
    extern __PST__g__73 RLN30LMD_BASE;
    
    /* initialization with random value */
    {
        RLN30LMD_BASE = _main_gen_init_g73();
    }
}

static void _main_gen_init_sym_RLN30LBFC_BASE(void)
{
    extern __PST__g__77 RLN30LBFC_BASE;
    
    /* initialization with random value */
    {
        RLN30LBFC_BASE = _main_gen_init_g77();
    }
}

static void _main_gen_init_sym_RLN30LEDE_BASE(void)
{
    extern __PST__g__80 RLN30LEDE_BASE;
    
    /* initialization with random value */
    {
        RLN30LEDE_BASE = _main_gen_init_g80();
    }
}

static void _main_gen_init_sym_RLN30LCUC_BASE(void)
{
    extern __PST__g__83 RLN30LCUC_BASE;
    
    /* initialization with random value */
    {
        RLN30LCUC_BASE = _main_gen_init_g83();
    }
}

static void _main_gen_init_sym_RLN30LST_BASE(void)
{
    extern __PST__g__86 RLN30LST_BASE;
    
    /* initialization with random value */
    {
        RLN30LST_BASE = _main_gen_init_g86();
    }
}

static void _main_gen_init_sym_RLN30LEST_BASE(void)
{
    extern __PST__g__90 RLN30LEST_BASE;
    
    /* initialization with random value */
    {
        RLN30LEST_BASE = _main_gen_init_g90();
    }
}

static void _main_gen_init_sym_RLN30LDFC_BASE(void)
{
    extern __PST__g__93 RLN30LDFC_BASE;
    
    /* initialization with random value */
    {
        RLN30LDFC_BASE = _main_gen_init_g93();
    }
}

static void _main_gen_init_sym_RLN30LUOER_BASE(void)
{
    extern __PST__g__96 RLN30LUOER_BASE;
    
    /* initialization with random value */
    {
        RLN30LUOER_BASE = _main_gen_init_g96();
    }
}

static void _main_gen_init_sym_RLN30LUOR1_BASE(void)
{
    extern __PST__g__99 RLN30LUOR1_BASE;
    
    /* initialization with random value */
    {
        RLN30LUOR1_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_RLN30LUTDR_BASE(void)
{
    extern __PST__g__102 RLN30LUTDR_BASE;
    
    /* initialization with random value */
    {
        RLN30LUTDR_BASE = _main_gen_init_g102();
    }
}

static void _main_gen_init_sym_RLN30LURDR_BASE(void)
{
    extern __PST__g__106 RLN30LURDR_BASE;
    
    /* initialization with random value */
    {
        RLN30LURDR_BASE = _main_gen_init_g106();
    }
}

static void _main_gen_init_sym_MSR_LM11_BASE(void)
{
    extern __PST__g__112 MSR_LM11_BASE;
    
    /* initialization with random value */
    {
        MSR_LM11_BASE = _main_gen_init_g112();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Srv_GetTxRateGroup_Buf(void)
{
    extern __PST__g__29 Uart0CfgAndUse_Srv_GetTxRateGroup_Buf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 2048; _main_gen_tmp_3_0++)
            {
                /* base type */
                Uart0CfgAndUse_Srv_GetTxRateGroup_Buf[_main_gen_tmp_3_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Srv_GetTxRateGroup_Return(void)
{
    extern __PST__UINT8 Uart0CfgAndUse_Srv_GetTxRateGroup_Return;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Srv_GetTxRateGroup_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Srv_SetRxSigGroup_Buf(void)
{
    extern __PST__g__116 Uart0CfgAndUse_Srv_SetRxSigGroup_Buf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 8; _main_gen_tmp_4_0++)
            {
                /* base type */
                Uart0CfgAndUse_Srv_SetRxSigGroup_Buf[_main_gen_tmp_4_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_Uart0CfgAndUse_Srv_SetRxSigGroup_Return(void)
{
    extern __PST__UINT8 Uart0CfgAndUse_Srv_SetRxSigGroup_Return;
    
    /* initialization with random value */
    {
        Uart0CfgAndUse_Srv_SetRxSigGroup_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Uart0CfgAndUse_Pim_PrevDmaTrfCnt */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_PrevDmaTrfCnt();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart0100MilliSecBufCnt */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0100MilliSecBufCnt();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart0100MilliSecReadCmpl */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0100MilliSecReadCmpl();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart010MilliSecBufCnt */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart010MilliSecBufCnt();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart010MilliSecReadCmpl */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart010MilliSecReadCmpl();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart02MilliSecBufCnt */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart02MilliSecBufCnt();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart0DiagcFrmErrCntr */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0DiagcFrmErrCntr();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart0DiagcOvrrunErrCntr */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0DiagcOvrrunErrCntr();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart0DiagcParErrCntr */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0DiagcParErrCntr();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart0DiagcRxMaxDataErrCntr */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0DiagcRxMaxDataErrCntr();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart0NrOfPnd100MilliSecFrmCnt */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0NrOfPnd100MilliSecFrmCnt();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart0NrOfPnd10MilliSecFrmCnt */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0NrOfPnd10MilliSecFrmCnt();
    
    /* init for variable Uart0CfgAndUse_Pim_Uart0RxPrevLoopDataUnread */
    _main_gen_init_sym_Uart0CfgAndUse_Pim_Uart0RxPrevLoopDataUnread();
    
    /* init for variable DTSA100_BASE */
    _main_gen_init_sym_DTSA100_BASE();
    
    /* init for variable DTDA100_BASE */
    _main_gen_init_sym_DTDA100_BASE();
    
    /* init for variable DTTC100_BASE */
    _main_gen_init_sym_DTTC100_BASE();
    
    /* init for variable DTTCT100_BASE */
    _main_gen_init_sym_DTTCT100_BASE();
    
    /* init for variable DTRSA100_BASE */
    _main_gen_init_sym_DTRSA100_BASE();
    
    /* init for variable DTRDA100_BASE */
    _main_gen_init_sym_DTRDA100_BASE();
    
    /* init for variable DTRTC100_BASE */
    _main_gen_init_sym_DTRTC100_BASE();
    
    /* init for variable DTFSL100_BASE */
    _main_gen_init_sym_DTFSL100_BASE();
    
    /* init for variable DTFSC100_BASE */
    _main_gen_init_sym_DTFSC100_BASE();
    
    /* init for variable DTSA101_BASE */
    _main_gen_init_sym_DTSA101_BASE();
    
    /* init for variable DTDA101_BASE */
    _main_gen_init_sym_DTDA101_BASE();
    
    /* init for variable DTTC101_BASE */
    _main_gen_init_sym_DTTC101_BASE();
    
    /* init for variable DTTCT101_BASE */
    _main_gen_init_sym_DTTCT101_BASE();
    
    /* init for variable DTFSL101_BASE */
    _main_gen_init_sym_DTFSL101_BASE();
    
    /* init for variable DTFSS101_BASE */
    _main_gen_init_sym_DTFSS101_BASE();
    
    /* init for variable DTFSC101_BASE */
    _main_gen_init_sym_DTFSC101_BASE();
    
    /* init for variable DTS100CM_BASE */
    _main_gen_init_sym_DTS100CM_BASE();
    
    /* init for variable DTS101CM_BASE */
    _main_gen_init_sym_DTS101CM_BASE();
    
    /* init for variable RLN30LWBR_BASE */
    _main_gen_init_sym_RLN30LWBR_BASE();
    
    /* init for variable RLN30LBRP01_BASE */
    _main_gen_init_sym_RLN30LBRP01_BASE();
    
    /* init for variable RLN30LMD_BASE */
    _main_gen_init_sym_RLN30LMD_BASE();
    
    /* init for variable RLN30LBFC_BASE */
    _main_gen_init_sym_RLN30LBFC_BASE();
    
    /* init for variable RLN30LEDE_BASE */
    _main_gen_init_sym_RLN30LEDE_BASE();
    
    /* init for variable RLN30LCUC_BASE */
    _main_gen_init_sym_RLN30LCUC_BASE();
    
    /* init for variable RLN30LST_BASE */
    _main_gen_init_sym_RLN30LST_BASE();
    
    /* init for variable RLN30LEST_BASE */
    _main_gen_init_sym_RLN30LEST_BASE();
    
    /* init for variable RLN30LDFC_BASE */
    _main_gen_init_sym_RLN30LDFC_BASE();
    
    /* init for variable RLN30LUOER_BASE */
    _main_gen_init_sym_RLN30LUOER_BASE();
    
    /* init for variable RLN30LUOR1_BASE */
    _main_gen_init_sym_RLN30LUOR1_BASE();
    
    /* init for variable RLN30LUTDR_BASE */
    _main_gen_init_sym_RLN30LUTDR_BASE();
    
    /* init for variable RLN30LURDR_BASE */
    _main_gen_init_sym_RLN30LURDR_BASE();
    
    /* init for variable MSR_LM11_BASE */
    _main_gen_init_sym_MSR_LM11_BASE();
    
    /* init for variable Uart0CfgAndUse_Srv_GetTxRateGroup_RateGroup : useless (never read) */

    /* init for variable Uart0CfgAndUse_Srv_GetTxRateGroup_Buf */
    _main_gen_init_sym_Uart0CfgAndUse_Srv_GetTxRateGroup_Buf();
    
    /* init for variable Uart0CfgAndUse_Srv_GetTxRateGroup_Return */
    _main_gen_init_sym_Uart0CfgAndUse_Srv_GetTxRateGroup_Return();
    
    /* init for variable Uart0CfgAndUse_Srv_SetRxSigGroup_SigGroup : useless (never read) */

    /* init for variable Uart0CfgAndUse_Srv_SetRxSigGroup_DataSrc : useless (never read) */

    /* init for variable Uart0CfgAndUse_Srv_SetRxSigGroup_Buf */
    _main_gen_init_sym_Uart0CfgAndUse_Srv_SetRxSigGroup_Buf();
    
    /* init for variable Uart0CfgAndUse_Srv_SetRxSigGroup_Return */
    _main_gen_init_sym_Uart0CfgAndUse_Srv_SetRxSigGroup_Return();
    
}
