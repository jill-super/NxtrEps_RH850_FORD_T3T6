/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  Rte_Type.h
 *        Config:  C:/Users/NZ5334/Documents/Synergy/Working/ses_dev_ea4/MM124A_FordMsg077BusHiSpd_Impl/tools/Component.dpa
 *     SW-C Type:  FordMsg077BusHiSpd
 *  Generated at:  Fri May  4 10:30:53 2018
 *
 *     Generator:  MICROSAR RTE Generator Version 4.13.0
 *                 RTE Core Version 1.13.0
 *       License:  Unlimited license CBD1400351 for Nexteer Automotive Corporation
 *
 *   Description:  Header file containing user defined AUTOSAR types and RTE structures (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_TYPE_H
# define _RTE_TYPE_H

# include "Rte.h"


/**********************************************************************************************************************
 * Data type definitions
 *********************************************************************************************************************/

# define Rte_TypeDef_Ford_VehLatComp_A_Actl
typedef uint16 Ford_VehLatComp_A_Actl;

# define Rte_TypeDef_Ford_VehLongComp_A_Actl
typedef uint16 Ford_VehLongComp_A_Actl;

# define Rte_TypeDef_Ford_VehOverGnd_V_Est
typedef uint16 Ford_VehOverGnd_V_Est;

# define Rte_TypeDef_Ford_VehYawComp_W_Actl
typedef uint16 Ford_VehYawComp_W_Actl;

# define Rte_TypeDef_NtcNr1
typedef uint16 NtcNr1;

# define Rte_TypeDef_NtcSts1
typedef uint8 NtcSts1;

# define Rte_TypeDef_u16p0
typedef uint16 u16p0;


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

#endif /* _RTE_TYPE_H */
