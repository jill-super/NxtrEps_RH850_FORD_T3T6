/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordBrkOscnRednEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordBrkOscnRednEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordBrkOscnRednEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordBrkOscnRednEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordBrkOscnRednEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordCanDtcInhb_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordCanDtcInhb_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordCanDtcInhb_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordCanDtcInhb_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordCanDtcInhb_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordClrDiagcFlgProxy_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordClrDiagcFlgProxy_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordClrDiagcFlgProxy_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordClrDiagcFlgProxy_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordClrDiagcFlgProxy_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordEpsLifeCycMod_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordEpsLifeCycMod_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordEpsLifeCycMod_Val"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordEpsLifeCycMod_Val"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordEpsLifeCycMod_Val(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordEvasSteerAssiEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordEvasSteerAssiEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordEvasSteerAssiEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordEvasSteerAssiEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordEvasSteerAssiEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordLaneCentrAssiEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordLaneCentrAssiEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordLaneCentrAssiEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordLaneCentrAssiEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordLaneCentrAssiEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordLaneKeepAssiEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordLaneKeepAssiEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordLaneKeepAssiEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordLaneKeepAssiEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordLaneKeepAssiEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordPullDriftCmpEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordPullDriftCmpEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordPullDriftCmpEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordPullDriftCmpEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordPullDriftCmpEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordTqSteerCmpEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordTqSteerCmpEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordTqSteerCmpEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordTqSteerCmpEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordTqSteerCmpEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordTrfcJamAssiEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordTrfcJamAssiEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordTrfcJamAssiEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordTrfcJamAssiEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordTrfcJamAssiEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_FordTrlrBackUpAssiEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_FordTrlrBackUpAssiEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_FordTrlrBackUpAssiEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_FordTrlrBackUpAssiEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordTrlrBackUpAssiEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_Ford_VehLatComp_A_Actl_Ford_VehLatComp_A_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_Ford_VehLatComp_A_Actl_Ford_VehLatComp_A_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_Ford_VehLatComp_A_Actl_Ford_VehLatComp_A_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_Ford_VehLatComp_A_Actl_Ford_VehLatComp_A_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_Ford_VehLatComp_A_Actl_Ford_VehLatComp_A_Actl(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_Ford_VehLongComp_A_Actl_Ford_VehLongComp_A_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_Ford_VehLongComp_A_Actl_Ford_VehLongComp_A_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_Ford_VehLongComp_A_Actl_Ford_VehLongComp_A_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_Ford_VehLongComp_A_Actl_Ford_VehLongComp_A_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_Ford_VehLongComp_A_Actl_Ford_VehLongComp_A_Actl(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_Ford_VehOverGnd_V_Est_Ford_VehOverGnd_V_Est
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_Ford_VehOverGnd_V_Est_Ford_VehOverGnd_V_Est"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_Ford_VehOverGnd_V_Est_Ford_VehOverGnd_V_Est"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_Ford_VehOverGnd_V_Est_Ford_VehOverGnd_V_Est"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_Ford_VehOverGnd_V_Est_Ford_VehOverGnd_V_Est(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg077BusHiSpd_Ford_VehYawComp_W_Actl_Ford_VehYawComp_W_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg077BusHiSpd_Ford_VehYawComp_W_Actl_Ford_VehYawComp_W_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg077BusHiSpd_Ford_VehYawComp_W_Actl_Ford_VehYawComp_W_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg077BusHiSpd_Ford_VehYawComp_W_Actl_Ford_VehYawComp_W_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg077BusHiSpd_Ford_VehYawComp_W_Actl_Ford_VehYawComp_W_Actl(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpd_Val"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdVld_Logl"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpd_Val"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdVld_Logl"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGnd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGnd_Val"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGnd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndVld_Logl"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpd_Val"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdVld_Logl"
//
// __PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdCanDtcInhbThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdCanDtcInhbThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdCanDtcInhbThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdCanDtcInhbThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdCanDtcInhbThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdVldMissThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdVldMissThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdVldMissThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdVldMissThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdVldMissThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldMissThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldMissThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldMissThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldMissThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldMissThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdVldMissThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdVldMissThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdVldMissThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdVldMissThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdVldMissThd_Val(__PST__VOID)
// {
//    ...
// }

