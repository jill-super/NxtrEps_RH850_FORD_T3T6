#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_FordMsg077BusHiSpd_FordBrkOscnRednEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordBrkOscnRednEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordCanDtcInhb_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordCanDtcInhb_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordClrDiagcFlgProxy_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordClrDiagcFlgProxy_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordEpsLifeCycMod_Val
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordEpsLifeCycMod_Val(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordEvasSteerAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordEvasSteerAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordLaneCentrAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordLaneCentrAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordLaneKeepAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordLaneKeepAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordPullDriftCmpEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordPullDriftCmpEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordTqSteerCmpEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordTqSteerCmpEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordTrfcJamAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordTrfcJamAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_FordTrlrBackUpAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_FordTrlrBackUpAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_Ford_VehLatComp_A_Actl_Ford_VehLatComp_A_Actl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_Ford_VehLatComp_A_Actl_Ford_VehLatComp_A_Actl(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_Ford_VehLongComp_A_Actl_Ford_VehLongComp_A_Actl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_Ford_VehLongComp_A_Actl_Ford_VehLongComp_A_Actl(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_Ford_VehOverGnd_V_Est_Ford_VehOverGnd_V_Est
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_Ford_VehOverGnd_V_Est_Ford_VehOverGnd_V_Est(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg077BusHiSpd_Ford_VehYawComp_W_Actl_Ford_VehYawComp_W_Actl
 */


__PST__UINT8 Rte_Read_FordMsg077BusHiSpd_Ford_VehYawComp_W_Actl_Ford_VehYawComp_W_Actl(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpd_Val"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdRaw_Val"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdRaw_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdVld_Logl"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLatACmpdVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpd_Val"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdRaw_Val"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdRaw_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdVld_Logl"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehLgtACmpdVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGnd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGnd_Val"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGnd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndRaw_Val"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndRaw_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndVld_Logl"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehSpdOverGndVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpd_Val"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdRaw_Val"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdRaw_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdVld_Logl"


__PST__UINT8 Rte_Write_FordMsg077BusHiSpd_FordVehYawRateCmpdVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdCanDtcInhbThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdCanDtcInhbThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdCanDtcInhbThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLatACmpdInvldSigPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdInvldSigPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdVldMissThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdVldMissThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdLgtACmpdVldMissThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdMissMsgPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdOverGndInvldSigPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLatACmpdVldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehLgtACmpdVldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldMissThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldMissThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldMissThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehSpdOverGndVldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdVehYawRateCmpdVldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdInvldSigPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdVldMissThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdVldMissThd_Val"


__PST__UINT16 Rte_Prm_FordMsg077BusHiSpd_FordMsg077BusHiSpdYawRateCmpdVldMissThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

