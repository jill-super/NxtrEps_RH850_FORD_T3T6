#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__79 _main_gen_init_g79(void);

extern __PST__g__77 _main_gen_init_g77(void);

extern struct __PST__g__75 _main_gen_init_g75(void);

extern __PST__g__71 _main_gen_init_g71(void);

extern struct __PST__g__70 _main_gen_init_g70(void);

extern __PST__g__68 _main_gen_init_g68(void);

extern struct __PST__g__67 _main_gen_init_g67(void);

extern __PST__g__65 _main_gen_init_g65(void);

extern __PST__g__62 _main_gen_init_g62(void);

extern struct __PST__g__61 _main_gen_init_g61(void);

extern __PST__g__59 _main_gen_init_g59(void);

extern __PST__g__56 _main_gen_init_g56(void);

extern __PST__g__53 _main_gen_init_g53(void);

extern __PST__g__50 _main_gen_init_g50(void);

extern __PST__g__47 _main_gen_init_g47(void);

extern __PST__g__44 _main_gen_init_g44(void);

extern __PST__g__41 _main_gen_init_g41(void);

extern __PST__g__38 _main_gen_init_g38(void);

extern __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__34 _main_gen_init_g34(void)
{
    __PST__g__34 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__38 _main_gen_init_g38(void)
{
    __PST__g__38 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__41 _main_gen_init_g41(void)
{
    __PST__g__41 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__44 _main_gen_init_g44(void)
{
    __PST__g__44 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__47 _main_gen_init_g47(void)
{
    __PST__g__47 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__50 _main_gen_init_g50(void)
{
    __PST__g__50 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__53 _main_gen_init_g53(void)
{
    __PST__g__53 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__56 _main_gen_init_g56(void)
{
    __PST__g__56 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__61 _main_gen_init_g61(void)
{
    static struct __PST__g__61 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._DTE = bitf;
    }
    return x;
}

__PST__g__59 _main_gen_init_g59(void)
{
    __PST__g__59 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g61();
    return x;
}

__PST__g__62 _main_gen_init_g62(void)
{
    __PST__g__62 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__67 _main_gen_init_g67(void)
{
    static struct __PST__g__67 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._TCC = bitf;
    }
    return x;
}

__PST__g__65 _main_gen_init_g65(void)
{
    __PST__g__65 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g67();
    return x;
}

struct __PST__g__70 _main_gen_init_g70(void)
{
    static struct __PST__g__70 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._DRQC = bitf;
    }
    return x;
}

__PST__g__68 _main_gen_init_g68(void)
{
    __PST__g__68 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g70();
    return x;
}

struct __PST__g__75 _main_gen_init_g75(void)
{
    static struct __PST__g__75 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._TC = bitf;
    }
    return x;
}

__PST__g__71 _main_gen_init_g71(void)
{
    __PST__g__71 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g75();
    return x;
}

struct __PST__g__79 _main_gen_init_g79(void)
{
    static struct __PST__g__79 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._UM = bitf;
    }
    return x;
}

__PST__g__77 _main_gen_init_g77(void)
{
    __PST__g__77 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g79();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_MotCtrlToTwoMilliSec_Rec(void)
{
    extern __PST__g__26 MotCtrlMgr_MotCtrlToTwoMilliSec_Rec;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 16; _main_gen_tmp_0_0++)
            {
                /* base type */
                MotCtrlMgr_MotCtrlToTwoMilliSec_Rec[_main_gen_tmp_0_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlMgr_TwoMilliSecToMotCtrl_Rec(void)
{
    extern __PST__g__26 MotCtrlMgr_TwoMilliSecToMotCtrl_Rec;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 16; _main_gen_tmp_1_0++)
            {
                /* base type */
                MotCtrlMgr_TwoMilliSecToMotCtrl_Rec[_main_gen_tmp_1_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc0RawRes(void)
{
    extern __PST__g__27 MOTCTRLMGR_MotCtrlAdc0RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 24; _main_gen_tmp_2_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlAdc0RawRes[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc1RawRes(void)
{
    extern __PST__g__27 MOTCTRLMGR_MotCtrlAdc1RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 24; _main_gen_tmp_3_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlAdc1RawRes[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec(void)
{
    extern __PST__g__26 MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 16; _main_gen_tmp_4_0++)
            {
                /* base type */
                MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec[_main_gen_tmp_4_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec(void)
{
    extern __PST__g__26 MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 16; _main_gen_tmp_5_0++)
            {
                /* base type */
                MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec[_main_gen_tmp_5_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_ADCF0DR00_BASE(void)
{
    extern __PST__g__28 ADCF0DR00_BASE;
    
    /* initialization with random value */
    {
        ADCF0DR00_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ADCF1DR00_BASE(void)
{
    extern __PST__g__28 ADCF1DR00_BASE;
    
    /* initialization with random value */
    {
        ADCF1DR00_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_DSA1_BASE(void)
{
    extern __PST__g__34 DSA1_BASE;
    
    /* initialization with random value */
    {
        DSA1_BASE = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DDA1_BASE(void)
{
    extern __PST__g__38 DDA1_BASE;
    
    /* initialization with random value */
    {
        DDA1_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DTC1_BASE(void)
{
    extern __PST__g__41 DTC1_BASE;
    
    /* initialization with random value */
    {
        DTC1_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_DTCT1_BASE(void)
{
    extern __PST__g__44 DTCT1_BASE;
    
    /* initialization with random value */
    {
        DTCT1_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_DRSA1_BASE(void)
{
    extern __PST__g__47 DRSA1_BASE;
    
    /* initialization with random value */
    {
        DRSA1_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_DRDA1_BASE(void)
{
    extern __PST__g__50 DRDA1_BASE;
    
    /* initialization with random value */
    {
        DRDA1_BASE = _main_gen_init_g50();
    }
}

static void _main_gen_init_sym_DRTC1_BASE(void)
{
    extern __PST__g__53 DRTC1_BASE;
    
    /* initialization with random value */
    {
        DRTC1_BASE = _main_gen_init_g53();
    }
}

static void _main_gen_init_sym_DTCC1_BASE(void)
{
    extern __PST__g__56 DTCC1_BASE;
    
    /* initialization with random value */
    {
        DTCC1_BASE = _main_gen_init_g56();
    }
}

static void _main_gen_init_sym_DCEN1_BASE(void)
{
    extern __PST__g__59 DCEN1_BASE;
    
    /* initialization with random value */
    {
        DCEN1_BASE = _main_gen_init_g59();
    }
}

static void _main_gen_init_sym_DTFR1_BASE(void)
{
    extern __PST__g__62 DTFR1_BASE;
    
    /* initialization with random value */
    {
        DTFR1_BASE = _main_gen_init_g62();
    }
}

static void _main_gen_init_sym_DSA9_BASE(void)
{
    extern __PST__g__34 DSA9_BASE;
    
    /* initialization with random value */
    {
        DSA9_BASE = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DDA9_BASE(void)
{
    extern __PST__g__38 DDA9_BASE;
    
    /* initialization with random value */
    {
        DDA9_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DTC9_BASE(void)
{
    extern __PST__g__41 DTC9_BASE;
    
    /* initialization with random value */
    {
        DTC9_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_DTCT9_BASE(void)
{
    extern __PST__g__44 DTCT9_BASE;
    
    /* initialization with random value */
    {
        DTCT9_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_DRSA9_BASE(void)
{
    extern __PST__g__47 DRSA9_BASE;
    
    /* initialization with random value */
    {
        DRSA9_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_DRDA9_BASE(void)
{
    extern __PST__g__50 DRDA9_BASE;
    
    /* initialization with random value */
    {
        DRDA9_BASE = _main_gen_init_g50();
    }
}

static void _main_gen_init_sym_DRTC9_BASE(void)
{
    extern __PST__g__53 DRTC9_BASE;
    
    /* initialization with random value */
    {
        DRTC9_BASE = _main_gen_init_g53();
    }
}

static void _main_gen_init_sym_DTCC9_BASE(void)
{
    extern __PST__g__56 DTCC9_BASE;
    
    /* initialization with random value */
    {
        DTCC9_BASE = _main_gen_init_g56();
    }
}

static void _main_gen_init_sym_DCEN9_BASE(void)
{
    extern __PST__g__59 DCEN9_BASE;
    
    /* initialization with random value */
    {
        DCEN9_BASE = _main_gen_init_g59();
    }
}

static void _main_gen_init_sym_DCSTC9_BASE(void)
{
    extern __PST__g__65 DCSTC9_BASE;
    
    /* initialization with random value */
    {
        DCSTC9_BASE = _main_gen_init_g65();
    }
}

static void _main_gen_init_sym_DTFR9_BASE(void)
{
    extern __PST__g__62 DTFR9_BASE;
    
    /* initialization with random value */
    {
        DTFR9_BASE = _main_gen_init_g62();
    }
}

static void _main_gen_init_sym_DTFRRQC9_BASE(void)
{
    extern __PST__g__68 DTFRRQC9_BASE;
    
    /* initialization with random value */
    {
        DTFRRQC9_BASE = _main_gen_init_g68();
    }
}

static void _main_gen_init_sym_DSA14_BASE(void)
{
    extern __PST__g__34 DSA14_BASE;
    
    /* initialization with random value */
    {
        DSA14_BASE = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DDA14_BASE(void)
{
    extern __PST__g__38 DDA14_BASE;
    
    /* initialization with random value */
    {
        DDA14_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DTC14_BASE(void)
{
    extern __PST__g__41 DTC14_BASE;
    
    /* initialization with random value */
    {
        DTC14_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_DTCT14_BASE(void)
{
    extern __PST__g__44 DTCT14_BASE;
    
    /* initialization with random value */
    {
        DTCT14_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_DRSA14_BASE(void)
{
    extern __PST__g__47 DRSA14_BASE;
    
    /* initialization with random value */
    {
        DRSA14_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_DRDA14_BASE(void)
{
    extern __PST__g__50 DRDA14_BASE;
    
    /* initialization with random value */
    {
        DRDA14_BASE = _main_gen_init_g50();
    }
}

static void _main_gen_init_sym_DRTC14_BASE(void)
{
    extern __PST__g__53 DRTC14_BASE;
    
    /* initialization with random value */
    {
        DRTC14_BASE = _main_gen_init_g53();
    }
}

static void _main_gen_init_sym_DTCC14_BASE(void)
{
    extern __PST__g__56 DTCC14_BASE;
    
    /* initialization with random value */
    {
        DTCC14_BASE = _main_gen_init_g56();
    }
}

static void _main_gen_init_sym_DCEN14_BASE(void)
{
    extern __PST__g__59 DCEN14_BASE;
    
    /* initialization with random value */
    {
        DCEN14_BASE = _main_gen_init_g59();
    }
}

static void _main_gen_init_sym_DCSTC14_BASE(void)
{
    extern __PST__g__65 DCSTC14_BASE;
    
    /* initialization with random value */
    {
        DCSTC14_BASE = _main_gen_init_g65();
    }
}

static void _main_gen_init_sym_DTFR14_BASE(void)
{
    extern __PST__g__62 DTFR14_BASE;
    
    /* initialization with random value */
    {
        DTFR14_BASE = _main_gen_init_g62();
    }
}

static void _main_gen_init_sym_DTFRRQC14_BASE(void)
{
    extern __PST__g__68 DTFRRQC14_BASE;
    
    /* initialization with random value */
    {
        DTFRRQC14_BASE = _main_gen_init_g68();
    }
}

static void _main_gen_init_sym_DSA15_BASE(void)
{
    extern __PST__g__34 DSA15_BASE;
    
    /* initialization with random value */
    {
        DSA15_BASE = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_DDA15_BASE(void)
{
    extern __PST__g__38 DDA15_BASE;
    
    /* initialization with random value */
    {
        DDA15_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DTC15_BASE(void)
{
    extern __PST__g__41 DTC15_BASE;
    
    /* initialization with random value */
    {
        DTC15_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_DTCT15_BASE(void)
{
    extern __PST__g__44 DTCT15_BASE;
    
    /* initialization with random value */
    {
        DTCT15_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_DRSA15_BASE(void)
{
    extern __PST__g__47 DRSA15_BASE;
    
    /* initialization with random value */
    {
        DRSA15_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_DRDA15_BASE(void)
{
    extern __PST__g__50 DRDA15_BASE;
    
    /* initialization with random value */
    {
        DRDA15_BASE = _main_gen_init_g50();
    }
}

static void _main_gen_init_sym_DRTC15_BASE(void)
{
    extern __PST__g__53 DRTC15_BASE;
    
    /* initialization with random value */
    {
        DRTC15_BASE = _main_gen_init_g53();
    }
}

static void _main_gen_init_sym_DTCC15_BASE(void)
{
    extern __PST__g__56 DTCC15_BASE;
    
    /* initialization with random value */
    {
        DTCC15_BASE = _main_gen_init_g56();
    }
}

static void _main_gen_init_sym_DCEN15_BASE(void)
{
    extern __PST__g__59 DCEN15_BASE;
    
    /* initialization with random value */
    {
        DCEN15_BASE = _main_gen_init_g59();
    }
}

static void _main_gen_init_sym_DCST15_BASE(void)
{
    extern __PST__g__71 DCST15_BASE;
    
    /* initialization with random value */
    {
        DCST15_BASE = _main_gen_init_g71();
    }
}

static void _main_gen_init_sym_DCSTC15_BASE(void)
{
    extern __PST__g__65 DCSTC15_BASE;
    
    /* initialization with random value */
    {
        DCSTC15_BASE = _main_gen_init_g65();
    }
}

static void _main_gen_init_sym_DTFR15_BASE(void)
{
    extern __PST__g__62 DTFR15_BASE;
    
    /* initialization with random value */
    {
        DTFR15_BASE = _main_gen_init_g62();
    }
}

static void _main_gen_init_sym_DM01CM_BASE(void)
{
    extern __PST__g__77 DM01CM_BASE;
    
    /* initialization with random value */
    {
        DM01CM_BASE = _main_gen_init_g77();
    }
}

static void _main_gen_init_sym_DM11CM_BASE(void)
{
    extern __PST__g__77 DM11CM_BASE;
    
    /* initialization with random value */
    {
        DM11CM_BASE = _main_gen_init_g77();
    }
}

static void _main_gen_init_sym_DM16CM_BASE(void)
{
    extern __PST__g__77 DM16CM_BASE;
    
    /* initialization with random value */
    {
        DM16CM_BASE = _main_gen_init_g77();
    }
}

static void _main_gen_init_sym_DM17CM_BASE(void)
{
    extern __PST__g__77 DM17CM_BASE;
    
    /* initialization with random value */
    {
        DM17CM_BASE = _main_gen_init_g77();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return(void)
{
    extern __PST__UINT8 DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DmaCfgAndUse_Srv_ReadErrInjReg_ErrId(void)
{
    extern __PST__UINT32 DmaCfgAndUse_Srv_ReadErrInjReg_ErrId;
    
    /* initialization with random value */
    {
        DmaCfgAndUse_Srv_ReadErrInjReg_ErrId = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable DmaCfgAndUse_Pim_d2MilliSecAdcActDmaTrfTi : useless (never read) */

    /* init for variable DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi */
    _main_gen_init_sym_DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcMaxDmaTrfTi();
    
    /* init for variable DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi */
    _main_gen_init_sym_DmaCfgAndUse_Pim_DmaCfgAndUse2MilliSecAdcStrtTi();
    
    /* init for variable MotCtrlMgr_MotCtrlToTwoMilliSec_Rec */
    _main_gen_init_sym_MotCtrlMgr_MotCtrlToTwoMilliSec_Rec();
    
    /* init for variable MotCtrlMgr_TwoMilliSecToMotCtrl_Rec */
    _main_gen_init_sym_MotCtrlMgr_TwoMilliSecToMotCtrl_Rec();
    
    /* init for variable MOTCTRLMGR_MotCtrlAdc0RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc0RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlAdc1RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc1RawRes();
    
    /* init for variable MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec */
    _main_gen_init_sym_MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec();
    
    /* init for variable MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec */
    _main_gen_init_sym_MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec();
    
    /* init for variable ADCF0DR00_BASE */
    _main_gen_init_sym_ADCF0DR00_BASE();
    
    /* init for variable ADCF1DR00_BASE */
    _main_gen_init_sym_ADCF1DR00_BASE();
    
    /* init for variable DSA1_BASE */
    _main_gen_init_sym_DSA1_BASE();
    
    /* init for variable DDA1_BASE */
    _main_gen_init_sym_DDA1_BASE();
    
    /* init for variable DTC1_BASE */
    _main_gen_init_sym_DTC1_BASE();
    
    /* init for variable DTCT1_BASE */
    _main_gen_init_sym_DTCT1_BASE();
    
    /* init for variable DRSA1_BASE */
    _main_gen_init_sym_DRSA1_BASE();
    
    /* init for variable DRDA1_BASE */
    _main_gen_init_sym_DRDA1_BASE();
    
    /* init for variable DRTC1_BASE */
    _main_gen_init_sym_DRTC1_BASE();
    
    /* init for variable DTCC1_BASE */
    _main_gen_init_sym_DTCC1_BASE();
    
    /* init for variable DCEN1_BASE */
    _main_gen_init_sym_DCEN1_BASE();
    
    /* init for variable DTFR1_BASE */
    _main_gen_init_sym_DTFR1_BASE();
    
    /* init for variable DSA9_BASE */
    _main_gen_init_sym_DSA9_BASE();
    
    /* init for variable DDA9_BASE */
    _main_gen_init_sym_DDA9_BASE();
    
    /* init for variable DTC9_BASE */
    _main_gen_init_sym_DTC9_BASE();
    
    /* init for variable DTCT9_BASE */
    _main_gen_init_sym_DTCT9_BASE();
    
    /* init for variable DRSA9_BASE */
    _main_gen_init_sym_DRSA9_BASE();
    
    /* init for variable DRDA9_BASE */
    _main_gen_init_sym_DRDA9_BASE();
    
    /* init for variable DRTC9_BASE */
    _main_gen_init_sym_DRTC9_BASE();
    
    /* init for variable DTCC9_BASE */
    _main_gen_init_sym_DTCC9_BASE();
    
    /* init for variable DCEN9_BASE */
    _main_gen_init_sym_DCEN9_BASE();
    
    /* init for variable DCSTC9_BASE */
    _main_gen_init_sym_DCSTC9_BASE();
    
    /* init for variable DTFR9_BASE */
    _main_gen_init_sym_DTFR9_BASE();
    
    /* init for variable DTFRRQC9_BASE */
    _main_gen_init_sym_DTFRRQC9_BASE();
    
    /* init for variable DSA14_BASE */
    _main_gen_init_sym_DSA14_BASE();
    
    /* init for variable DDA14_BASE */
    _main_gen_init_sym_DDA14_BASE();
    
    /* init for variable DTC14_BASE */
    _main_gen_init_sym_DTC14_BASE();
    
    /* init for variable DTCT14_BASE */
    _main_gen_init_sym_DTCT14_BASE();
    
    /* init for variable DRSA14_BASE */
    _main_gen_init_sym_DRSA14_BASE();
    
    /* init for variable DRDA14_BASE */
    _main_gen_init_sym_DRDA14_BASE();
    
    /* init for variable DRTC14_BASE */
    _main_gen_init_sym_DRTC14_BASE();
    
    /* init for variable DTCC14_BASE */
    _main_gen_init_sym_DTCC14_BASE();
    
    /* init for variable DCEN14_BASE */
    _main_gen_init_sym_DCEN14_BASE();
    
    /* init for variable DCSTC14_BASE */
    _main_gen_init_sym_DCSTC14_BASE();
    
    /* init for variable DTFR14_BASE */
    _main_gen_init_sym_DTFR14_BASE();
    
    /* init for variable DTFRRQC14_BASE */
    _main_gen_init_sym_DTFRRQC14_BASE();
    
    /* init for variable DSA15_BASE */
    _main_gen_init_sym_DSA15_BASE();
    
    /* init for variable DDA15_BASE */
    _main_gen_init_sym_DDA15_BASE();
    
    /* init for variable DTC15_BASE */
    _main_gen_init_sym_DTC15_BASE();
    
    /* init for variable DTCT15_BASE */
    _main_gen_init_sym_DTCT15_BASE();
    
    /* init for variable DRSA15_BASE */
    _main_gen_init_sym_DRSA15_BASE();
    
    /* init for variable DRDA15_BASE */
    _main_gen_init_sym_DRDA15_BASE();
    
    /* init for variable DRTC15_BASE */
    _main_gen_init_sym_DRTC15_BASE();
    
    /* init for variable DTCC15_BASE */
    _main_gen_init_sym_DTCC15_BASE();
    
    /* init for variable DCEN15_BASE */
    _main_gen_init_sym_DCEN15_BASE();
    
    /* init for variable DCST15_BASE */
    _main_gen_init_sym_DCST15_BASE();
    
    /* init for variable DCSTC15_BASE */
    _main_gen_init_sym_DCSTC15_BASE();
    
    /* init for variable DTFR15_BASE */
    _main_gen_init_sym_DTFR15_BASE();
    
    /* init for variable DM01CM_BASE */
    _main_gen_init_sym_DM01CM_BASE();
    
    /* init for variable DM11CM_BASE */
    _main_gen_init_sym_DM11CM_BASE();
    
    /* init for variable DM16CM_BASE */
    _main_gen_init_sym_DM16CM_BASE();
    
    /* init for variable DM17CM_BASE */
    _main_gen_init_sym_DM17CM_BASE();
    
    /* init for variable DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr */
    _main_gen_init_sym_DmaCfgAndUse_Srv_GetRefTmr1MicroSec32bit_RefTmr();
    
    /* init for variable DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan */
    _main_gen_init_sym_DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_TiSpan();
    
    /* init for variable DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return */
    _main_gen_init_sym_DmaCfgAndUse_Srv_GetTiSpan1MicroSec32bit_Return();
    
    /* init for variable DmaCfgAndUse_Srv_ReadErrInjReg_ErrId */
    _main_gen_init_sym_DmaCfgAndUse_Srv_ReadErrInjReg_ErrId();
    
    /* init for variable DmaCfgAndUse_Cli_DmaWaitForMotCtrlTo2MilliSecTrf_Return : useless (never read) */

}
