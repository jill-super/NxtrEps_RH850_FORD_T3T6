#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__91 _main_gen_init_g91(void);

extern __PST__g__84 _main_gen_init_g84(void);

extern __PST__g__79 _main_gen_init_g79(void);

extern __PST__g__76 _main_gen_init_g76(void);

extern __PST__g__73 _main_gen_init_g73(void);

extern __PST__g__67 _main_gen_init_g67(void);

extern union __PST__g__65 _main_gen_init_g65(void);

extern struct __PST__g__60 _main_gen_init_g60(void);

extern union __PST__g__59 _main_gen_init_g59(void);

extern struct __PST__g__58 _main_gen_init_g58(void);

extern union __PST__g__57 _main_gen_init_g57(void);

extern struct __PST__g__51 _main_gen_init_g51(void);

extern union __PST__g__50 _main_gen_init_g50(void);

extern union __PST__g__48 _main_gen_init_g48(void);

extern union __PST__g__46 _main_gen_init_g46(void);

extern union __PST__g__44 _main_gen_init_g44(void);

extern union __PST__g__42 _main_gen_init_g42(void);

extern union __PST__g__40 _main_gen_init_g40(void);

extern union __PST__g__38 _main_gen_init_g38(void);

extern union __PST__g__35 _main_gen_init_g35(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__35 _main_gen_init_g35(void)
{
    static union __PST__g__35 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__38 _main_gen_init_g38(void)
{
    static union __PST__g__38 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__40 _main_gen_init_g40(void)
{
    static union __PST__g__40 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__42 _main_gen_init_g42(void)
{
    static union __PST__g__42 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__44 _main_gen_init_g44(void)
{
    static union __PST__g__44 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__46 _main_gen_init_g46(void)
{
    static union __PST__g__46 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__48 _main_gen_init_g48(void)
{
    static union __PST__g__48 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__51 _main_gen_init_g51(void)
{
    static struct __PST__g__51 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._REQEN = bitf;
    }
    return x;
}

union __PST__g__50 _main_gen_init_g50(void)
{
    static union __PST__g__50 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g51();
    return x;
}

struct __PST__g__58 _main_gen_init_g58(void)
{
    static struct __PST__g__58 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._DRQS = bitf;
    }
    return x;
}

union __PST__g__57 _main_gen_init_g57(void)
{
    static union __PST__g__57 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g58();
    return x;
}

struct __PST__g__60 _main_gen_init_g60(void)
{
    static struct __PST__g__60 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x._DRQC = bitf;
    }
    return x;
}

union __PST__g__59 _main_gen_init_g59(void)
{
    static union __PST__g__59 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g60();
    return x;
}

union __PST__g__65 _main_gen_init_g65(void)
{
    static union __PST__g__65 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__67 _main_gen_init_g67(void)
{
    __PST__g__67 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__73 _main_gen_init_g73(void)
{
    __PST__g__73 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__76 _main_gen_init_g76(void)
{
    __PST__g__76 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__79 _main_gen_init_g79(void)
{
    __PST__g__79 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__84 _main_gen_init_g84(void)
{
    __PST__g__84 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__91 _main_gen_init_g91(void)
{
    __PST__g__91 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FlsMem_Pim_CodFlsCrcChkStrtTi(void)
{
    extern __PST__UINT32 FlsMem_Pim_CodFlsCrcChkStrtTi;
    
    /* initialization with random value */
    {
        FlsMem_Pim_CodFlsCrcChkStrtTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Pim_CodFlsSngBitErr(void)
{
    extern __PST__UINT8 FlsMem_Pim_CodFlsSngBitErr;
    
    /* initialization with random value */
    {
        FlsMem_Pim_CodFlsSngBitErr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FlsMem_Pim_CrcChkCmpl(void)
{
    extern __PST__UINT8 FlsMem_Pim_CrcChkCmpl;
    
    /* initialization with random value */
    {
        FlsMem_Pim_CrcChkCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FlsMem_Pim_CrcHwIdxKey(void)
{
    extern __PST__UINT32 FlsMem_Pim_CrcHwIdxKey;
    
    /* initialization with random value */
    {
        FlsMem_Pim_CrcHwIdxKey = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Pim_PwrOnRstCrcChkCmpl(void)
{
    extern __PST__UINT8 FlsMem_Pim_PwrOnRstCrcChkCmpl;
    
    /* initialization with random value */
    {
        FlsMem_Pim_PwrOnRstCrcChkCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DTSCfg(void)
{
    extern __PST__g__32 DTSCfg;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 128; _main_gen_tmp_0_0++)
            {
                /* struct/union type */
                DTSCfg[_main_gen_tmp_0_0].DMASSDTSA = _main_gen_init_g35();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTDA = _main_gen_init_g38();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTTC = _main_gen_init_g40();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTTCT = _main_gen_init_g42();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTRSA = _main_gen_init_g44();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTRDA = _main_gen_init_g38();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTRTC = _main_gen_init_g46();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTTCC = _main_gen_init_g48();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTFSL = _main_gen_init_g50();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTFSS = _main_gen_init_g57();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTFSC = _main_gen_init_g59();
            }
        }
    }
}

static void _main_gen_init_sym_DTSMstrCfg(void)
{
    extern __PST__g__62 DTSMstrCfg;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 128; _main_gen_tmp_1_0++)
            {
                /* struct/union type */
                DTSMstrCfg[_main_gen_tmp_1_0].DTSnnnCM = _main_gen_init_g65();
            }
        }
    }
}

static void _main_gen_init_sym_PINT0_BASE(void)
{
    extern __PST__g__67 PINT0_BASE;
    
    /* initialization with random value */
    {
        PINT0_BASE = _main_gen_init_g67();
    }
}

static void _main_gen_init_sym_PINTCLR0_BASE(void)
{
    extern __PST__g__73 PINTCLR0_BASE;
    
    /* initialization with random value */
    {
        PINTCLR0_BASE = _main_gen_init_g73();
    }
}

static void _main_gen_init_sym_UCFSERSTCLR_BASE(void)
{
    extern __PST__g__76 UCFSERSTCLR_BASE;
    
    /* initialization with random value */
    {
        UCFSERSTCLR_BASE = _main_gen_init_g76();
    }
}

static void _main_gen_init_sym_UCFSERSTR_BASE(void)
{
    extern __PST__g__79 UCFSERSTR_BASE;
    
    /* initialization with random value */
    {
        UCFSERSTR_BASE = _main_gen_init_g79();
    }
}

static void _main_gen_init_sym_UCF1SEDADR_BASE(void)
{
    extern __PST__g__84 UCF1SEDADR_BASE;
    
    /* initialization with random value */
    {
        UCF1SEDADR_BASE = _main_gen_init_g84();
    }
}

static void _main_gen_init_sym_UCF2SEDADR_BASE(void)
{
    extern __PST__g__84 UCF2SEDADR_BASE;
    
    /* initialization with random value */
    {
        UCF2SEDADR_BASE = _main_gen_init_g84();
    }
}

static void _main_gen_init_sym_UCF3SEDADR_BASE(void)
{
    extern __PST__g__84 UCF3SEDADR_BASE;
    
    /* initialization with random value */
    {
        UCF3SEDADR_BASE = _main_gen_init_g84();
    }
}

static void _main_gen_init_sym_UCF4SEDADR_BASE(void)
{
    extern __PST__g__84 UCF4SEDADR_BASE;
    
    /* initialization with random value */
    {
        UCF4SEDADR_BASE = _main_gen_init_g84();
    }
}

static void _main_gen_init_sym_ECM0ESSTC1_BASE(void)
{
    extern __PST__g__91 ECM0ESSTC1_BASE;
    
    /* initialization with random value */
    {
        ECM0ESSTC1_BASE = _main_gen_init_g91();
    }
}

static void _main_gen_init_sym_CCT_Range_01_Start(void)
{
    extern __PST__g__100 CCT_Range_01_Start;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < pst_random_g_8; _main_gen_tmp_2_0++)
            {
                /* base type */
                CCT_Range_01_Start[_main_gen_tmp_2_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_01_Address(void)
{
    extern __PST__g__100 CCT_Range_01_Address;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < pst_random_g_8; _main_gen_tmp_3_0++)
            {
                /* base type */
                CCT_Range_01_Address[_main_gen_tmp_3_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_01_Length(void)
{
    extern __PST__g__100 CCT_Range_01_Length;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < pst_random_g_8; _main_gen_tmp_4_0++)
            {
                /* base type */
                CCT_Range_01_Length[_main_gen_tmp_4_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_02_Start(void)
{
    extern __PST__g__100 CCT_Range_02_Start;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < pst_random_g_8; _main_gen_tmp_5_0++)
            {
                /* base type */
                CCT_Range_02_Start[_main_gen_tmp_5_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_02_Address(void)
{
    extern __PST__g__100 CCT_Range_02_Address;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < pst_random_g_8; _main_gen_tmp_6_0++)
            {
                /* base type */
                CCT_Range_02_Address[_main_gen_tmp_6_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_02_Length(void)
{
    extern __PST__g__100 CCT_Range_02_Length;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < pst_random_g_8; _main_gen_tmp_7_0++)
            {
                /* base type */
                CCT_Range_02_Length[_main_gen_tmp_7_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_03_Start(void)
{
    extern __PST__g__100 CCT_Range_03_Start;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < pst_random_g_8; _main_gen_tmp_8_0++)
            {
                /* base type */
                CCT_Range_03_Start[_main_gen_tmp_8_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_03_Address(void)
{
    extern __PST__g__100 CCT_Range_03_Address;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < pst_random_g_8; _main_gen_tmp_9_0++)
            {
                /* base type */
                CCT_Range_03_Address[_main_gen_tmp_9_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_03_Length(void)
{
    extern __PST__g__100 CCT_Range_03_Length;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < pst_random_g_8; _main_gen_tmp_10_0++)
            {
                /* base type */
                CCT_Range_03_Length[_main_gen_tmp_10_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_04_Start(void)
{
    extern __PST__g__100 CCT_Range_04_Start;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < pst_random_g_8; _main_gen_tmp_11_0++)
            {
                /* base type */
                CCT_Range_04_Start[_main_gen_tmp_11_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_04_Address(void)
{
    extern __PST__g__100 CCT_Range_04_Address;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < pst_random_g_8; _main_gen_tmp_12_0++)
            {
                /* base type */
                CCT_Range_04_Address[_main_gen_tmp_12_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_04_Length(void)
{
    extern __PST__g__100 CCT_Range_04_Length;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < pst_random_g_8; _main_gen_tmp_13_0++)
            {
                /* base type */
                CCT_Range_04_Length[_main_gen_tmp_13_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr(void)
{
    extern __PST__UINT32 FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr;
    
    /* initialization with random value */
    {
        FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr(void)
{
    extern __PST__UINT32 FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr;
    
    /* initialization with random value */
    {
        FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_ResvKey(void)
{
    extern __PST__UINT32 FlsMem_Srv_ResvCrcHwUnit_ResvKey;
    
    /* initialization with random value */
    {
        FlsMem_Srv_ResvCrcHwUnit_ResvKey = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_Return(void)
{
    extern __PST__UINT8 FlsMem_Srv_ResvCrcHwUnit_Return;
    
    /* initialization with random value */
    {
        FlsMem_Srv_ResvCrcHwUnit_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 FlsMem_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        FlsMem_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FlsMem_Op_CodFlsCrcChkCmpl : useless (never read) */

    /* init for variable FlsMem_Op_SwApplCrc : useless (never read) */

    /* init for variable FlsMem_Pim_CodFlsCrcChkStrtTi */
    _main_gen_init_sym_FlsMem_Pim_CodFlsCrcChkStrtTi();
    
    /* init for variable FlsMem_Pim_CodFlsSngBitErr */
    _main_gen_init_sym_FlsMem_Pim_CodFlsSngBitErr();
    
    /* init for variable FlsMem_Pim_CrcChkCmpl */
    _main_gen_init_sym_FlsMem_Pim_CrcChkCmpl();
    
    /* init for variable FlsMem_Pim_CrcHwIdxKey */
    _main_gen_init_sym_FlsMem_Pim_CrcHwIdxKey();
    
    /* init for variable FlsMem_Pim_PwrOnRstCrcChkCmpl */
    _main_gen_init_sym_FlsMem_Pim_PwrOnRstCrcChkCmpl();
    
    /* init for variable FlsMem_Pim_dFlsMemVrfyCrcInitCmpl : useless (never read) */

    /* init for variable DTSCfg */
    _main_gen_init_sym_DTSCfg();
    
    /* init for variable DTSMstrCfg */
    _main_gen_init_sym_DTSMstrCfg();
    
    /* init for variable PINT0_BASE */
    _main_gen_init_sym_PINT0_BASE();
    
    /* init for variable FlsMem_Pim_CodFlsDummyRead1 : useless (never read) */

    /* init for variable FlsMem_Pim_CodFlsDummyRead2 : useless (never read) */

    /* init for variable FlsMem_Pim_CodFlsDummyRead3 : useless (never read) */

    /* init for variable FlsMem_Pim_CodFlsDummyRead4 : useless (never read) */

    /* init for variable PINTCLR0_BASE */
    _main_gen_init_sym_PINTCLR0_BASE();
    
    /* init for variable UCFSERSTCLR_BASE */
    _main_gen_init_sym_UCFSERSTCLR_BASE();
    
    /* init for variable UCFSERSTR_BASE */
    _main_gen_init_sym_UCFSERSTR_BASE();
    
    /* init for variable UCF1SEDADR_BASE */
    _main_gen_init_sym_UCF1SEDADR_BASE();
    
    /* init for variable UCF2SEDADR_BASE */
    _main_gen_init_sym_UCF2SEDADR_BASE();
    
    /* init for variable UCF3SEDADR_BASE */
    _main_gen_init_sym_UCF3SEDADR_BASE();
    
    /* init for variable UCF4SEDADR_BASE */
    _main_gen_init_sym_UCF4SEDADR_BASE();
    
    /* init for variable ECM0ESSTC1_BASE */
    _main_gen_init_sym_ECM0ESSTC1_BASE();
    
    /* init for variable CCT_Range_01_Start */
    _main_gen_init_sym_CCT_Range_01_Start();
    
    /* init for variable CCT_Range_01_Address */
    _main_gen_init_sym_CCT_Range_01_Address();
    
    /* init for variable CCT_Range_01_Length */
    _main_gen_init_sym_CCT_Range_01_Length();
    
    /* init for variable CCT_Range_02_Start */
    _main_gen_init_sym_CCT_Range_02_Start();
    
    /* init for variable CCT_Range_02_Address */
    _main_gen_init_sym_CCT_Range_02_Address();
    
    /* init for variable CCT_Range_02_Length */
    _main_gen_init_sym_CCT_Range_02_Length();
    
    /* init for variable CCT_Range_03_Start */
    _main_gen_init_sym_CCT_Range_03_Start();
    
    /* init for variable CCT_Range_03_Address */
    _main_gen_init_sym_CCT_Range_03_Address();
    
    /* init for variable CCT_Range_03_Length */
    _main_gen_init_sym_CCT_Range_03_Length();
    
    /* init for variable CCT_Range_04_Start */
    _main_gen_init_sym_CCT_Range_04_Start();
    
    /* init for variable CCT_Range_04_Address */
    _main_gen_init_sym_CCT_Range_04_Address();
    
    /* init for variable CCT_Range_04_Length */
    _main_gen_init_sym_CCT_Range_04_Length();
    
    /* init for variable FlsMem_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable FlsMem_Srv_ResvCrcHwUnit_Mod : useless (never read) */

    /* init for variable FlsMem_Srv_ResvCrcHwUnit_CrcCfg : useless (never read) */

    /* init for variable FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr */
    _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr();
    
    /* init for variable FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr */
    _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr();
    
    /* init for variable FlsMem_Srv_ResvCrcHwUnit_StrtVal : useless (never read) */

    /* init for variable FlsMem_Srv_ResvCrcHwUnit_ResvKey */
    _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_ResvKey();
    
    /* init for variable FlsMem_Srv_ResvCrcHwUnit_Return */
    _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_Return();
    
    /* init for variable FlsMem_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable FlsMem_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable FlsMem_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable FlsMem_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable FlsMem_Srv_SetNtcSts_Return */
    _main_gen_init_sym_FlsMem_Srv_SetNtcSts_Return();
    
}
