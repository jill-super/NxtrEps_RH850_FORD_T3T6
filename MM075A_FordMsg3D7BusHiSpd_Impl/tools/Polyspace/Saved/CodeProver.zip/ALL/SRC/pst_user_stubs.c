/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_ClrDiagcFlgProxy_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_ClrDiagcFlgProxy_Val"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_ClrDiagcFlgProxy_Val(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_FordCanDtcInhb_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_FordCanDtcInhb_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_FordCanDtcInhb_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_FordCanDtcInhb_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_FordCanDtcInhb_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_FordEpsLifeCycMod_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_FordEpsLifeCycMod_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_FordEpsLifeCycMod_Val"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_FordEpsLifeCycMod_Val"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_FordEpsLifeCycMod_Val(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_FordEvasSteerAssiEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_FordEvasSteerAssiEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_FordEvasSteerAssiEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_FordEvasSteerAssiEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_FordEvasSteerAssiEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjClass_D_Stat1_Ford_CmbbObjClass_D_Stat
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjClass_D_Stat1_Ford_CmbbObjClass_D_Stat"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjClass_D_Stat1_Ford_CmbbObjClass_D_Stat"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjClass_D_Stat1_Ford_CmbbObjClass_D_Stat"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjClass_D_Stat1_Ford_CmbbObjClass_D_Stat(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjColl_T_Actl_Ford_CmbbObjColl_T_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjColl_T_Actl_Ford_CmbbObjColl_T_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjColl_T_Actl_Ford_CmbbObjColl_T_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjColl_T_Actl_Ford_CmbbObjColl_T_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjColl_T_Actl_Ford_CmbbObjColl_T_Actl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjConfdnc_D_Stat1_Ford_CmbbObjConfdnc_D_Stat
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjConfdnc_D_Stat1_Ford_CmbbObjConfdnc_D_Stat"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjConfdnc_D_Stat1_Ford_CmbbObjConfdnc_D_Stat"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjConfdnc_D_Stat1_Ford_CmbbObjConfdnc_D_Stat"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjConfdnc_D_Stat1_Ford_CmbbObjConfdnc_D_Stat(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLat_L_Actl_Ford_CmbbObjDistLat_L_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLat_L_Actl_Ford_CmbbObjDistLat_L_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLat_L_Actl_Ford_CmbbObjDistLat_L_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLat_L_Actl_Ford_CmbbObjDistLat_L_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLat_L_Actl_Ford_CmbbObjDistLat_L_Actl(__PST__g__36 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLong_L_Actl_Ford_CmbbObjDistLong_L_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLong_L_Actl_Ford_CmbbObjDistLong_L_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLong_L_Actl_Ford_CmbbObjDistLong_L_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLong_L_Actl_Ford_CmbbObjDistLong_L_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLong_L_Actl_Ford_CmbbObjDistLong_L_Actl(__PST__g__36 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLat_V_Actl_Ford_CmbbObjRelLat_V_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLat_V_Actl_Ford_CmbbObjRelLat_V_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLat_V_Actl_Ford_CmbbObjRelLat_V_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLat_V_Actl_Ford_CmbbObjRelLat_V_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLat_V_Actl_Ford_CmbbObjRelLat_V_Actl(__PST__g__36 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLong_V_Actl_Ford_CmbbObjRelLong_V_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLong_V_Actl_Ford_CmbbObjRelLong_V_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLong_V_Actl_Ford_CmbbObjRelLong_V_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLong_V_Actl_Ford_CmbbObjRelLong_V_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLong_V_Actl_Ford_CmbbObjRelLong_V_Actl(__PST__g__36 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D7BusHiSpd_Ford_EsaEnbl_D2_Rq1_Ford_EsaEnbl_D2_Rq
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D7BusHiSpd_Ford_EsaEnbl_D2_Rq1_Ford_EsaEnbl_D2_Rq"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D7BusHiSpd_Ford_EsaEnbl_D2_Rq1_Ford_EsaEnbl_D2_Rq"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D7BusHiSpd_Ford_EsaEnbl_D2_Rq1_Ford_EsaEnbl_D2_Rq"
//
// __PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_EsaEnbl_D2_Rq1_Ford_EsaEnbl_D2_Rq(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLatDstRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLatDstRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLatDstRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLatDstRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLatDstRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLgtDstRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLgtDstRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLgtDstRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLgtDstRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLgtDstRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjDataConfLvlRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjDataConfLvlRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjDataConfLvlRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjDataConfLvlRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjDataConfLvlRaw_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjTypClassnRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjTypClassnRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjTypClassnRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjTypClassnRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjTypClassnRaw_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLatVelRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLatVelRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLatVelRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLatVelRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLatVelRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLgtVelRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLgtVelRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLgtVelRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLgtVelRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLgtVelRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgTiToCllsnRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgTiToCllsnRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgTiToCllsnRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgTiToCllsnRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgTiToCllsnRaw_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiEnadReqRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiEnadReqRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiEnadReqRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiEnadReqRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiEnadReqRaw_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiImgProcrModlAVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiImgProcrModlAVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiImgProcrModlAVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiImgProcrModlAVld_Logl"
//
// __PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiImgProcrModlAVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldMissThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldMissThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldMissThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldMissThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldMissThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstRawVldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstRawVldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstRawVldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstRawVldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstRawVldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelRawVldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelRawVldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelRawVldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelRawVldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelRawVldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelRawVldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelRawVldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelRawVldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelRawVldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelRawVldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnRawVldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnRawVldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnRawVldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnRawVldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnRawVldFaildThd_Val(__PST__VOID)
// {
//    ...
// }

