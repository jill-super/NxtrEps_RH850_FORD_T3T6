#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_FordMsg3D7BusHiSpd_ClrDiagcFlgProxy_Val
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_ClrDiagcFlgProxy_Val(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_FordCanDtcInhb_Logl
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_FordCanDtcInhb_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_FordEpsLifeCycMod_Val
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_FordEpsLifeCycMod_Val(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_FordEvasSteerAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_FordEvasSteerAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjClass_D_Stat1_Ford_CmbbObjClass_D_Stat
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjClass_D_Stat1_Ford_CmbbObjClass_D_Stat(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjColl_T_Actl_Ford_CmbbObjColl_T_Actl
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjColl_T_Actl_Ford_CmbbObjColl_T_Actl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjConfdnc_D_Stat1_Ford_CmbbObjConfdnc_D_Stat
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjConfdnc_D_Stat1_Ford_CmbbObjConfdnc_D_Stat(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLat_L_Actl_Ford_CmbbObjDistLat_L_Actl
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLat_L_Actl_Ford_CmbbObjDistLat_L_Actl(__PST__g__36 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLong_L_Actl_Ford_CmbbObjDistLong_L_Actl
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjDistLong_L_Actl_Ford_CmbbObjDistLong_L_Actl(__PST__g__36 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLat_V_Actl_Ford_CmbbObjRelLat_V_Actl
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLat_V_Actl_Ford_CmbbObjRelLat_V_Actl(__PST__g__36 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLong_V_Actl_Ford_CmbbObjRelLong_V_Actl
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_CmbbObjRelLong_V_Actl_Ford_CmbbObjRelLong_V_Actl(__PST__g__36 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg3D7BusHiSpd_Ford_EsaEnbl_D2_Rq1_Ford_EsaEnbl_D2_Rq
 */


__PST__UINT8 Rte_Read_FordMsg3D7BusHiSpd_Ford_EsaEnbl_D2_Rq1_Ford_EsaEnbl_D2_Rq(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLatDstRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLatDstRaw_Val"


__PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLatDstRaw_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLgtDstRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLgtDstRaw_Val"


__PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgLgtDstRaw_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjDataConfLvlRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjDataConfLvlRaw_Val"


__PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjDataConfLvlRaw_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjTypClassnRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjTypClassnRaw_Val"


__PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgObjTypClassnRaw_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLatVelRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLatVelRaw_Val"


__PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLatVelRaw_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLgtVelRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLgtVelRaw_Val"


__PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgRelLgtVelRaw_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgTiToCllsnRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgTiToCllsnRaw_Val"


__PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehCllsnMtgtnByBrkgTiToCllsnRaw_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiEnadReqRaw_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiEnadReqRaw_Val"


__PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiEnadReqRaw_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiImgProcrModlAVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiImgProcrModlAVld_Logl"


__PST__UINT8 Rte_Write_FordMsg3D7BusHiSpd_FordVehEvasSteerAssiImgProcrModlAVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldMissThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldMissThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldMissThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdImgProcrModlAVldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstInvldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstRawVldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstRawVldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLatDstRawVldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdLgtDstInvldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdMissMsgPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelInvldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelRawVldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelRawVldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLatVelRawVldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelInvldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelRawVldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelRawVldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdRelLgtVelRawVldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnInvldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnRawVldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnRawVldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg3D7BusHiSpd_FordMsg3D7BusHiSpdTiToCllsnRawVldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

