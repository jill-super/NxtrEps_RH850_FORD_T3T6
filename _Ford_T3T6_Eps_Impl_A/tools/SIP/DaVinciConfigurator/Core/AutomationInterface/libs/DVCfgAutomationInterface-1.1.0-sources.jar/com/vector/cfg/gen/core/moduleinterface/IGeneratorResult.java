package com.vector.cfg.gen.core.moduleinterface;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.util.text.format.IFormattable;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * A GeneratorResult represents a result, which is shown in the GUI of the Cfg. A Result could be a ERROR, WARNING, IMPROVEMENT or INFO.
 *
 * <p>
 * Please use <code>com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder</code> to create instances of {@link IGeneratorResult}s.
 * </p>
 *
 * <div class="extdoc" id="Common">
 *
 * An {@link IGeneratorResult} is also an {@link IValidationResult} so we will to the terms interchangeably. You should always use {@link IGeneratorResult}s, because they
 * provide a broader API for the generator use case, such as API for the Definition model <!--LaTeX: (See \vref{sec:BswmdModel})-->
 *
 * The figure <!--LaTeX:\vref{fig:IGeneratorResultClasses}--> show the class hierarchy of {@link IGeneratorResult}s.
 *
 * <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaAAAAE+CAYAAADLWsRqAAAABmJLR0QA/wD/AP+gvaeTAAAeyElEQVR4nO3df4wUdZ7/8dfwa5iBgfkNCozADL9FEQT8/eMPc8nirtxFdwCT85I12dwmu8n9sRuS3XxDslEvuskZc/FWw+55t7ugG3fWH7CnKC4oigKOoiDyYwYc5Ncwv+THDIPj1PePnq6urh/d1T3d/emZeT6Ska5PfarqXT1YL+pT1dUFlmVZAgAgtxpGma4AADAyEUAAACMIIACAEQQQAMAIAggAYMSYXG+wra1NO3fuVH9/f643jWGqpKRE9913n0aPHm26FAApyHkA/fKXv9Tzzz+f681imNu6dau+973vmS4DQApyHkCXLl2SJG3+n/9ytFpxfzhexL2MTbo/uhRb3vdDTVaCZQK7xddg+a/Zt6973b6bdzR49slvU56PayWoyPKbH/Tm+G/U9+Nhcb+mJO9nwP5afu+vfwWuBv/3p2HLdv3f9l3q6ury1gsgr+U8gKIeXL3KMWW5/gg+oNsHP7+Dk+Xt6VxH/CIBB/TQAWSFqjfWlGh5/3rjy0mt3mQBZMVv3FtzFuqNb3YHVrLAtFylRqa+7evT/23fJQBDDzchAACMIIAAAEYQQAAAIwggAIARBNCAoqp5Kq6aZ08XV89XcfX8hMtMmLpQE6YuzMj2J027UZOm3ZiRdeWjqjl3qmrOnabLAJBHjN0Fl45xZbPipns7miVJheW1ken2prj54yvqJElX2o7loLpwSq5dLEm6ePqzrG+r7Lqbfds7T+zN+rbDqJ57lySp9ci7hisBYMKQCqCrncftEIqGT7Z0t36Z1fW7XTi1P2vr7vxqn6K3NZfNXK6ymcvVcWJP1rYHAGEMqQDKhKLKOXHTPeeP+PaLDr85g2jClAWhtjHxmuvjpi+eOSApdvYTeX1DZN6pyJlQdPgtGkSTpi/xrPebk5/YryfPWCpJ6mppVGnNUru9q+XjUDW6lc9a6Wlrb/4wbrqi9ta46bamDyRJlXW3RaaPvW/Pq5pzhyTp/FH/z+hEz36cr88d3plq2QCGsGFxDai3IzL0VlhRa7fZw2/tseG3oso56mk7GvkZCJ6iqrmhthENn8vnDg38fOHbb+I1i3TpzAH7R5JKBgLp4unP7X4XT39mh4/bpOkDYfT1p/pm4EeSJs+4ydO3tGapuloa7eAprVkWan+cymetkCR1HP/I/pGkitm32H0qZkfCp71pt9qadqut6QNV1t6W8rainMNurUfeVSvhA4w4I+oMqKftaNa3cenMQSV55k1GdbU0Ju3jvhbUeWJvkkcLBauovVVtTbslxc6AACAdwyaAejuaVFheq/GOsyDn2Y/kHX7LhonXLMr6NlLV+dU+O4QS3YDgNwwX1d682z4LqhwYiiOAAAzGsAmgZMYPhI99FmRZoYffwpo4NRI+0aE3yXs9yJTOr/aq7LrIDQhBIRQdepP8H0baPnDmE70WVFl7GyEEIG3D4hpQlPM2bPfZT6ZNmJKZz//kUjR4ymYuD9Xf7xqQJHsILkhV3e1pVAdgpBlSZ0DOzwEVls9O6VbsK21HNb5yTtrDcJfPHdKEKQscNyN84QmhS2cPauLURQnPei6e/lwl1y723AXndOHr/Zo0/UbPnXDOu+DS1Xlir8pmLlf5zBX2rdgdx/eofNYKzxCc8y445xBcVPTsp+3YB6qsu02VA8Fz/tj7oUKo9ci7qp57F3fBASNUgeX7xS/Z8/DDD2vTpk369psWRytfx8DXMaT3dQwNW7brJz9/TH/605+0bt06ARgyGobVEBwAYOgggAAARhBAAAAjCCAAgBEEEADACAIIAGAEAQQAMIIAAgAYQQABAIwggAAARhBAAAAjjD2M9OVXtjqmEjyXzP3IML9G32fBuWcHLBPYLdmz4ALWFfgsuOBl/J+t5u4e8Cy4wHKSPVstuJ7I5nw6Bz0Lzm86YH8DnwXnrcD/eX+ul42fHfLWCWBIMBZAax/5V1ObBgDkAWMBtPl//ssxxRkQZ0DpnQF91Pi5Nv6hwVsrgLxnLIAeXL3KMWW5/gg+oNsHP7+Dk+Xt6VxH/CIBB/TQAWSFqjfWlGh5/3rjy0mt3mQBNFy+juHbvj4BGJq4CQEAYAQBBAAwggACABhBAAEAjCCAAABGEEAAACMIIACAEQQQAMAIAggAYAQBBAAwggACABhBAAEAjCCAAABGEEAAACMIIACAEQQQAMAIAggAYAQBBAAwggACABhBAAEAjCCAAABGEEAAACMIIACAEQQQAMAIAggAYAQBBAAwYoypDb/8ylbHlBX3h+NF3MvYpKvRsbx7Tmx2wDKB3eJrsPzX7NvXvW7fzTsaPPvktynLW39gRZbf/KA3x3+jlmd7cr7NPkX6/qI8DZbf++tfgavB//15/Y2d3joBDAk5D6CJEydKktY+8q+53jSGsdLSUtMlAEhRgeX7T93saWtr086dO9Xf35/LzQ45zz77rHbs2KENGzZo4cKFpsvJayUlJbrvvvs0evRo06UACK8h5wGE5Pr6+jRt2jT19vaqvr5ezz33nOmSACDTGrgJIQ+9/fbb6uvr0wsvvKC//OUv+vbbb02XBAAZRwDloU2bNunBBx/UqlWrVFBQoG3btpkuCQAyjgDKM1euXNErr7yiNWvWaOzYsXrooYe0adMm02UBQMYRQHlmy5YtKikp0d133y1JWrdunV599VVdvnzZcGUAkFkEUJ7ZtGmT1qxZo1GjIr+a22+/XRUVFXr11VcNVwYAmUUA5ZGuri797W9/07p16+y2goIC1dfX66WXXjJYGQBkHgGUR/7617+qpqZGy5Yti2tft26d3njjDXV0dBiqDAAyjwDKI5s3b9batWs97UuWLFFdXZ1efvllA1UBQHYQQHni7Nmzeuedd+KG35zWrVvH3XAAhhUCKE+89NJLWrJkiebNm+c7v76+Xu+9955Onz6d48oAIDsIoDyxefNmrVmzJnB+XV2dbr75Zr344os5rAoAsocAygPNzc3at2+f6uvrE/ZjGA7AcEIA5YHNmzfrjjvu0IwZMxL2q6+v16effqrDhw/nqDIAyB5jX0iHmMcff1yrVq3S22+/nbTvd999p40bN+qpp57KQWUAkD0EkGH9/f3q7e3VW2+9pY8//thu//bbb9XV1aWqqirPMp2dnbksEQCyggAybNSoUerr6/O079q1S/fff7+ampoMVAUA2cc1IACAEQQQAMAIAggAYAQBBAAwggACABhBAAEAjCCAAABGEEAAACMIIACAEQQQAMAIAggAYAQBBAAwggACABhBAAEAjCCAAABGEEAAACMIIACAEQQQAMAIAggAYAQBBAAwggACABhBAAEAjCCAAABGEEAAACMIIACAEQQQAMAIAggAYAQBBAAwggACABhBAAEAjCCAAABGEEAAACMIIACAEQQQAMAIAggAYAQBBAAwggACABhBAAEAjCCAAABGEEAAACMIIACAEQQQAMCIMbnaUHt7u37xi1/o4sWLudrkkNbW1qbu7m798Ic/NF3KkLF06VKtX7/edBkAQiqwLMvKxYZefPFFrV27NhebwgiWo7/OAAavIWdnQP39/ZKk/934jNY+tNoxx5Is+5X939hLK37S0d/ZGmt2HYAG1hG/iPsgZbk2FT/fe1CzXGUG12zPT6Pm+JJSq1mW5akiUzV7lk+h5vjmEDXHr9BndyMvfvLzx9SwZbsADB1cAwIAGEEAAQCMIIAAAEYQQAAAIwggAIARBBBypmrOnaqac6fpMgDkiZzdhj0Y48pmxU33djTbrwvLaz39r7Qfy3pN2TBp2o2SpAtf78/YOsuuu9m3vePEnoxtI13Vc++SJLUeeddwJQBMGBIBdLXzuB1CvZ3N9mdACstnR9o6muI+UzO+om7IhlC2dH61137fymYuV/nMFXkRQgBGriERQJlQVDnH09Zz/oj9urhqniSpu/Wwiqvn2+3drV/GLTNhygLPei6dPShJmjh1UWT6zAFNvOZ6+7VTybWL46YvnPpMUuzsR5ImTY+eCX1qt02ecZNnu10nGyVJpTVLI9MtH6u0Zlnk9Vf7PP2TKZ+10tPW3vyh/bpi9q1x89qaPrBfV9bdFmk79r7dVjXnDknS+aO7POutnnun4/XAmdDhnSnXDGDoGpYB5D77GT8QPj1tRyMNlqWiqrkqqpobF0KSVFw9zw6d4ur5Kq6er8vnDkmKhc/lc1/YZxMTpi7UxKmL7BCSZIePW8m1i3Xx9OeKLlxy7Q2aNO0GXTi1XxdO7XcNwcWeCTB5+hJJ0jcnP4m1zbhJpTOWqqul0W6Lhk86ouHTcfwjSZFnDlTMukUVs29Re/OHdvi0N+2251fW3hYXQqloPfKeHUL2EByP0QFGlGEVQOMrYteD0h2C6249LM8jYlLkPuuJioRP9nS1fBybcB3My65bHjed7vBbRe2tdgilGz4AIA2zALrS3hQXQm5+w3DpmDBlYVrLuYffcqnzq712CHWe2Ot9ltsAv2E4SWpv3m2fBVXURv4kgAAMxrAKoGScQ3CD4RyCk3wezOkjGj7uIbhc6jyxV2Uzl6ts5vLAMyDnEJx7t9qbd0tWLIAGMwQHACP6c0BFVXMzsp7ozQdDQeeJvZKk8pkrQvWvmH3LwJ+xGxCiQ3CJVNXdnkZ1AEaSIXEG5PwcUGHZbPtzQL0dzSosn+37WSCnK21HNb5yjmcIzn0DQjKXzx3ShCkLPENwzhsQglw8/blKrl2ccBgueiOC+y64b77+VJOnL/HcCdd1sjGty1XRMyHnrdgdxz9S+ayVniG46F1wziG4KOfZT9uxD1RZd5sqB4Ln/LH3k4ZQ65F3VT33Lu6CA0aoIRFAVzuPS/L/PqDejibFN/sfke3hN8l3CK77/GHPotG74ZzfBxS5I87/u3UunT3o+906UbGbEIK/D+jCqf2+63DeARe/VQ3cCee/zU77duz4+X5DcNHhN3vtAUNw8VuPid6CHZ3jvv36/NH3IvMdi8Z9CJW74IARZUQPwQEAzCGAAABGEEAAACMIIACAEQQQAMAIAggAYAQBBAAwggACABhBAAEAjCCAAABGEEAAACNy/iy4//ztf+u1LW/6zvN/EphPa8JHhoVYi6dLqs8gcz8LLkT/FJqdM5Ou2/K8CMVKbQeSd/JdXYrva4hnwXl7RFoa9x9KbVsAjMt5AO3Z94n27HM/WBMAMNLkPID+d+MzWvvQakeL5XjCcuy/sZfuf0+7n9Ic/GRp5zriF3H/O9pybSp+vuXTP/AL6XyeZO19snS4muNLSq1mWe7nVWeuZs/yKdQc3xyi5vgV+uxu5MVPfv6YGrZsF4Chg2tAAAAjCCAAgBEEEADACAIIAGAEAQQAMIIAAgAYQQABAIwggAAARhBAAAAjCCAAgBEEEADACAIIAGAEAQQAMIIAAgAYQQABAIwggAAARhBAAAAjCCAAgBEEEADACAIIAGAEAQQAMIIAAgAYQQABAIwggAAARhBAAAAjCCAAgBEEEADAiDG53uA/P/ozvbblTd95VthW/47h1+LpknCF/muz4qaS90+hWZIsq1/dPVdUXFwUctWp7YOV2g4k7+S7uhTfVyuddzLS8vobO1PbFgDjchZAixYtsl+//MrWXG0WI8iCBQtMlwAgBQWWFeKfncgpy7JUV1en5uZm/epXv9Kvf/1r0yUBQKY1cA0oD23btk0nT56UJD3zzDPq6ekxXBEAZB4BlIc2bNig7777TpJ09epV/fGPfzRcEQBkHkNweeaTTz7R8uXL7QCSpJqaGh0/flyjRvHvBQDDBkNw+ebJJ5/U6NGj49rOnj2r119/3VBFAJAdnAHlkZMnT2rWrFlxZz+SNGrUKK1YsUK7d+82VBkAZBxnQPnk6aef1tixYz3t/f392rt3rxobGw1UBQDZwRlQnrh06ZKmTJmi7u5u3/ljxozR97//fTU0NOS4MgDICs6A8sXvf/979ff3e9rHjx8vSerr69Nrr72mlpaWXJcGAFlBAOWBvr4+PfbYY7py5YokaezYsZo8ebIkadmyZSosLJQUOQt6+umnjdUJAJlEAOWBhoYGXbhwQZJUWFion/70p1q/fr0kaevWraqpqdHYsWPV29ur3/72t+rq6jJZLgBkBAGUBx5//HH19vaqsLBQDzzwgH7zm9/Y8yZPnqx33nlHpaWlGjMm8ui+jRs3mioVADKGADJs586d2r9/v8aMGaObb75Zf/jDH1RQUBDXZ/r06dq+fbsmTJignp4ePfXUU+rr6zNUMQBkBgFk2OOPPy5Jmj9/vrZu3apx48b59lu8eLHefPNNjR49Wq2trfrzn/+cyzIBIOMIIIOOHj2qbdu2SZK2b99u33gQZOXKlfZt2A8//HDW6wOAbCKADFq5cqWkSBBVVVWFWuYHP/iBnnjiCUnSli1bslYbAGRbzr8RFTGbN29WcXGx6urqPPOWLl2q4uJi3+XWr1+vyspKLVu2LNslAkDW8CSEPLVr1y7df//93HINYLjiSQgAADMIIACAEQRQniotLdU999xjugwAyBquAQEATOAaEADADAIIAGAEAQQAMIIAAgAYQQABAIwggAAARhBAAAAjCCAAgBEEUJ7q6urSjh07TJcBAFlDAOWpAwcOaPXq1abLAICsIYAAAEYQQAAAIwggAIARBBAAwAgCCABgBAEEADCCAAIAGDEiAqigoMB0CVmrIR/2DQDSMcZ0AdkUPTgPxW8dLy0t1T333JO0n2VZQ3o/AYxcBdYwPGqFOSA7zxyc/QoKCgIP6kHL+M139vE7S8nEeoP6DcNfKYDhp2FYnQGFPQBHQybs9GCXiQZaULgMtpYod+ARRADy2bC5BuQ82Ifp55RsOmiZZGcuYWtOtF4/ybblDD0AyFfD5gwo29dCwhzM0znghwmbVPeLMyAAQ8GwCSApu0NQ6ZxZhQmkMDWG3S+CB8BQMqwCKCrX10KCrslkmnO//G5iIHgADCXD5hqQH79rIX7XRlIZBgu7XNizn2TrTbaesNe+ACDfDMszILdM3EDgFxbR5YLmJQq+ZMuG2W7Y2gEgH42IAPITdOBOdEBPdV6yu+vCrDfMfAAYiob1ENxQ1tXVpR07dpguAwCyhgDKUwcOHNDq1atNlwEAWUMAAQCMIIAAAEYQQAAAIwggAIARBBAAwAgCCABgBAEEADCCAAIAmGH56OrqssaNG2dJ4oefEf3zyCOP+P0vknULFiwwvu/88JPop6amxmpqahrMX/O/+D4LrqWlRVevXpUkPbh6lV+XOFaqc4IXCN3JMzd5Q4osz2rCrzFJz6QrsnxepbLZwe27ld5Op7aAFTQ5iNqt1Jb37xlrff2NnWpsbEy/nkE4dOiQJOmf/vGfjGwfSOStt99SS0uL7r33Xv3973/X7Nmz01pPwoeR/uLffqLHNqx3tfodmIOOJn6HFSs4LKwkByLHAcZyzwhYp/eY5K3VU7+rpliL3356l7V86/Gu029PIk0B74LvQ0kdVSUKoET76dktvwAKu5/eZX330/XeJf774VpLUE2J/n74dk+8n/c2P+pXSM7U/7BeL/zuBaM1AH7+5Uf/opf+/JJOnTo1qBDiGhAAIC0bn9toh1Bzc3PKyxNAAIC0rKlfM6gQIoAAAGkbTAgRQACAQUk3hAigEa7suuUqm7k8J9uqrL1NlbW3xabrbldl3e0Jl6mac4eq5tyR7dIADFI6IZSVr+QeVzbT09bbeTwbm8q6CVMXSpIun/0iY+ssmXaDb/uFU/szto10RcOo48SeuPbyWSt9+7c3f5j1mgAMDWvq10iSHv3xo6Hujst4AI0rnSlJutp5Qs5bWseVzRqyIZQtF059puh7NGnajZo07ca8CKFEOo5/ZL8un7VSFbNvCR1CbU0fZKssAHkilRDKyhlQWIXl3qKutDfZr8dX1A20HbNfS9KVtqNxyxRVzvWsp+f8YUlScdU8SVJ362EVV0dffxnXd8KUBXHTl88dGmhfGOszcCZ06exBu23iNYs827105oAkqeTaxZKki6c/d7z+zNM/mcnTl3javjn5SWz+jKVx87paYh+cLK1ZNtD2sd1Wdt3NkqTOr/Z51usciiufuUKS1HF8j6efn4rZt0iS2pt3x9pqb5UktTVF2qLDb4mCqKou8XBb9Zw7PW2tR96NzZ93tyTp3OGdmmK/3pGsfAApmHndTBUVFamopChhv5aWFt199906efKk7/ycBZD77CcaPr0dzYqeBRSW12p8RW1cCEmRILrSfkyypPGVdRpfOUc9AyFUVDlHktRz/ojdv6hqroqq5tkhJMkOH7fiKfPtwJEiYTRhygJdPveFLp/7wg6hy2e/iPvg4sSpkfCJBo4kTbzmek285npdPPO53RYNn3RMGgifb77+NNJgWZo84yZNnnGTvjn5iSbPuEmS1HVyIHQsqbRmaVzgpKLzxF7vENxgHyiRgqqB60Hnj+6KtTmu/1QNhE/rkfcGWixVz71L1XPvigshSXb4AMi8Df9vg670XgkMlqjt27fr66+/Dpyf9QAaVzbLfp3uENyV9mODrqO7NRpG8UfU7nNfBjwhIDMunv7cMRW/nUmua0HpDr+Vzlhqh1DkDCh7++O+FpSv14DOHd7pmMphigIjxL8/9u9J+0SfmBAk6wF0tfN4XAi5+Q3DpaOoyjsMF0bxlPkZ2X46Lpz6zA6hROHjNwwnKe4sqHRgKM45BJcNg7kGlCnVc73DcACGHqPXgKT4IbjAx4CF4ByCs1eWRHF1JHzcQ3C5dOHU/qQ3IDiH4DzzTjbKUiyABjMEN1Q4h+AADF159zmg8RW1GVlPUZX/NZ98FA2eSdNuDNU/etYT/VNyXAdKIHoDQi5UzL510OsI+/mf6rl3DXpbAHIv42dAV7tOaFzpTN/PAjn1djSrsHy2ZwjOfQNCMj1tR1VUOcczBOe8ASFId+uXKq6en/Cs5/LZLzRh6kLPXXCXzh7UxKmLNPGa6+P6XzpzIK1rSnFnQgNnPBe+/lSTpi/xDMFF74JzDsFFOa8BdbV8rNKaZfbdcJ1f7UsaQtEbEYLuggu6BtTe/KEqZt9iB0978+6UQ+j8sfdVVXe7HTznj+6KC6HzR99T1Zw7PUNw7hsQAAwNWRmCi3wGSEr2LS+R4TfHXNcQnN/NB9FbsJ39etqOBH4tQPf5wwlHaoJvQoi1RT+E6u536cxBBa08/uYD17xTn7m2EGEPwTmG2uzhN1e7PX9gCM53hXLcgj3wdQzu2687v9rrWS7uQ6gD85zXfmKz4n9hkTCKNbQP3H4dbXHfft127H3POs8f2xW3ztgdcZHG1qPvJfyKiNaBmw8YnAPyX94NwQEARgYCCABgBAEEADCCAAIAGEEAAQCMIIAAAEYQQAAyItmTkZEf8un3RAABw0jQwSUbB5101pnqMvl0sExmKNUaZbpmAghAzvRc7DFdAvKI8YeRAsg95798naHg/hdxUGBE+0X/DFqHe/mikiL1XOxJ2CfZNsLW6FdPtL+7jjDrDjMv3VrTqcc937lM0Pvut2yibWb7HwwEEDDCuA9GzoNfmAOXpND90+0TtI1Uakx1XrJ1J5uX6VqTLR/2fQwSpuZU15kqAghIoLu7Wz/+8Y+T9luxYoV+9KMfJe23Z88e/e53v8tEaRmTyQNMOusyNSyXb8OBg60nG/tj9Azoyf94Vk/+x7NZLQDIZ7W1mfl6kHySaAgsFxelww7BmZBo/3Nx00Uqy2fjfcz17yZhAM2bW6vFC5N/Y2jwk4cD5oR6VHHiTgEPv051I8m3YHlawi+b5uxkTxFPvtjg9t1Kb6dTW8AKmhxE7VZqy/v3jLXufH+fiouL9dxzz6Vfk8uKFSu0YsWKpP2ef/75jG3TT9AwS67CIJfDPKlIZSgvTLhk+6wmG+9j3gzBPbDqH/TYhvWuVr8Dc9DRxO+w4ve1p35fx+BzeHAcYCz3jIB1eo9J3loTfh1D0v30Luv+moKgdfrtSaQp4F3w+TqGuKoSBVCi/fTsll8Ahd1P77K+++l67xL//XCtJaimRH8/fLsn3s97H3jUr5C8lulx/WwcgPIpcJIJqjXdM5vB7nuia0CJlslVfaniGhAwzCQbRgma7273WzZoPelc/E5nG4OpMVn/RH39ag66uy7dWlOtPezv0W89YWvmLjgAKUtl6CaV5RL1D7qTzW861QNxoulUl0+0jmRhlup6w9aa7u8j7HKJfk+DfX8Hgw+iAgCMIIAAAEYQQAAAIwggAIARBBAAwAgCCABgBAEEADCCAAIAGEEAAQCMIIAAAEYQQAAAIwggAIARBBAAwAgCCABgBAEEADCCAAIAGEEAAQCMIIAAAEYQQAAAIwggAIARBBAAwAgCCABgBAEEADCCAAIAGEEAAQCMKLAsy3I3Hjx4UNdff72JeoC8csMNN2j//v05325BQUHOtwlki0/MSFLDGL/WBQsW6Gc/+5nOnDmT3aqAPPfAAw8Y2e4TTzyhxsZGI9sGMmnp0qWB83zPgAAAyLIGrgEBAIwggAAARhBAAAAjCCAAgBEEEADAiP8P3k/yy1N5jloAAAAASUVORK5CYII=" alt="IGeneratorResult and IValidationResult" id="fig:IGeneratorResultClasses
 * " data-latex-style="scale=0.7" />
 *
 * <pre>
 * <!--UML: ClassDiag IGeneratorResultClasses{
 *
 * [G:{@link IGeneratorResult}]-^[ {@link IValidationResult}],
 * [B:GeneratorResultBuilder]"<creates>"-.->[G],
 * [note:"Use this to create results"]-[B],
 * }
 * -->
 * </pre>
 *
 * You must not implement the {@link IGeneratorResult} interface to make you own results!
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see GeneratorResultBuilder
 * @noimplement This interface is not intended to be implemented by clients. Please use GeneratorResultBuilder
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGeneratorResult extends IValidationResult, IFormattable {
    /**
     * Gets the exception which has caused this generator result, or null if no exception has caused this result.
     *
     * @return The exception or <code>null</code>.
     */
    @PublishedMethod
    Throwable getException();

    /**
     * Gets the Result Id (Origin,Id, etc.) of this Result. The ResultId is used to group certain messages together.
     *
     * @return The ValidationResultId
     */
    @PublishedMethod
    @Override
    IValidationResultId getId();

    /**
     * Gets the description of the Result.
     *
     * @return The Description
     */
    @PublishedMethod
    @Override
    IMixedText getDescription();

    /**
     * Gets the Severity of the Result.
     *
     * <p>
     * The severity "<b>Improvement</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The settings are correct and valid but may not be optimal with respect to embedded code generation. E.g. modifying this value may reduce memory consumption or CPU
     * load.</li>
     * <li>The detection of Improvement may be executed during generation or in a separate step that has to be triggered by the user (e.g. "Find Improvements").</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Info</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>Some settings have been adapted by a clearly defined rule (e.g. using of a default value). Applying this rule has not modified the behavior of the software.</li>
     * <li>General information for the user e.g. the finalization of the generation process.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Warning</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The configuration may be faulty or in some way incorrect but there are reasons why the user might require such a way of configuration.</li>
     * <li>The output files can be processed without problems (e.g. no compile errors...)</li>
     * <li>It may happen that the output files will lead to a non functioning system in case the warning is ignored by the user.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Error</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>Input data is not consistent e.g. conflicting settings</li>
     * <li>Using the output files lead to problems in the following processing steps or in an invalid runtime behavior of the ECU.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Fatal Error</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The detected internal fatal error is so severe that processing (e.g. generation or validation) cannot be continued.</li>
     * </ul>
     * Hint: Do not report Fatal Errors!
     * </p>
     *
     *
     * @return The Severity of the result
     */
    @PublishedMethod
    @Override
    EValidationSeverityType getSeverity();

    /**
     * Gets the erroneous Configuration entities involved in the result.
     *
     * @return Collection of CEs.
     */
    @PublishedMethod
    @Override
    Collection<IDescriptor> getErroneousCEs();

    /**
     * Gets the solving actions registered to this Result.
     *
     * @return Collection of Solving Actions
     */
    @PublishedMethod
    @Override
    Collection<ISolvingAction> getSolvingActions();

    /**
     * Gets auto solving Action.
     *
     * @return A auto Solving Action
     */
    @PublishedMethod
    @Override
    ISolvingAction getAutoSolvingAction();

}
