#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__g__108 _main_gen_init_g108(void);

extern __PST__g__103 _main_gen_init_g103(void);

extern __PST__g__99 _main_gen_init_g99(void);

extern __PST__g__96 _main_gen_init_g96(void);

extern __PST__g__93 _main_gen_init_g93(void);

extern __PST__g__90 _main_gen_init_g90(void);

extern __PST__g__87 _main_gen_init_g87(void);

extern __PST__g__84 _main_gen_init_g84(void);

extern __PST__g__81 _main_gen_init_g81(void);

extern __PST__g__78 _main_gen_init_g78(void);

extern __PST__g__75 _main_gen_init_g75(void);

extern __PST__g__72 _main_gen_init_g72(void);

extern __PST__g__69 _main_gen_init_g69(void);

extern __PST__g__66 _main_gen_init_g66(void);

extern __PST__g__63 _main_gen_init_g63(void);

extern __PST__g__60 _main_gen_init_g60(void);

extern __PST__g__57 _main_gen_init_g57(void);

extern __PST__g__51 _main_gen_init_g51(void);

extern __PST__g__47 _main_gen_init_g47(void);

extern __PST__g__43 _main_gen_init_g43(void);

extern __PST__g__40 _main_gen_init_g40(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__22 _main_gen_init_g22(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__22 _main_gen_init_g22(void)
{
    __PST__g__22 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__40 _main_gen_init_g40(void)
{
    __PST__g__40 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__43 _main_gen_init_g43(void)
{
    __PST__g__43 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__47 _main_gen_init_g47(void)
{
    __PST__g__47 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__51 _main_gen_init_g51(void)
{
    __PST__g__51 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__57 _main_gen_init_g57(void)
{
    __PST__g__57 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__60 _main_gen_init_g60(void)
{
    __PST__g__60 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__63 _main_gen_init_g63(void)
{
    __PST__g__63 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__66 _main_gen_init_g66(void)
{
    __PST__g__66 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__69 _main_gen_init_g69(void)
{
    __PST__g__69 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__72 _main_gen_init_g72(void)
{
    __PST__g__72 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__75 _main_gen_init_g75(void)
{
    __PST__g__75 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__78 _main_gen_init_g78(void)
{
    __PST__g__78 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__81 _main_gen_init_g81(void)
{
    __PST__g__81 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__84 _main_gen_init_g84(void)
{
    __PST__g__84 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__87 _main_gen_init_g87(void)
{
    __PST__g__87 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__90 _main_gen_init_g90(void)
{
    __PST__g__90 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__93 _main_gen_init_g93(void)
{
    __PST__g__93 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__96 _main_gen_init_g96(void)
{
    __PST__g__96 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__99 _main_gen_init_g99(void)
{
    __PST__g__99 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__103 _main_gen_init_g103(void)
{
    __PST__g__103 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__108 _main_gen_init_g108(void)
{
    __PST__g__108 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_GtmCfgAndUse_Ip_IvtrFetFltPha(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Ip_IvtrFetFltPha;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Ip_IvtrFetFltPha = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Ip_MotCurrEolCalSt(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Ip_MotCurrEolCalSt;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Ip_MotCurrEolCalSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Ip_SysSt(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Ip_SysSt;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvn2Offs(void)
{
    extern __PST__g__22 GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvn2Offs;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvn2Offs = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvnPeakOffs(void)
{
    extern __PST__g__22 GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvnPeakOffs;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvnPeakOffs = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseDma2MilliSecToMotCtrlTrig(void)
{
    extern __PST__g__22 GtmCfgAndUse_Cal_GtmCfgAndUseDma2MilliSecToMotCtrlTrig;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Cal_GtmCfgAndUseDma2MilliSecToMotCtrlTrig = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotAgATrig(void)
{
    extern __PST__g__22 GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotAgATrig;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotAgATrig = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotCtrlTo2MilliSecTrig(void)
{
    extern __PST__g__22 GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotCtrlTo2MilliSecTrig;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotCtrlTo2MilliSecTrig = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUsePwmDbnd(void)
{
    extern __PST__g__22 GtmCfgAndUse_Cal_GtmCfgAndUsePwmDbnd;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Cal_GtmCfgAndUsePwmDbnd = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_AdcStrtOfCnvn2(void)
{
    extern __PST__UINT32 GtmCfgAndUse_Pim_AdcStrtOfCnvn2;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_AdcStrtOfCnvn2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_AdcStrtOfCnvnPeak(void)
{
    extern __PST__UINT32 GtmCfgAndUse_Pim_AdcStrtOfCnvnPeak;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_AdcStrtOfCnvnPeak = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_Dma2MilliSecToMotCtrlTrig(void)
{
    extern __PST__UINT32 GtmCfgAndUse_Pim_Dma2MilliSecToMotCtrlTrig;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_Dma2MilliSecToMotCtrlTrig = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_DmaMotAgATrig(void)
{
    extern __PST__UINT32 GtmCfgAndUse_Pim_DmaMotAgATrig;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_DmaMotAgATrig = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_DmaMotCtrlTo2MilliSecTrig(void)
{
    extern __PST__UINT32 GtmCfgAndUse_Pim_DmaMotCtrlTo2MilliSecTrig;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_DmaMotCtrlTo2MilliSecTrig = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_PhaAFetFldSts(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Pim_PhaAFetFldSts;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_PhaAFetFldSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_PhaBFetFldSts(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Pim_PhaBFetFldSts;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_PhaBFetFldSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_PhaCFetFldSts(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Pim_PhaCFetFldSts;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_PhaCFetFldSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_PhaOnTiCntrAPrev(void)
{
    extern __PST__UINT32 GtmCfgAndUse_Pim_PhaOnTiCntrAPrev;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_PhaOnTiCntrAPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_PhaOnTiCntrBPrev(void)
{
    extern __PST__UINT32 GtmCfgAndUse_Pim_PhaOnTiCntrBPrev;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_PhaOnTiCntrBPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_PhaOnTiCntrCPrev(void)
{
    extern __PST__UINT32 GtmCfgAndUse_Pim_PhaOnTiCntrCPrev;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_PhaOnTiCntrCPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_SysStEnaPrev(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Pim_SysStEnaPrev;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_SysStEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GTM0GTMRST_BASE(void)
{
    extern __PST__g__28 GTM0GTMRST_BASE;
    
    /* initialization with random value */
    {
        GTM0GTMRST_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_GTM0GTMCTRL_BASE(void)
{
    extern __PST__g__32 GTM0GTMCTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0GTMCTRL_BASE = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_GTM0TBUCHEN_BASE(void)
{
    extern __PST__g__36 GTM0TBUCHEN_BASE;
    
    /* initialization with random value */
    {
        GTM0TBUCHEN_BASE = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_GTM0CMUCLKEN_BASE(void)
{
    extern __PST__g__40 GTM0CMUCLKEN_BASE;
    
    /* initialization with random value */
    {
        GTM0CMUCLKEN_BASE = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_GTM0CMUCLK0CTRL_BASE(void)
{
    extern __PST__g__43 GTM0CMUCLK0CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0CMUCLK0CTRL_BASE = _main_gen_init_g43();
    }
}

static void _main_gen_init_sym_GTM0CMUCLK1CTRL_BASE(void)
{
    extern __PST__g__43 GTM0CMUCLK1CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0CMUCLK1CTRL_BASE = _main_gen_init_g43();
    }
}

static void _main_gen_init_sym_GTM0CMUCLK2CTRL_BASE(void)
{
    extern __PST__g__43 GTM0CMUCLK2CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0CMUCLK2CTRL_BASE = _main_gen_init_g43();
    }
}

static void _main_gen_init_sym_GTM0CMUCLK3CTRL_BASE(void)
{
    extern __PST__g__43 GTM0CMUCLK3CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0CMUCLK3CTRL_BASE = _main_gen_init_g43();
    }
}

static void _main_gen_init_sym_GTM0TIM01CTRL_BASE(void)
{
    extern __PST__g__47 GTM0TIM01CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM01CTRL_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_GTM0TIM04CTRL_BASE(void)
{
    extern __PST__g__47 GTM0TIM04CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM04CTRL_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_GTM0TIM10CNT_BASE(void)
{
    extern __PST__g__51 GTM0TIM10CNT_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM10CNT_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_GTM0TIM10CTRL_BASE(void)
{
    extern __PST__g__57 GTM0TIM10CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM10CTRL_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_GTM0TIM11CNT_BASE(void)
{
    extern __PST__g__51 GTM0TIM11CNT_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM11CNT_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_GTM0TIM11CTRL_BASE(void)
{
    extern __PST__g__57 GTM0TIM11CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM11CTRL_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_GTM0TIM12CNT_BASE(void)
{
    extern __PST__g__51 GTM0TIM12CNT_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM12CNT_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_GTM0TIM12CTRL_BASE(void)
{
    extern __PST__g__57 GTM0TIM12CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM12CTRL_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_GTM0TIM13CTRL_BASE(void)
{
    extern __PST__g__57 GTM0TIM13CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM13CTRL_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_GTM0TIM14CTRL_BASE(void)
{
    extern __PST__g__57 GTM0TIM14CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM14CTRL_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_GTM0TIM15CTRL_BASE(void)
{
    extern __PST__g__57 GTM0TIM15CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM15CTRL_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_GTM0TIM16CTRL_BASE(void)
{
    extern __PST__g__57 GTM0TIM16CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0TIM16CTRL_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_GTM0ATOM00CTRL_BASE(void)
{
    extern __PST__g__60 GTM0ATOM00CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM00CTRL_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_GTM0ATOM00SR0_BASE(void)
{
    extern __PST__g__63 GTM0ATOM00SR0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM00SR0_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_GTM0ATOM00SR1_BASE(void)
{
    extern __PST__g__66 GTM0ATOM00SR1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM00SR1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_GTM0ATOM00CM0_BASE(void)
{
    extern __PST__g__69 GTM0ATOM00CM0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM00CM0_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_GTM0ATOM00CM1_BASE(void)
{
    extern __PST__g__72 GTM0ATOM00CM1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM00CM1_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_GTM0ATOM00CN0_BASE(void)
{
    extern __PST__g__75 GTM0ATOM00CN0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM00CN0_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_GTM0ATOM0AGCGLBCTRL_BASE(void)
{
    extern __PST__g__78 GTM0ATOM0AGCGLBCTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM0AGCGLBCTRL_BASE = _main_gen_init_g78();
    }
}

static void _main_gen_init_sym_GTM0ATOM0AGCENDISSTAT_BASE(void)
{
    extern __PST__g__81 GTM0ATOM0AGCENDISSTAT_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM0AGCENDISSTAT_BASE = _main_gen_init_g81();
    }
}

static void _main_gen_init_sym_GTM0ATOM0AGCOUTENSTAT_BASE(void)
{
    extern __PST__g__84 GTM0ATOM0AGCOUTENSTAT_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM0AGCOUTENSTAT_BASE = _main_gen_init_g84();
    }
}

static void _main_gen_init_sym_GTM0ATOM01CTRL_BASE(void)
{
    extern __PST__g__60 GTM0ATOM01CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM01CTRL_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_GTM0ATOM01SR0_BASE(void)
{
    extern __PST__g__63 GTM0ATOM01SR0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM01SR0_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_GTM0ATOM01SR1_BASE(void)
{
    extern __PST__g__66 GTM0ATOM01SR1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM01SR1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_GTM0ATOM01CM0_BASE(void)
{
    extern __PST__g__69 GTM0ATOM01CM0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM01CM0_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_GTM0ATOM01CM1_BASE(void)
{
    extern __PST__g__72 GTM0ATOM01CM1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM01CM1_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_GTM0ATOM01CN0_BASE(void)
{
    extern __PST__g__75 GTM0ATOM01CN0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM01CN0_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_GTM0ATOM02CTRL_BASE(void)
{
    extern __PST__g__60 GTM0ATOM02CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM02CTRL_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_GTM0ATOM02SR0_BASE(void)
{
    extern __PST__g__63 GTM0ATOM02SR0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM02SR0_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_GTM0ATOM02SR1_BASE(void)
{
    extern __PST__g__66 GTM0ATOM02SR1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM02SR1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_GTM0ATOM02CM0_BASE(void)
{
    extern __PST__g__69 GTM0ATOM02CM0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM02CM0_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_GTM0ATOM02CM1_BASE(void)
{
    extern __PST__g__72 GTM0ATOM02CM1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM02CM1_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_GTM0ATOM02CN0_BASE(void)
{
    extern __PST__g__75 GTM0ATOM02CN0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM02CN0_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_GTM0ATOM03CTRL_BASE(void)
{
    extern __PST__g__60 GTM0ATOM03CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM03CTRL_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_GTM0ATOM03SR1_BASE(void)
{
    extern __PST__g__66 GTM0ATOM03SR1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM03SR1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_GTM0ATOM03CM0_BASE(void)
{
    extern __PST__g__69 GTM0ATOM03CM0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM03CM0_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_GTM0ATOM03CM1_BASE(void)
{
    extern __PST__g__72 GTM0ATOM03CM1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM03CM1_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_GTM0ATOM03CN0_BASE(void)
{
    extern __PST__g__75 GTM0ATOM03CN0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM03CN0_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_GTM0ATOM04CTRL_BASE(void)
{
    extern __PST__g__60 GTM0ATOM04CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM04CTRL_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_GTM0ATOM04SR0_BASE(void)
{
    extern __PST__g__63 GTM0ATOM04SR0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM04SR0_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_GTM0ATOM04SR1_BASE(void)
{
    extern __PST__g__66 GTM0ATOM04SR1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM04SR1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_GTM0ATOM04CM0_BASE(void)
{
    extern __PST__g__69 GTM0ATOM04CM0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM04CM0_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_GTM0ATOM04CM1_BASE(void)
{
    extern __PST__g__72 GTM0ATOM04CM1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM04CM1_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_GTM0ATOM04CN0_BASE(void)
{
    extern __PST__g__75 GTM0ATOM04CN0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM04CN0_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_GTM0ATOM05CTRL_BASE(void)
{
    extern __PST__g__60 GTM0ATOM05CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM05CTRL_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_GTM0ATOM05SR0_BASE(void)
{
    extern __PST__g__63 GTM0ATOM05SR0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM05SR0_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_GTM0ATOM05SR1_BASE(void)
{
    extern __PST__g__66 GTM0ATOM05SR1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM05SR1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_GTM0ATOM05CM0_BASE(void)
{
    extern __PST__g__69 GTM0ATOM05CM0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM05CM0_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_GTM0ATOM05CM1_BASE(void)
{
    extern __PST__g__72 GTM0ATOM05CM1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM05CM1_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_GTM0ATOM05CN0_BASE(void)
{
    extern __PST__g__75 GTM0ATOM05CN0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM05CN0_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_GTM0ATOM06CTRL_BASE(void)
{
    extern __PST__g__60 GTM0ATOM06CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM06CTRL_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_GTM0ATOM06SR0_BASE(void)
{
    extern __PST__g__63 GTM0ATOM06SR0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM06SR0_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_GTM0ATOM06SR1_BASE(void)
{
    extern __PST__g__66 GTM0ATOM06SR1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM06SR1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_GTM0ATOM06CM0_BASE(void)
{
    extern __PST__g__69 GTM0ATOM06CM0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM06CM0_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_GTM0ATOM06CM1_BASE(void)
{
    extern __PST__g__72 GTM0ATOM06CM1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM06CM1_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_GTM0ATOM06CN0_BASE(void)
{
    extern __PST__g__75 GTM0ATOM06CN0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM06CN0_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_GTM0ATOM07CTRL_BASE(void)
{
    extern __PST__g__60 GTM0ATOM07CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM07CTRL_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_GTM0ATOM07SR0_BASE(void)
{
    extern __PST__g__63 GTM0ATOM07SR0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM07SR0_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_GTM0ATOM07SR1_BASE(void)
{
    extern __PST__g__66 GTM0ATOM07SR1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM07SR1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_GTM0ATOM07CM0_BASE(void)
{
    extern __PST__g__69 GTM0ATOM07CM0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM07CM0_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_GTM0ATOM07CM1_BASE(void)
{
    extern __PST__g__72 GTM0ATOM07CM1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM07CM1_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_GTM0ATOM07CN0_BASE(void)
{
    extern __PST__g__75 GTM0ATOM07CN0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM07CN0_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_GTM0ATOM07IRQEN_BASE(void)
{
    extern __PST__g__87 GTM0ATOM07IRQEN_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM07IRQEN_BASE = _main_gen_init_g87();
    }
}

static void _main_gen_init_sym_GTM0ATOM10CTRL_BASE(void)
{
    extern __PST__g__60 GTM0ATOM10CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM10CTRL_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_GTM0ATOM10SR0_BASE(void)
{
    extern __PST__g__63 GTM0ATOM10SR0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM10SR0_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_GTM0ATOM10SR1_BASE(void)
{
    extern __PST__g__66 GTM0ATOM10SR1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM10SR1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_GTM0ATOM10CM0_BASE(void)
{
    extern __PST__g__69 GTM0ATOM10CM0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM10CM0_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_GTM0ATOM10CM1_BASE(void)
{
    extern __PST__g__72 GTM0ATOM10CM1_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM10CM1_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_GTM0ATOM10CN0_BASE(void)
{
    extern __PST__g__75 GTM0ATOM10CN0_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM10CN0_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_GTM0ATOM1AGCGLBCTRL_BASE(void)
{
    extern __PST__g__78 GTM0ATOM1AGCGLBCTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM1AGCGLBCTRL_BASE = _main_gen_init_g78();
    }
}

static void _main_gen_init_sym_GTM0ATOM1AGCENDISSTAT_BASE(void)
{
    extern __PST__g__81 GTM0ATOM1AGCENDISSTAT_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM1AGCENDISSTAT_BASE = _main_gen_init_g81();
    }
}

static void _main_gen_init_sym_GTM0ATOM1AGCOUTENSTAT_BASE(void)
{
    extern __PST__g__84 GTM0ATOM1AGCOUTENSTAT_BASE;
    
    /* initialization with random value */
    {
        GTM0ATOM1AGCOUTENSTAT_BASE = _main_gen_init_g84();
    }
}

static void _main_gen_init_sym_GTM0DTM24CTRL_BASE(void)
{
    extern __PST__g__90 GTM0DTM24CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0DTM24CTRL_BASE = _main_gen_init_g90();
    }
}

static void _main_gen_init_sym_GTM0DTM24CHCTRL2_BASE(void)
{
    extern __PST__g__93 GTM0DTM24CHCTRL2_BASE;
    
    /* initialization with random value */
    {
        GTM0DTM24CHCTRL2_BASE = _main_gen_init_g93();
    }
}

static void _main_gen_init_sym_GTM0DTM24CHCTRL2SR_BASE(void)
{
    extern __PST__g__96 GTM0DTM24CHCTRL2SR_BASE;
    
    /* initialization with random value */
    {
        GTM0DTM24CHCTRL2SR_BASE = _main_gen_init_g96();
    }
}

static void _main_gen_init_sym_GTM0DTM240DTV_BASE(void)
{
    extern __PST__g__99 GTM0DTM240DTV_BASE;
    
    /* initialization with random value */
    {
        GTM0DTM240DTV_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_GTM0DTM242DTV_BASE(void)
{
    extern __PST__g__99 GTM0DTM242DTV_BASE;
    
    /* initialization with random value */
    {
        GTM0DTM242DTV_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_GTM0DTM243DTV_BASE(void)
{
    extern __PST__g__99 GTM0DTM243DTV_BASE;
    
    /* initialization with random value */
    {
        GTM0DTM243DTV_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_GTM0MCS00CTRL_BASE(void)
{
    extern __PST__g__103 GTM0MCS00CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0MCS00CTRL_BASE = _main_gen_init_g103();
    }
}

static void _main_gen_init_sym_GTM0MCS0CTRLSTAT_BASE(void)
{
    extern __PST__g__108 GTM0MCS0CTRLSTAT_BASE;
    
    /* initialization with random value */
    {
        GTM0MCS0CTRLSTAT_BASE = _main_gen_init_g108();
    }
}

static void _main_gen_init_sym_GTM0MCS01CTRL_BASE(void)
{
    extern __PST__g__103 GTM0MCS01CTRL_BASE;
    
    /* initialization with random value */
    {
        GTM0MCS01CTRL_BASE = _main_gen_init_g103();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cal_CurrMeasEolFixdPwmPerd(void)
{
    extern __PST__g__22 GtmCfgAndUse_Cal_CurrMeasEolFixdPwmPerd;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Cal_CurrMeasEolFixdPwmPerd = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs(void)
{
    extern __PST__g__22 GtmCfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs(void)
{
    extern __PST__g__22 GtmCfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_MissUpdCntr(void)
{
    extern __PST__UINT16 GtmCfgAndUse_Pim_MissUpdCntr;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_MissUpdCntr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Pim_MissUpdIninCntr(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Pim_MissUpdIninCntr;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Pim_MissUpdIninCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrEolCalSt(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrEolCalSt;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrEolCalSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPwmPerd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPwmPerd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiA = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiB = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiC = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return(void)
{
    extern __PST__UINT8 GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return;
    
    /* initialization with random value */
    {
        GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cli_GtmGetSent0Data_BufStrt(void)
{
    extern __PST__g__114 GtmCfgAndUse_Cli_GtmGetSent0Data_BufStrt;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 32; _main_gen_tmp_0_0++)
            {
                /* base type */
                GtmCfgAndUse_Cli_GtmGetSent0Data_BufStrt[_main_gen_tmp_0_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_GtmCfgAndUse_Cli_GtmGetSent1Data_BufStrt(void)
{
    extern __PST__g__114 GtmCfgAndUse_Cli_GtmGetSent1Data_BufStrt;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 32; _main_gen_tmp_1_0++)
            {
                /* base type */
                GtmCfgAndUse_Cli_GtmGetSent1Data_BufStrt[_main_gen_tmp_1_0] = pst_random_g_8;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable GtmCfgAndUse_Ip_IvtrFetFltPha */
    _main_gen_init_sym_GtmCfgAndUse_Ip_IvtrFetFltPha();
    
    /* init for variable GtmCfgAndUse_Ip_MotCurrEolCalSt */
    _main_gen_init_sym_GtmCfgAndUse_Ip_MotCurrEolCalSt();
    
    /* init for variable GtmCfgAndUse_Ip_SysSt */
    _main_gen_init_sym_GtmCfgAndUse_Ip_SysSt();
    
    /* init for variable GtmCfgAndUse_Op_PhaOnTiMeasdA : useless (never read) */

    /* init for variable GtmCfgAndUse_Op_PhaOnTiMeasdB : useless (never read) */

    /* init for variable GtmCfgAndUse_Op_PhaOnTiMeasdC : useless (never read) */

    /* init for variable GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvn2Offs */
    _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvn2Offs();
    
    /* init for variable GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvnPeakOffs */
    _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseAdcStrtOfCnvnPeakOffs();
    
    /* init for variable GtmCfgAndUse_Cal_GtmCfgAndUseDma2MilliSecToMotCtrlTrig */
    _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseDma2MilliSecToMotCtrlTrig();
    
    /* init for variable GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotAgATrig */
    _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotAgATrig();
    
    /* init for variable GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotCtrlTo2MilliSecTrig */
    _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUseDmaMotCtrlTo2MilliSecTrig();
    
    /* init for variable GtmCfgAndUse_Cal_GtmCfgAndUsePwmDbnd */
    _main_gen_init_sym_GtmCfgAndUse_Cal_GtmCfgAndUsePwmDbnd();
    
    /* init for variable GtmCfgAndUse_Pim_AdcStrtOfCnvn2 */
    _main_gen_init_sym_GtmCfgAndUse_Pim_AdcStrtOfCnvn2();
    
    /* init for variable GtmCfgAndUse_Pim_AdcStrtOfCnvnPeak */
    _main_gen_init_sym_GtmCfgAndUse_Pim_AdcStrtOfCnvnPeak();
    
    /* init for variable GtmCfgAndUse_Pim_Dma2MilliSecToMotCtrlTrig */
    _main_gen_init_sym_GtmCfgAndUse_Pim_Dma2MilliSecToMotCtrlTrig();
    
    /* init for variable GtmCfgAndUse_Pim_DmaMotAgATrig */
    _main_gen_init_sym_GtmCfgAndUse_Pim_DmaMotAgATrig();
    
    /* init for variable GtmCfgAndUse_Pim_DmaMotCtrlTo2MilliSecTrig */
    _main_gen_init_sym_GtmCfgAndUse_Pim_DmaMotCtrlTo2MilliSecTrig();
    
    /* init for variable GtmCfgAndUse_Pim_PhaAFetFldSts */
    _main_gen_init_sym_GtmCfgAndUse_Pim_PhaAFetFldSts();
    
    /* init for variable GtmCfgAndUse_Pim_PhaBFetFldSts */
    _main_gen_init_sym_GtmCfgAndUse_Pim_PhaBFetFldSts();
    
    /* init for variable GtmCfgAndUse_Pim_PhaCFetFldSts */
    _main_gen_init_sym_GtmCfgAndUse_Pim_PhaCFetFldSts();
    
    /* init for variable GtmCfgAndUse_Pim_PhaOnTiCntrAPrev */
    _main_gen_init_sym_GtmCfgAndUse_Pim_PhaOnTiCntrAPrev();
    
    /* init for variable GtmCfgAndUse_Pim_PhaOnTiCntrBPrev */
    _main_gen_init_sym_GtmCfgAndUse_Pim_PhaOnTiCntrBPrev();
    
    /* init for variable GtmCfgAndUse_Pim_PhaOnTiCntrCPrev */
    _main_gen_init_sym_GtmCfgAndUse_Pim_PhaOnTiCntrCPrev();
    
    /* init for variable GtmCfgAndUse_Pim_SysStEnaPrev */
    _main_gen_init_sym_GtmCfgAndUse_Pim_SysStEnaPrev();
    
    /* init for variable GTM0GTMRST_BASE */
    _main_gen_init_sym_GTM0GTMRST_BASE();
    
    /* init for variable GTM0GTMCTRL_BASE */
    _main_gen_init_sym_GTM0GTMCTRL_BASE();
    
    /* init for variable GTM0TBUCHEN_BASE */
    _main_gen_init_sym_GTM0TBUCHEN_BASE();
    
    /* init for variable GTM0CMUCLKEN_BASE */
    _main_gen_init_sym_GTM0CMUCLKEN_BASE();
    
    /* init for variable GTM0CMUCLK0CTRL_BASE */
    _main_gen_init_sym_GTM0CMUCLK0CTRL_BASE();
    
    /* init for variable GTM0CMUCLK1CTRL_BASE */
    _main_gen_init_sym_GTM0CMUCLK1CTRL_BASE();
    
    /* init for variable GTM0CMUCLK2CTRL_BASE */
    _main_gen_init_sym_GTM0CMUCLK2CTRL_BASE();
    
    /* init for variable GTM0CMUCLK3CTRL_BASE */
    _main_gen_init_sym_GTM0CMUCLK3CTRL_BASE();
    
    /* init for variable GTM0TIM01CTRL_BASE */
    _main_gen_init_sym_GTM0TIM01CTRL_BASE();
    
    /* init for variable GTM0TIM04CTRL_BASE */
    _main_gen_init_sym_GTM0TIM04CTRL_BASE();
    
    /* init for variable GTM0TIM10CNT_BASE */
    _main_gen_init_sym_GTM0TIM10CNT_BASE();
    
    /* init for variable GTM0TIM10CTRL_BASE */
    _main_gen_init_sym_GTM0TIM10CTRL_BASE();
    
    /* init for variable GTM0TIM11CNT_BASE */
    _main_gen_init_sym_GTM0TIM11CNT_BASE();
    
    /* init for variable GTM0TIM11CTRL_BASE */
    _main_gen_init_sym_GTM0TIM11CTRL_BASE();
    
    /* init for variable GTM0TIM12CNT_BASE */
    _main_gen_init_sym_GTM0TIM12CNT_BASE();
    
    /* init for variable GTM0TIM12CTRL_BASE */
    _main_gen_init_sym_GTM0TIM12CTRL_BASE();
    
    /* init for variable GTM0TIM13CTRL_BASE */
    _main_gen_init_sym_GTM0TIM13CTRL_BASE();
    
    /* init for variable GTM0TIM14CTRL_BASE */
    _main_gen_init_sym_GTM0TIM14CTRL_BASE();
    
    /* init for variable GTM0TIM15CTRL_BASE */
    _main_gen_init_sym_GTM0TIM15CTRL_BASE();
    
    /* init for variable GTM0TIM16CTRL_BASE */
    _main_gen_init_sym_GTM0TIM16CTRL_BASE();
    
    /* init for variable GTM0ATOM00CTRL_BASE */
    _main_gen_init_sym_GTM0ATOM00CTRL_BASE();
    
    /* init for variable GTM0ATOM00SR0_BASE */
    _main_gen_init_sym_GTM0ATOM00SR0_BASE();
    
    /* init for variable GTM0ATOM00SR1_BASE */
    _main_gen_init_sym_GTM0ATOM00SR1_BASE();
    
    /* init for variable GTM0ATOM00CM0_BASE */
    _main_gen_init_sym_GTM0ATOM00CM0_BASE();
    
    /* init for variable GTM0ATOM00CM1_BASE */
    _main_gen_init_sym_GTM0ATOM00CM1_BASE();
    
    /* init for variable GTM0ATOM00CN0_BASE */
    _main_gen_init_sym_GTM0ATOM00CN0_BASE();
    
    /* init for variable GTM0ATOM0AGCGLBCTRL_BASE */
    _main_gen_init_sym_GTM0ATOM0AGCGLBCTRL_BASE();
    
    /* init for variable GTM0ATOM0AGCENDISSTAT_BASE */
    _main_gen_init_sym_GTM0ATOM0AGCENDISSTAT_BASE();
    
    /* init for variable GTM0ATOM0AGCOUTENSTAT_BASE */
    _main_gen_init_sym_GTM0ATOM0AGCOUTENSTAT_BASE();
    
    /* init for variable GTM0ATOM01CTRL_BASE */
    _main_gen_init_sym_GTM0ATOM01CTRL_BASE();
    
    /* init for variable GTM0ATOM01SR0_BASE */
    _main_gen_init_sym_GTM0ATOM01SR0_BASE();
    
    /* init for variable GTM0ATOM01SR1_BASE */
    _main_gen_init_sym_GTM0ATOM01SR1_BASE();
    
    /* init for variable GTM0ATOM01CM0_BASE */
    _main_gen_init_sym_GTM0ATOM01CM0_BASE();
    
    /* init for variable GTM0ATOM01CM1_BASE */
    _main_gen_init_sym_GTM0ATOM01CM1_BASE();
    
    /* init for variable GTM0ATOM01CN0_BASE */
    _main_gen_init_sym_GTM0ATOM01CN0_BASE();
    
    /* init for variable GTM0ATOM02CTRL_BASE */
    _main_gen_init_sym_GTM0ATOM02CTRL_BASE();
    
    /* init for variable GTM0ATOM02SR0_BASE */
    _main_gen_init_sym_GTM0ATOM02SR0_BASE();
    
    /* init for variable GTM0ATOM02SR1_BASE */
    _main_gen_init_sym_GTM0ATOM02SR1_BASE();
    
    /* init for variable GTM0ATOM02CM0_BASE */
    _main_gen_init_sym_GTM0ATOM02CM0_BASE();
    
    /* init for variable GTM0ATOM02CM1_BASE */
    _main_gen_init_sym_GTM0ATOM02CM1_BASE();
    
    /* init for variable GTM0ATOM02CN0_BASE */
    _main_gen_init_sym_GTM0ATOM02CN0_BASE();
    
    /* init for variable GTM0ATOM03CTRL_BASE */
    _main_gen_init_sym_GTM0ATOM03CTRL_BASE();
    
    /* init for variable GTM0ATOM03SR1_BASE */
    _main_gen_init_sym_GTM0ATOM03SR1_BASE();
    
    /* init for variable GTM0ATOM03CM0_BASE */
    _main_gen_init_sym_GTM0ATOM03CM0_BASE();
    
    /* init for variable GTM0ATOM03CM1_BASE */
    _main_gen_init_sym_GTM0ATOM03CM1_BASE();
    
    /* init for variable GTM0ATOM03CN0_BASE */
    _main_gen_init_sym_GTM0ATOM03CN0_BASE();
    
    /* init for variable GTM0ATOM04CTRL_BASE */
    _main_gen_init_sym_GTM0ATOM04CTRL_BASE();
    
    /* init for variable GTM0ATOM04SR0_BASE */
    _main_gen_init_sym_GTM0ATOM04SR0_BASE();
    
    /* init for variable GTM0ATOM04SR1_BASE */
    _main_gen_init_sym_GTM0ATOM04SR1_BASE();
    
    /* init for variable GTM0ATOM04CM0_BASE */
    _main_gen_init_sym_GTM0ATOM04CM0_BASE();
    
    /* init for variable GTM0ATOM04CM1_BASE */
    _main_gen_init_sym_GTM0ATOM04CM1_BASE();
    
    /* init for variable GTM0ATOM04CN0_BASE */
    _main_gen_init_sym_GTM0ATOM04CN0_BASE();
    
    /* init for variable GTM0ATOM05CTRL_BASE */
    _main_gen_init_sym_GTM0ATOM05CTRL_BASE();
    
    /* init for variable GTM0ATOM05SR0_BASE */
    _main_gen_init_sym_GTM0ATOM05SR0_BASE();
    
    /* init for variable GTM0ATOM05SR1_BASE */
    _main_gen_init_sym_GTM0ATOM05SR1_BASE();
    
    /* init for variable GTM0ATOM05CM0_BASE */
    _main_gen_init_sym_GTM0ATOM05CM0_BASE();
    
    /* init for variable GTM0ATOM05CM1_BASE */
    _main_gen_init_sym_GTM0ATOM05CM1_BASE();
    
    /* init for variable GTM0ATOM05CN0_BASE */
    _main_gen_init_sym_GTM0ATOM05CN0_BASE();
    
    /* init for variable GTM0ATOM06CTRL_BASE */
    _main_gen_init_sym_GTM0ATOM06CTRL_BASE();
    
    /* init for variable GTM0ATOM06SR0_BASE */
    _main_gen_init_sym_GTM0ATOM06SR0_BASE();
    
    /* init for variable GTM0ATOM06SR1_BASE */
    _main_gen_init_sym_GTM0ATOM06SR1_BASE();
    
    /* init for variable GTM0ATOM06CM0_BASE */
    _main_gen_init_sym_GTM0ATOM06CM0_BASE();
    
    /* init for variable GTM0ATOM06CM1_BASE */
    _main_gen_init_sym_GTM0ATOM06CM1_BASE();
    
    /* init for variable GTM0ATOM06CN0_BASE */
    _main_gen_init_sym_GTM0ATOM06CN0_BASE();
    
    /* init for variable GTM0ATOM07CTRL_BASE */
    _main_gen_init_sym_GTM0ATOM07CTRL_BASE();
    
    /* init for variable GTM0ATOM07SR0_BASE */
    _main_gen_init_sym_GTM0ATOM07SR0_BASE();
    
    /* init for variable GTM0ATOM07SR1_BASE */
    _main_gen_init_sym_GTM0ATOM07SR1_BASE();
    
    /* init for variable GTM0ATOM07CM0_BASE */
    _main_gen_init_sym_GTM0ATOM07CM0_BASE();
    
    /* init for variable GTM0ATOM07CM1_BASE */
    _main_gen_init_sym_GTM0ATOM07CM1_BASE();
    
    /* init for variable GTM0ATOM07CN0_BASE */
    _main_gen_init_sym_GTM0ATOM07CN0_BASE();
    
    /* init for variable GTM0ATOM07IRQEN_BASE */
    _main_gen_init_sym_GTM0ATOM07IRQEN_BASE();
    
    /* init for variable GTM0ATOM10CTRL_BASE */
    _main_gen_init_sym_GTM0ATOM10CTRL_BASE();
    
    /* init for variable GTM0ATOM10SR0_BASE */
    _main_gen_init_sym_GTM0ATOM10SR0_BASE();
    
    /* init for variable GTM0ATOM10SR1_BASE */
    _main_gen_init_sym_GTM0ATOM10SR1_BASE();
    
    /* init for variable GTM0ATOM10CM0_BASE */
    _main_gen_init_sym_GTM0ATOM10CM0_BASE();
    
    /* init for variable GTM0ATOM10CM1_BASE */
    _main_gen_init_sym_GTM0ATOM10CM1_BASE();
    
    /* init for variable GTM0ATOM10CN0_BASE */
    _main_gen_init_sym_GTM0ATOM10CN0_BASE();
    
    /* init for variable GTM0ATOM1AGCGLBCTRL_BASE */
    _main_gen_init_sym_GTM0ATOM1AGCGLBCTRL_BASE();
    
    /* init for variable GTM0ATOM1AGCENDISSTAT_BASE */
    _main_gen_init_sym_GTM0ATOM1AGCENDISSTAT_BASE();
    
    /* init for variable GTM0ATOM1AGCOUTENSTAT_BASE */
    _main_gen_init_sym_GTM0ATOM1AGCOUTENSTAT_BASE();
    
    /* init for variable GTM0DTM24CTRL_BASE */
    _main_gen_init_sym_GTM0DTM24CTRL_BASE();
    
    /* init for variable GTM0DTM24CHCTRL2_BASE */
    _main_gen_init_sym_GTM0DTM24CHCTRL2_BASE();
    
    /* init for variable GTM0DTM24CHCTRL2SR_BASE */
    _main_gen_init_sym_GTM0DTM24CHCTRL2SR_BASE();
    
    /* init for variable GTM0DTM240DTV_BASE */
    _main_gen_init_sym_GTM0DTM240DTV_BASE();
    
    /* init for variable GTM0DTM242DTV_BASE */
    _main_gen_init_sym_GTM0DTM242DTV_BASE();
    
    /* init for variable GTM0DTM243DTV_BASE */
    _main_gen_init_sym_GTM0DTM243DTV_BASE();
    
    /* init for variable GTM0MCS00CTRL_BASE */
    _main_gen_init_sym_GTM0MCS00CTRL_BASE();
    
    /* init for variable GTM0MCS0CTRLSTAT_BASE */
    _main_gen_init_sym_GTM0MCS0CTRLSTAT_BASE();
    
    /* init for variable GTM0MCS01CTRL_BASE */
    _main_gen_init_sym_GTM0MCS01CTRL_BASE();
    
    /* init for variable GtmCfgAndUse_Cal_CurrMeasEolFixdPwmPerd */
    _main_gen_init_sym_GtmCfgAndUse_Cal_CurrMeasEolFixdPwmPerd();
    
    /* init for variable GtmCfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs */
    _main_gen_init_sym_GtmCfgAndUse_Cal_CurrMeasEolOffsHiCmuOffs();
    
    /* init for variable GtmCfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs */
    _main_gen_init_sym_GtmCfgAndUse_Cal_CurrMeasEolOffsLoCmuOffs();
    
    /* init for variable GtmCfgAndUse_Pim_MissUpdCntr */
    _main_gen_init_sym_GtmCfgAndUse_Pim_MissUpdCntr();
    
    /* init for variable GtmCfgAndUse_Pim_MissUpdIninCntr */
    _main_gen_init_sym_GtmCfgAndUse_Pim_MissUpdIninCntr();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrEolCalSt */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrEolCalSt();
    
    /* init for variable MOTCTRLMGR_MotCtrlPwmPerd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaALowrCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaAUpprCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBLowrCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaBUpprCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCLowrCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctGpioPhaCUpprCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaALowrCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaAUpprCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBLowrCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaBUpprCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCLowrCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetFctPeriphPhaCUpprCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_PinSt : useless (never read) */

    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaALowrCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_PinSt : useless (never read) */

    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaAUpprCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_PinSt : useless (never read) */

    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBLowrCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_PinSt : useless (never read) */

    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaBUpprCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_PinSt : useless (never read) */

    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCLowrCmd_Return();
    
    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_PinSt : useless (never read) */

    /* init for variable GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return */
    _main_gen_init_sym_GtmCfgAndUse_Srv_IoHwAb_SetGpioPhaCUpprCmd_Return();
    
    /* init for variable GtmCfgAndUse_Cli_GtmGetSent0Data_BufStrt */
    _main_gen_init_sym_GtmCfgAndUse_Cli_GtmGetSent0Data_BufStrt();
    
    /* init for variable GtmCfgAndUse_Cli_GtmGetSent0Data_Return : useless (never read) */

    /* init for variable GtmCfgAndUse_Cli_GtmGetSent1Data_BufStrt */
    _main_gen_init_sym_GtmCfgAndUse_Cli_GtmGetSent1Data_BufStrt();
    
    /* init for variable GtmCfgAndUse_Cli_GtmGetSent1Data_Return : useless (never read) */

}
